<script>
	import Vue from 'vue'
	export default {
		onLaunch: function() {
			uni.getSystemInfo({
				success: function(e) {
					// #ifndef MP
					Vue.prototype.StatusBar = e.statusBarHeight;
					if (e.platform == 'android') {
						Vue.prototype.CustomBar = e.statusBarHeight + 50;
					} else {
						Vue.prototype.CustomBar = e.statusBarHeight + 45;
					};
					// #endif
					// #ifdef MP-WEIXIN
					Vue.prototype.StatusBar = e.statusBarHeight;
					let custom = wx.getMenuButtonBoundingClientRect();
					Vue.prototype.Custom = custom;
					Vue.prototype.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
					// #endif		

					// #ifdef MP-ALIPAY
					Vue.prototype.StatusBar = e.statusBarHeight;
					Vue.prototype.CustomBar = e.statusBarHeight + e.titleBarHeight;
					// #endif
				}
			})
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}

	}
</script>

<style>
	@import "colorui/main.css";
	@import "colorui/icon.css";

	.nav-list {
		display: flex;
		flex-wrap: wrap;
		padding: 0px 40upx 0px;
		justify-content: space-between;
	}

	.nav-li {
		padding: 30upx;
		border-radius: 12upx;
		width: 45%;
		margin: 0 2.5% 40upx;
		background-image: url(https://cdn.nlark.com/yuque/0/2019/png/280374/1552996358352-assets/web-upload/cc3b1807-c684-4b83-8f80-80e5b8a6b975.png);
		background-size: cover;
		background-position: center;
		position: relative;
		z-index: 1;
	}

	.nav-li::after {
		content: "";
		position: absolute;
		z-index: -1;
		background-color: inherit;
		width: 100%;
		height: 100%;
		left: 0;
		bottom: -10%;
		border-radius: 10upx;
		opacity: 0.2;
		transform: scale(0.9, 0.9);
	}

	.nav-li.cur {
		color: #fff;
		background: rgb(94, 185, 94);
		box-shadow: 4upx 4upx 6upx rgba(94, 185, 94, 0.4);
	}

	.nav-title {
		font-size: 32upx;
		font-weight: 300;
	}

	.nav-title::first-letter {
		font-size: 40upx;
		margin-right: 4upx;
	}

	.nav-name {
		font-size: 28upx;
		text-transform: Capitalize;
		margin-top: 20upx;
		position: relative;
	}

	.nav-name::before {
		content: "";
		position: absolute;
		display: block;
		width: 40upx;
		height: 6upx;
		background: #fff;
		bottom: 0;
		right: 0;
		opacity: 0.5;
	}

	.nav-name::after {
		content: "";
		position: absolute;
		display: block;
		width: 100upx;
		height: 1px;
		background: #fff;
		bottom: 0;
		right: 40upx;
		opacity: 0.3;
	}

	.nav-name::first-letter {
		font-weight: bold;
		font-size: 36upx;
		margin-right: 1px;
	}

	.nav-li text {
		position: absolute;
		right: 30upx;
		top: 30upx;
		font-size: 52upx;
		width: 60upx;
		height: 60upx;
		text-align: center;
		line-height: 60upx;
	}

	.text-light {
		font-weight: 300;
	}

	@keyframes show {
		0% {
			transform: translateY(-50px);
		}

		60% {
			transform: translateY(40upx);
		}

		100% {
			transform: translateY(0px);
		}
	}

	@-webkit-keyframes show {
		0% {
			transform: translateY(-50px);
		}

		60% {
			transform: translateY(40upx);
		}

		100% {
			transform: translateY(0px);
		}
	}
    
    .listend{
        height: 30upx;
        font-size: 21upx;
        text-align: center;
        font-weight: 400;
        line-height: 30upx;
        color: #EBEBEB;
        opacity: 1;
        margin-bottom: 50upx;
    }
    
    .parktitle{
        font-weight: bold; 
        color: #000000;
        margin-left: 40upx;
    }
	
	.mescroll-lazy-in,
	.mescroll-fade-in {
		-webkit-animation: mescrollFadeIn .3s linear forwards;
		animation: mescrollFadeIn .3s linear forwards;
	}
	
	.backTop {
		z-index: 999;
		position: fixed;
		right: 20upx;
		bottom: 220upx;
		/* #ifdef H5 */
		bottom: 220upx;
		/* #endif */
		width: 72upx;
		height: 72upx;
		border-radius: 50%;
		transform: translateZ(0);
		-webkit-transform: translateZ(0);
	}
	
	.backTop image {
		width: 100%;
		height: 100%;
	}
	
	.fenxianghaibao1{
		width: 570upx;
		height: 808upx;
		box-shadow: 0px 0px 21upx rgba(0, 0, 0, 0.16);
		margin: auto;
		position: relative;
	}
	
	.fenxianghaibao1s{
		width: 465upx;
		height: 808upx;
		box-shadow: 0px 0px 21upx rgba(0, 0, 0, 0.16);
		margin: auto;
		position: relative;
	}
	
	.fenxianghaibao2{
		width: 510upx;
		margin-left: 30upx;
		display: flex;
		align-items: center;
	}
	
	.fenxianghaibao3{
		width: 68upx;
		height: 68upx;
		border-radius: 50%;
	}
	
	.fenxianghaibao4{
		margin-left: 16upx;
		color: #2E2E2E;
	}
	
	.fenxianghaibao5{
		color: #6B6B6B;
		width: 510upx;
		margin-left: 30upx;
		text-align: left;
		margin-top: 15upx;
	}
	
	.fenxianghaibao6{
		border-bottom: 1upx dashed #707070;
		width: 510upx;
		height: 1upx;
		margin-left: 30upx;
		font-size: 28upx;
		text-align: left;
		margin-top: 20upx;
	}
	
	.fenxianghaibao7{
		margin-left: 30upx;
		width: 510upx;
		height: 400upx;
		margin-top: 20upx;
		position: relative;
	}
	
	.fenxianghaibao7img{
		position: absolute;
		width: 510upx;
		height: 400upx;
		top: 0;
		left: 0;
		z-index: 1;
	}
	
	.fenxianghaibao7v1{
		position: relative;
		margin-left: 30upx;
		text-align: left;
		width: 450upx;
		max-height: 200upx;
		font-size: 36upx;
		font-weight: bold;
		line-height: 50upx;
		color: #FFFFFF;
		opacity: 1;
		z-index: 2;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 4;
		overflow: hidden;
	}
	
	.fenxianghaibao7v2{
		position: absolute;
		width: 450upx;
		left: 30upx;
		text-align: left;
		bottom: 29upx;
		height: 30upx;
		font-size: 30upx;
		font-weight: 400;
		line-height: 30upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
		z-index: 2;
		color: #EBEBEB;
		opacity: 1;
	}
	
	.fenxianghaibao7end{
		width: 48upx;
		height: 7upx;
		background: #FFFFFF;
		opacity: 1;
		position: relative;
		margin-top: 20upx;
		margin-left: 30upx;
		z-index: 2;
	}
	
	.fenxianghaibao8{
		color: #888888;
		width: 510upx;
		margin-left: 30upx;
		text-align: left;
		margin-top: 15upx;
		font-size: 26upx;
	}
	
	.fenxianghaibao9{
		width: 510upx;
		margin-left: 30upx;
		text-align: left;
		border-bottom: 1upx dashed #707070;
		height: 20upx;
	}
	
	.fenxianghaibao10{
		width: 100upx;
		height: 100upx;
		position: absolute;
		bottom: 33upx;
		left: 30upx;
	}
	
	.fenxianghaibao11{
		width: 122upx;
		height: 54upx;
		position: absolute;
		bottom: 53upx;
		right: 30upx;
		background-size: 100% 100%;
	}
	
	.fenxianghaibao12{
		margin-top: 40upx;
		margin-bottom: 30upx;
		color: #282828;
	}
	
	.fenxianghaibao13{
		width: 243upx;
		height: 71upx;
		line-height: 71upx;
		background: #5E068C;
		opacity: 1;
		color: #FFFFFF;
		border-radius: 48upx;
	}
</style>
