<template>
	<view>
		<view class="cu-custom" :style="[{height:CustomBar + 'px'}]">
			<view class="cu-bar fixed" :style="style" :class="[bgImage!=''?'none-bg text-white bg-img':'',bgColor]">
				<view class="action" @tap="BackPage" v-if="isBack">
                    <image class="backson2" src="https://keyanpro.com/kyrh/imageuni/backicon.png"></image>
					<!-- <text class="cuIcon-back"></text> -->
					<slot name="backText"></slot>
				</view>
                <view class="action" v-if="isBack3">
                  
                </view>
				<view @tap="search" class="kryzs" v-if="isinput">
                    <view class="home-logo">
                        <image src="https://keyanpro.com/kyrh/imageuni/home/selogo.png" class="home-logoimg"></image>
                    </view>
					<view class="home-search">
						<image class="home-search-img" src="https://keyanpro.com/kyrh/imageuni/home/search.png"></image>
						<input placeholder-class="placeholderinput" placeholder="国家自然科学基金" @input="nameChange" class="home-search-input" />
					</view>
					<slot name="backText"></slot>
				</view>
                <view class="kryzs" v-if="isinput2">
                    <image @tap="BackPage2" class="backson" src="https://keyanpro.com/kyrh/imageuni/backicon.png"></image>
                    <view style="margin-right: 37upx;">
                        <view class="home-search-view">{{names}}
                        <view class="home-search-view2"></view>
                        </view>
                    </view>
                	<view class="home-search2">
                		<image class="home-search-img" src="https://keyanpro.com/kyrh/imageuni/home/search.png"></image>
                		<input confirm-type="search" @confirm="confirm" placeholder-class="placeholderinput" placeholder="国家自然科学基金" @input="nameChange" class="home-search-input2" />
                	</view>
                	<slot name="backText"></slot>
                </view>
                <view class="kryzs" v-if="isinput3">
                    <view class="dytext">
                        <text class="dytextexy">我的订阅</text>
                    </view>
                    <view class="home-search2">
                    	<image class="home-search-img" src="https://keyanpro.com/kyrh/imageuni/home/search.png"></image>
                    	<input  confirm-type="search" @confirm="confirm" placeholder-class="placeholderinput" placeholder="国家自然科学基金" @input="nameChange" class="home-search-input2" />
                    </view>
                    <slot name="backText"></slot>
                </view>
				<view class="content" :style="[{top:StatusBar + 'px'}]">
					<slot name="content"></slot>
				</view>
				<slot name="right"></slot>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				StatusBar: this.StatusBar,
				CustomBar: this.CustomBar,
				titleI:this.titleI,
			};
		},
		name: 'cu-custom',
		computed: {
			style() {
				var StatusBar = this.StatusBar;
				var CustomBar = this.CustomBar;
				var bgImage = this.bgImage;
				var style = `height:${CustomBar}px;padding-top:${StatusBar}px;`;
				if (this.bgImage) {
					style = `${style}background-image:url(${bgImage});`;
				}
				return style
			}
		},
		props: {
			bgColor: {
				type: String,
				default: ''
			},
			isBack: {
				type: [Boolean, String],
				default: false
			},
            isBack3: {
            	type: [Boolean, String],
            	default: false
            },
			isinput: {
				type: [Boolean, String],
				default: false
			},
            isinput2: {
            	type: [Boolean, String],
            	default: false
            },
            isinput3: {
            	type: [Boolean, String],
            	default: false
            },
			bgImage: {
				type: String,
				default: ''
			},
            names: {
            	type: String,
            	default: ''
            },
		},
		methods: {
			BackPage() {
				var pages = getCurrentPages();
				if(pages.length > 1){
					uni.navigateBack({
						delta: 1
					});
				}else{
					uni.redirectTo({
					    url:'../../pages/index/index'
					});
				}
			},
            BackPage2() {
            	uni.redirectTo({
            	    url:'../../pages/index/index'
            	});
            },
			nameChange(e){
				uni.setStorageSync('titipt',e.target.value);
			},
			confirm(){
			    this.$emit('itemclick')
			},
            search(){
                uni.navigateTo({
                    url:'../../pages/home/searchlist'
                })
            }
		}
	}
</script>

<style>
	.home-search {
		width: 432upx;
		height: 60upx;
		background: #F9F9F9;
		border-radius: 32upx;
		position: relative;
	}
    
    .home-search2 {
    	width: 272upx;
    	height: 60upx;
    	background: #F9F9F9;
    	border-radius: 32upx;
    	position: relative;
    }
    
    .home-logo{
        width: 101upx;
        height: 60upx;
        position: relative;
    }
    
    .home-search-view{
        height: 60upx;
        margin-left: 37upx;
        font-size: 33upx;
        font-weight: bold;
        line-height: 53upx;
        color: #000000;
        opacity: 1;
    }
    
    .home-search-view2{
        height: 7upx;
        background: #9702A3;
        opacity: 1;
        border-radius: 7upx;
    }
    
    .kryzs{
        display: flex;
    }
	.home-search-img {
		width: 28upx;
		height: 28upx;
		position: absolute;
		left: 30upx;
		top: 18upx;
	}
    
    .placeholderinput{
        font-size: 21upx;
    }
    
	.home-search-input {
		width: 280upx;
		height: 60upx;
		line-height: 60upx;
		font-size: 30upx;
		position: absolute;
		left: 70upx;
	}
    
    .home-search-input2 {
    	width: 192upx;
    	height: 64upx;
    	line-height: 64upx;
    	font-size: 30upx;
    	position: absolute;
    	left: 70upx;
    }
	
	.home-sousuo{
		width: 120upx;
		background: #912775;
		height: 54upx;
		text-align: center;
		line-height: 54upx;
		margin-left: 10upx;
		border-radius: 8upx;
		color: #FFFFFF;
	}
    
    .home-logoimg{
        width: 60upx;
        height: 60upx;
        margin-left: 28upx;
        border-radius: 50%;
        border: 1upx solid #fcfcfc;
    }
    
    .backson{
        margin-left: 28upx;
        margin-top: 13upx;
        width: 21upx;
        height: 35upx;
    }
    
    .backson2{
        width: 21upx;
        height: 35upx;
    }
    
    .dytext{
        width: 198upx;
        height: 60upx;
        opacity: 1;
        margin-left: 30upx;
        position: relative;
    }
    
    .dytextexy{
        position: relative;
        height: 33upx;
        font-size: 33upx;
        font-weight: bold;
        line-height: 37upx;
        color: #000000;
        opacity: 1;
        top: 13upx;
    }
</style>
