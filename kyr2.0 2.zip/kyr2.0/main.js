import Vue from 'vue'
import App from './App'
import api from '@/api/'
Vue.prototype.$api = api

import home from './pages/home/index.vue'
Vue.component('home',home)

import subscribe from './pages/subscribe/index.vue'
Vue.component('subscribe',subscribe)

import my from './pages/my/index.vue'
Vue.component('my',my)

import cuCustom from './colorui/components/cu-custom.vue'
Vue.component('cu-custom',cuCustom)

import backTop from './components/back-top/back-top.vue'
Vue.component('backTop',backTop)

import uniqrcode from '@/components/uni-qrcode/uni-qrcode.vue'
Vue.component('uni-qrcode',uniqrcode)

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()

 



