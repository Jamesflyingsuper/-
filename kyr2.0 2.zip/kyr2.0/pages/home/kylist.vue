<template name="home">
    <view>
        <cu-custom v-if="ispop < 1" bgColor="bg-white" @itemclick="cpnclick" :names="titles" :isinput2="true">
        </cu-custom>
        <cu-custom v-if="ispop >= 1" bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
            <block slot="content"><text style="font-weight: bold; color: #000000;">筛选</text></block>
        </cu-custom>
        <fjj-condition ref='condition' @touchmove.stop :list="menuList" @result="resultConditon" />
        <view style="height: 21upx;"></view>
        <view class="nvascr">
            <scroll-view class="nvascrview" @scroll="leftlist" :scroll-left="sleft" scroll-x="true" v-if="custom4s == ''&&custom5s == ''">
                <view @click="NavChange1" class="nvascrtext" v-for="(item,index) in govtype" :data-cur="index"
                   :data-id="item.SUBJECT_ID" :class="PageCur1==index?'curtext':''">{{item.SUBJECT_NAME}}</view>
            </scroll-view>
            <view class="nvascrview2" v-else>
                <view class="nvascrviewbtn" v-if="savers== 1" @tap="showModal" data-target="DialogModal1">
                    <image class="nvascrviewimg" src="https://keyanpro.com/kyrh/imageuni/sdkard.png"></image>
                    <text class="nvascrviewtext">保存到我的订阅</text>
                </view>
                <view class="nvascrviewbtn" v-if="savers== 2" @click="save2()">
                    <image class="nvascrviewimg" src="https://keyanpro.com/kyrh/imageuni/dingyue.png"></image>
                    <text class="nvascrviewtext">查看我的订阅</text>
                </view>
                <view class="nvascrviewtz">
                    <text class="nvascrviewtext2">已筛选{{ispop}}个条件</text>
                </view>
            </view>
            <view class="nvascricon" @tap="orderbyChange">
                <image class="nvascriconimg" src="https://keyanpro.com/kyrh/imageuni/seachicon.png"></image>
            </view>
        </view>

        <scroll-view scroll-y class="home-list" :scroll-with-animation="true" @scrolltolower="scroll" :style="[Style]">
            <view style="height: 56upx;"></view>
            <view class="home-3list1s">
                <view class="home-3list2item" @click="goto2(item.PROJECT_ID)" v-for="(item,index) in kyxmlist">
                    <view class="home-3name">
                        {{item.PROJECT_NAME}}
                    </view> 
                    <view class="home-3dizhi">
                        <view class="home-3dizhit3">{{text(item.PROJECT_ORGANIZATION_FUND)}}</view>
                        <text class="home-3dizhit4">{{text(item.PROJECT_ORGANIZATION)}}</text>
                    </view>
                    <view class="home-3tubiao">
                        <text v-if="item.PROJECT_FUNDS != null && item.PROJECT_FUNDS != ''" class="home-3tubiaoicon">{{item.PROJECT_FUNDS}}{{item.PROJECT_FUNDS_UNIT}}</text>
                        <text class="home-3tubiaoicon2"
                            v-for="(item2,index) in keyword2(item.PROJECT_KEYWORDS)">{{item2}}</text>
                    </view>
                </view>
            </view>
            <view v-if="kyxmlist != ''" class="listend">— 内容太多，试试搜索功能吧 —</view>
            <view v-else class="listend">— 暂无数据 —</view>
        </scroll-view>
        <view class="cu-modal" :class="modalName=='DialogModal1'?'show':''">
            <view class="cu-dialog">
                <view class="cu-bar bg-white justify-end">
                    <view class="content">关键词</view>
                    <view class="action" @tap="hideModal">
                        <text class="cuIcon-close text-red"></text>
                    </view>
                </view>
                <view class="padding-xl">
                    <input v-model="title" placeholder="请输入关键词" />
                </view>
                <view class="cu-bar bg-white justify-end">
                    <view class="action">
                        <button class="cu-btn line-green text-green" @tap="hideModal">取消</button>
                        <button class="cu-btn bg-green margin-left" @click="save1()">确定</button>
                    </view>
                </view>
            </view>
        </view>
		<view v-if="page>1" class="backTop mescroll-fade-in" @click="toTopClick">
			<image src="../../static/back-top/top.png" mode="widthFix" />
		</view>
    </view>
</template>

<script>
    import fjjCondition from '@/components/fjj-condition/fjj-condition.vue';
    export default {
        name: "home",
        data() {
            return {
                modalName: null,
                CustomBar: this.CustomBar,
                ispop: 0,
                titles: '科研项目',
                PageCur1: 0,
                savers: 1,
                govtype:[],
                user_id: uni.getStorageSync('user_id'),
                menuList: [{
                    'title': '学科分类',
					'title2': '不选代表选择全部, 下同',
                    'type': 'custom',
                    'key': 'custom4',
                    'isMutiple': true, //多选
                    'detailList': [],
                }, {
                    'title': '资助机构所在国家/地区',
                    'type': 'custom',
                    'key': 'custom5',
                    'isMutiple': true, //单选
                    'detailList': [],
                }],
                custom4s: '',
                custom5s: '',
                title: '',
                kyxmlist: [],
                page: 1,
				level:1,
				scrollTop: 0,
				sleft:0,
				jsid:''
            };
        },
        onLoad() {
            var that = this;
            this.$api.govsubject({}).then((res) => {
                var qb = {
                    id:'',
                    SUBJECT_NAME:'最新'
                }
                that.govtype.push(qb);
                for (var i = 0; i < res.data.data.data.length; i++) {
					if (res.data.data.data[i].SUBJECT_LEVEL == 1) {
						that.govtype.push(res.data.data.data[i]);
					}
                }
                var mlist = [];
				for (var i = 0; i < res.data.data.data.length; i++) {
					if (res.data.data.data[i].SUBJECT_LEVEL == 1) {
						mlist.push(res.data.data.data[i]);
					}
				}
                that.menuList[0].detailList = mlist.map(Iterator => {
                	return{
                		SUBJECT_NAME:Iterator.SUBJECT_NAME,
                		id:Iterator.SUBJECT_ID
                	}
                })
            });
            this.$api.govcountry({}).then((res) => {
                var mlist = [];
                mlist = res.data.data.data;
                that.menuList[1].detailList = mlist.map(Iterator => {
                	return{
                		CN_NAME:Iterator.CN_NAME,
                		id:Iterator.COUNTRY_ID
                	}
                })
            });
			var uid = uni.getStorageSync('user_id');
			this.$api.userpay({
				user_id: uid
			}).then((res) => {
				that.level = res.data.data.level;
			});
            that.listp();
        },
        components: {
            fjjCondition,
        },
        computed: {
            Style() {
                let obj = {
                    "height": `calc((100vh - 77rpx) - ${this.CustomBar}px)`,
                }
                return obj
            }
        },
        methods: {
			leftlist(e){
				this.sleft = e.detail.scrollLeft
			},
            NavChange1: function(e) {
                this.PageCur1 = e.currentTarget.dataset.cur;
				this.jsid = e.currentTarget.dataset.id
                var that = this;
                this.kyxmlist = [];
                this.page = 1;
				that.listp();
            },
            resultConditon(obj) {
				this.PageCur1 = 0;
				this.sleft = 0;
                this.$refs.condition.visibleDrawer = false;
                this.hasChoose = obj.hasChoose;
                this.custom4s = obj.str_result.custom4;
                this.custom5s = obj.str_result.custom5;
                var cs4 = 0;
                var cs5 = 0;
                var cslist4 = obj.str_result.custom4.split( ';' );
                var cslist5 = obj.str_result.custom5.split( ';' );
                for (var j = 0; j < cslist4.length; j++) {
                    if(cslist4[0] != ''){
                        cs4++;
                    }
                }
                for (var k = 0; k < cslist5.length; k++) {
                    if(cslist5[0] != ''){
                        cs5++;
                    }
                }
                this.ispop = cs4+cs5;
                this.kyxmlist = [];
                this.page = 1;
                this.listp();
            },
            orderbyChange(obj) {
                this.ispop = 1;
				if(this.level != 1){
					this.$refs.condition.visibleDrawer = true;
				}else{
					uni.showToast({
						title: '请注册会员',
						icon: 'none'
					});
				}
            },
            goto2(e) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
				this.$api.vipproject({
					id: uid
				}).then((res) => {
					if (res.data.data == 0) {
						uni.navigateTo({
							url: '/pages/my/myts'
						})
						return;
					} else {
						uni.navigateTo({
						    url: '/pages/home/kydetails?id='+e
						})
					}
				});
            },
            scroll() {
                var that = this;
                that.page++;
                that.listp();
            },
            cpnclick(item) {
                var that = this;
                that.title = uni.getStorageSync('titipt');
                that.kyxmlist = [];
                that.page = 1;
                that.listp();
            },
            listp() {
                var that = this;
                this.$api.kyxmlist({
                    limit: 5,
                    page: that.page,
                    title: that.title,
                    scientific_classification_one:that.jsid,
                    project_organization_fund_country_id:that.custom5s
                }).then((res) => {
                    for (var i = 0; i < res.data.data.data.length; i++) {
                        that.kyxmlist.push(res.data.data.data[i])
                    }
                });
            },
            time(t) {
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var time = timestamp - t;
                var days = time / 86400;
                var hours = days / 3600;
                var mins = hours / 60;
                if (mins * 311040000 < 60 && mins * 311040000 > 0) {
                    return Math.floor(mins * 311040000) + '分钟前';
                }
                if (hours * 86400 < 24 && hours * 86400 > 0) {
                    return Math.floor(hours * 86400) + '小时前';
                }
                if (days < 30 && days > 0) {
                    return Math.floor(days) + '天前';
                }
                if (days < 365 && days > 0) {
                    return Math.floor(days / 30) + '月前';
                }
                if (days > 365 && days > 0) {
                    return Math.floor(days / 365) + '年前';
                }
            },
            time2(t) {
                var that = this;
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var times = t - timestamp;
                return times
            },
            keyword2(a) {
                if (a != null) {
                    var arr = a.split(';');
                    if (arr != undefined) {
                        return arr;
                    } else {
                        return a;
                    }
                } else {
                    return '';
                }
            },
            img(a) {
                var url = 'https://keyanpro.com/' + a;
                return url;
            },
            save1() {
                var that = this;
                if (that.title == '') {
                    that.title = '不限关键词';
                }
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    that.modalName = null;
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
                this.$api.subadd({
                    user_id: that.user_id,
                    keywords: that.title,
                    type: 3,
                    loacal: that.custom5s,
                    research_field: '',
                    project_type: '',
                    scientific:that.custom4s
                }).then((res) => {
                    uni.setStorageSync('titipt', '');
                    that.modalName = null;
                    uni.showToast({
                        title: res.data.data.test,
                        icon: 'none'
                    });
                    that.savers = 2
                });
            
            },
            save2() {
                // #ifdef MP-WEIXIN
                uni.navigateTo({
                    url: '/pages/index/index?PageCur=subscribe'
                })
                // #endif	
                // #ifdef H5
                uni.setStorageSync('PageCur', 'subscribe');
                uni.redirectTo({
                    url: '/pages/index/index'
                })
                // #endif	
            
            },
            showModal(e) {
                this.modalName = e.currentTarget.dataset.target;
            },
            hideModal(e) {
                this.modalName = null;
            },
			text(a){
				if(a==false || a== null){
					return '—'
				}else{
					return a
				}
			},
			toTopClick() {
				this.kyxmlist = [];
				this.page = 1;
				this.listp();
			}
        }

    }
</script>

<style>
    .home-list {
        width: 690upx;
        margin-left: 30upx;
    }

    .home-3list1s {
        opacity: 1;
    }

    .home-3list2 {
        /* margin-top: 56upx; */
    }

    .home-3name {
        font-size: 32upx;
        font-weight: bold;
        color: #121212;
        opacity: 1;
        position: relative;
        line-height: 47upx;
		max-height: 94upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
    }

    .home-3nameicon {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #5E068C;
        opacity: 1;
        border: 1upx solid #5E068C;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3nameicon2 {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3list2item {
        margin-bottom: 83upx;
    }

    .home-3dizhi {
        width: 690upx;
        height: 30upx;
        position: relative;
        margin-top: 38upx;
    }

    .home-3dizhit1 {
        width: 530upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }

    .home-3dizhiimg {
        width: 19upx;
        height: 19upx;
        float: right;
        position: relative;
        top: 4.5upx;
        margin-right: 8upx;
    }

    .home-3dizhit2 {
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: right;
    }

    .home-3tubiao {
        margin-top: 38upx;
        width: 690upx;
        position: relative;
        height: 40upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
    }

    .home-3tubiaoicon {
        font-size: 21upx;
        font-weight: 400;
        line-height: 40upx;
        position: relative;
        color: #990263;
        opacity: 1;
        border: 1upx solid #990263;
        border-radius: 1upx;
/*        padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }

    .home-3tubiaoicon2 {
        font-size: 21upx;
        line-height: 40upx;
        font-weight: 400;
        position: relative;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
/*        padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }

    .nvascr {
        width: 750upx;
        height: 56upx;
        position: relative;
        display: flex;
    }

    .nvascrview {
        width: 650upx;
        height: 56upx;
        margin-left: 30upx;
        position: relative;
        white-space: nowrap
    }

    .nvascrview2 {
        width: 650upx;
        height: 56upx;
        margin-left: 30upx;
        position: relative;
        /* display: flex; */
    }

    .nvascrviewbtn {
        margin-top: 13upx;
        height: 30upx;
        margin-right: 15upx;
        color: #5E068C;
        opacity: 1;
        float: left;
    }

    .nvascrtext {
        padding-right: 42upx;
        display: inline-block;
        font-size: 24upx;
        font-weight: 400;
        line-height: 58upx;
        color: #999999;
        opacity: 1;
    }

    .nvascricon {
        width: 70upx;
        height: 56upx;
    }

    .nvascriconimg {
        width: 28upx;
        height: 28upx;
        position: relative;
        left: 21upx;
        top: 14upx;
    }

    .nvascrviewimg {
        width: 24upx;
        height: 24upx;
        margin-right: 13upx;
    }

    .nvascrviewtext {
        font-weight: bold;
        font-size: 24upx;
        line-height: 24upx;
        position: relative;
        top: -4upx;
    }

    .nvascrviewtext2 {
        font-size: 24upx;
        line-height: 24upx;
        position: relative;
        top: -4upx;
    }
    
    .home-3dizhit3 {
        width: 340upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        margin-right: 10upx;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }
    
    .home-3dizhit4 {
        width: 340upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #9E9E9E;
        opacity: 1;
        float: right;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
    }
    
    .nvascrviewtz {
        float: right;
        margin-top: 13upx;
        height: 30upx;
        margin-right: 15upx;
        color: #999999;
        opacity: 1;
    }

    .curtext {
        font-weight: bold;
        color: #5E068C;
    }
</style>
