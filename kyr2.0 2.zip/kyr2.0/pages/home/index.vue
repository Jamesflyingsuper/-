<template name="home">
    <view>
        <cu-custom bgColor="bg-white" @itemclick="cpnclick" :isinput="true"></cu-custom>
        <scroll-view scroll-y>
            <view style="height: 42upx;"></view>
            <view class="home-1">
                <view class="home-1v" @click="gotolist(1)" :style="[{animation: 'show ' + (1*0.4) + 's 1'}]">
                    <view class="home-1vimg1">
                        <image src="https://keyanpro.com/kyrh/imageuni/home/homem1.png" style="width: 100%; height: 100%;"></image>
                    </view>
                    <view class="home-1vtext">申报指南</view>
                </view>
                <view class="home-1v" @click="gotolist(2)" :style="[{animation: 'show ' + (1*0.5) + 's 1'}]">
                    <view class="home-1vimg2">
                        <image src="https://keyanpro.com/kyrh/imageuni/home/homem2.png" style="width: 100%; height: 100%;"></image>
                    </view>
                    <view class="home-1vtext">政采招标</view>
                </view>
                <view class="home-1v" @click="gotolist(3)" :style="[{animation: 'show ' + (1*0.6) + 's 1'}]">
                    <view class="home-1vimg3">
                        <image src="https://keyanpro.com/kyrh/imageuni/home/homem3.png" style="width: 100%; height: 100%;"></image>
                    </view>
                    <view class="home-1vtext">科研项目</view>
                </view>
                <view class="home-1v" @click="gotolist(4)" :style="[{animation: 'show ' + (1*0.7) + 's 1'}]">
                    <view class="home-1vimg4">
                        <image src="https://keyanpro.com/kyrh/imageuni/home/homem4.png" style="width: 100%; height: 100%;"></image>
                    </view>
                    <view class="home-1vtext">深度文章</view>
                </view>
            </view>
            <view style="height: 44upx;"></view>
            <view class="home-2">
                <swiper style="width: 690upx; height: 360upx; border-radius: 8upx; overflow: hidden;"
                    class="screen-swiper square-dot" :indicator-dots="true" :circular="true" :autoplay="true"
                    interval="5000" duration="500">
                    <swiper-item @click="goto4(item.id)" v-for="(item,index) in bannerlist" :key="index">
                        <image :src="img(item.thumbnail)" mode="aspectFill"></image>
                        <view class="bannertext">{{item.post_title}}</view>
						<view class="bannertext2"></view>
                    </swiper-item>
                </swiper>
            </view>
            <view class="home-3">
                <view class="home-3list1">
                    <view class="home-3title">
                        <image class="home-3titleimg1" src="https://keyanpro.com/kyrh/imageuni/home/homelist1.png"></image>
                        <text class="home-3titlename1">申报指南</text>
                        <text class="home-3titlename2">申报中：<text style="color:#990263;">{{sbznt2}}</text></text>
                        <text class="home-3titlename2">24H更新：<text style="color:#990263;">{{sbznt1}}</text></text>
                        <view class="home-3titledd" @click="gotolist1()">
                            <view class="home-3titleddview1"></view>
                            <view class="home-3titleddview2"></view>
                            <view class="home-3titleddview3"></view>
                        </view>
                    </view>
                    <view class="home-3list2">
                        <view class="home-3list2item" @click="goto1(item.IN_PROJECT_GOV_ID)" v-for="(item,index) in sbznlsit">
                            <view class="home-3name">
                                <text v-if="time2(item.PROJECT_DATE_END) > 0 && item.HITS>=hots"
                                    class="home-3nameicon">热门</text>
                                <text v-if="time2(item.PROJECT_DATE_END) < 0 && (item.PROJECT_DATE_END != null)" class="home-3nameicon2">已结束</text>
                                {{item.PROJECT_NAME}}
                            </view>
                            <view class="home-3dizhi">
                                <view class="home-3dizhit1">{{text(item.PROJECT_GOVERNMENT)}}</view>
                                <text class="home-3dizhit2">{{time(item.PROJECT_DATE)}}</text>
                                <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                            </view>
                            <view class="home-3tubiao">
                                <text v-if="item.PROJECT_FUNDS != '' && item.PROJECT_FUNDS !=null"
                                    class="home-3tubiaoicon">{{item.PROJECT_FUNDS}}万</text>
                                <text class="home-3tubiaoicon2"
                                    v-for="(item2,index) in keyword2(item.PROJECT_CONTENT_KEYWORDS)">{{item2}}</text>
                            </view>
                        </view>
                    </view>
                </view>

                <view class="home-3list1">
                    <view class="home-3title">
                        <image class="home-3titleimg1" src="https://keyanpro.com/kyrh/imageuni/home/homelist1.png"></image>
                        <text class="home-3titlename1">政采招标</text>
                        <text class="home-3titlename2">招标中：<text style="color:#990263;">{{zczbt1}}</text></text>
                        <text class="home-3titlename2">24H更新：<text style="color:#990263;">{{zczbt2}}</text></text>
                        <view class="home-3titledd" @click="gotolist2()">
                            <view class="home-3titleddview1"></view>
                            <view class="home-3titleddview2"></view>
                            <view class="home-3titleddview3"></view>
                        </view>
                    </view>
                    <view class="home-3list2">
                        <view class="home-3list2item" @click="goto2(item.TENDER_ID)" v-for="(item,index) in zczblist">
                            <view class="home-3name">
                                <text v-if="time2(item.TENDER_END_TIME) > 0 && item.HITS>=hots1"
                                    class="home-3nameicon">热门</text>
                                <text v-if="time2(item.TENDER_END_TIME) < 0 && (item.TENDER_END_TIME != null) && (item.TENDER_END_TIME != false)" class="home-3nameicon2">已结束</text>
                                {{item.TENDER_NAME}}
                            </view>
                            <view class="home-3dizhi">
                                <view class="home-3dizhit1">{{text(item.TENDER_ORGANIZATION)}}</view>
                                <text class="home-3dizhit2">{{time(item.TENDER_RELEASE_TIME)}}</text>
                                <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                            </view>
                            <view class="home-3tubiao">
                                <text v-if="item.TENDER_MONEY != '' && item.TENDER_MONEY != null "
                                    class="home-3tubiaoicon">{{item.TENDER_MONEY}}万</text>
                                <text class="home-3tubiaoicon2"
                                    v-for="(item2,index) in keyword2(item.TENDER_KEYWORDS)">{{item2}}</text>
                                <!-- <text class="home-3tubiaoicon2">新农村</text> -->
                            </view>
                        </view>
                    </view>
                </view>

                <view class="home-3list1">
                    <view class="home-3title">
                        <image class="home-3titleimg1" src="https://keyanpro.com/kyrh/imageuni/home/homelist1.png"></image>
                        <text class="home-3titlename1">科研项目</text>
                        <text class="home-3titlename2">在库：<text style="color:#990263;">{{kyxmt1}}</text></text>
                        <view class="home-3titledd"  @click="gotolist3()">
                            <view class="home-3titleddview1"></view>
                            <view class="home-3titleddview2"></view>
                            <view class="home-3titleddview3"></view>
                        </view>
                    </view>
                    <view class="home-3list2">
                        <view class="home-3list2item" @click="goto3(item.PROJECT_ID)" v-for="(item,index) in kyxmlist">
                            <view class="home-3name">
                                {{item.PROJECT_NAME}}
                            </view>
                            <view class="home-3dizhi">
                                <view class="home-3dizhit3">{{text(item.PROJECT_ORGANIZATION_FUND)}}</view>
                                <text class="home-3dizhit4">{{text(item.PROJECT_ORGANIZATION)}}</text>
                            </view>
                            <view class="home-3tubiao">
                                <text v-if="item.PROJECT_FUNDS != '' && item.PROJECT_FUNDS != null"
                                    class="home-3tubiaoicon">{{item.PROJECT_FUNDS}}{{item.PROJECT_FUNDS_UNIT}}</text>
                                <text class="home-3tubiaoicon2"
                                    v-for="(item2,index) in keyword2(item.PROJECT_KEYWORDS)">{{item2}}</text>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
            <view class="listend">— 我是有底线的 —</view>
            <view class="cu-tabbar-height"></view>
        </scroll-view>
    </view>
</template>

<script>
    export default {
        name: "home",
        data() {
            return {
                bannerlist: [],
                sbznt1: 0,
                sbznt2: 0,
                sbznlsit: [],
                zczbt1: 0,
                zczbt2: 0,
                zczblist: [],
                kyxmt1: [],
                kyxmlist: [],
				hots:0,
				hots1:0
            };
        },
        onShow() {

        },
        mounted() {
            var that = this;
			this.$api.ProjectGovhot().then((res) => {
				that.hots = res.data.data;
			});
			this.$api.Tenderhot().then((res) => {
				that.hots1 = res.data.data;
			});
            this.$api.sbznt1({}).then((res) => {
                that.sbznt1 = res.data.data.num;
            });
            this.$api.sbznt2({}).then((res) => {
                that.sbznt2 = res.data.data.num;
            });
            this.$api.sbznlist2({
                limit: 5,
                page: 1
            }).then((res) => {
                that.sbznlsit = res.data.data;
            });
            this.$api.zczbt1({}).then((res) => {
                that.zczbt1 = res.data.data.num;
            });
            this.$api.zczbt2({}).then((res) => {
                that.zczbt2 = res.data.data.num;
            });
            this.$api.zczblist({
                limit: 5,
                page: 1
            }).then((res) => {
                that.zczblist = res.data.data.data;
            });
            this.$api.kyxmt1({}).then((res) => {
                that.kyxmt1 = res.data.data.num;
            });
            this.$api.kyxmlist({
                limit: 5,
                page: 1
            }).then((res) => {
                that.kyxmlist = res.data.data.data;
            });
            this.$api.bannerlist({
                limit: 5,
                page: 1
            }).then((res) => {
                that.bannerlist = res.data.data.data;
            });

        },
        methods: {
            goto1(a) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
                this.$api.vipprojectGov({
                	id: uid
                }).then((res) => {
                	if (res.data.data == 0) {
                		uni.navigateTo({
                			url: '/pages/my/myts'
                		})
                		return;
                	} else {
                		uni.navigateTo({
                			url: '/pages/home/zndetails?id=' + a
                		})
                	}
                });
            },
            goto4(e) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
                // uni.navigateTo({
                //     url: '/pages/home/details3?itemContent=' + encodeURIComponent(JSON.stringify(e).replace(/%/g, '%25'))
                // })
                uni.navigateTo({
                    url:'/pages/home/details3?id='+e
                })
            },
            goto2(a) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
                this.$api.viptender({
                	id: uid
                }).then((res) => {
                	if (res.data.data == 0) {
                		uni.navigateTo({
                			url: '/pages/my/myts'
                		})
                		return;
                	} else {
                		uni.navigateTo({
                		    url:'/pages/home/zsdetails?id='+a
                		})
                	}
                });
            },
            goto3(a) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
                this.$api.vipproject({
                	id: uid
                }).then((res) => {
                	if (res.data.data == 0) {
                		uni.navigateTo({
                			url: '/pages/my/myts'
                		})
                		return;
                	} else {
                		uni.navigateTo({
                		    url:'/pages/home/kydetails?id='+a
                		})
                	}
                });
            },
            gotolist(a) {
                switch (a) {
                    case 1:
                        uni.navigateTo({
                            url: '/pages/home/sblist'
                        })
                        break;
                    case 2:
                        uni.navigateTo({
                            url: '/pages/home/zclist'
                        })
                        break;
                    case 3:
                        uni.navigateTo({
                            url: '/pages/home/kylist'
                        })
                        break;
                    case 4:
                        uni.navigateTo({
                            url: '/pages/home/sdlist'
                        })
                        break;
                    default:
                        break;
                }
            },
			gotolist1() {
			    uni.navigateTo({
			        url: '/pages/home/sblist'
			    })
			},
			gotolist2() {
			    uni.navigateTo({
			        url: '/pages/home/zclist'
			    })
			},
			gotolist3() {
			    uni.navigateTo({
			        url: '/pages/home/kylist'
			    })
			},
            time(t) {
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var time = timestamp - t;
                var days = time / 86400;
                var hours = days / 3600;
                var mins = hours / 60;
                if (mins * 311040000 < 60 && mins * 311040000 > 0) {
                    return Math.floor(mins * 311040000) + '分钟前';
                }
                if (hours * 86400 < 24 && hours * 86400 > 0) {
                    return Math.floor(hours * 86400) + '小时前';
                }
                if (days < 30 && days > 0) {
                    return Math.floor(days) + '天前';
                }
                if (days < 365 && days > 0) {
                    return Math.floor(days / 30) + '月前';
                }
                if (days > 365 && days > 0) {
                    return Math.floor(days / 365) + '年前';
                }
            },
            time2(t) {
                var that = this;
                var timestamp = Math.floor((new Date()).getTime() /1000);
                var times = t - timestamp ;
                return times
            },
            keyword2(a) {
                if (a != null) {
                    var arr = a.split(';');
                    if (arr != undefined) {
                        return arr;
                    } else {
                        return a;
                    }
                } else {
                    return a;
                }
            },
            img(a) {
				if(a != ''){
					var url = 'https://keyanpro.com/upload/' + a;
					return url;
				}
            },
			text(a){
				if(a == null || a == false){
					return '—'
				}else{
					return a
				}
			}
        }
    }
</script>

<style>
    .home-1 {
        width: 690upx;
        margin-left: 30upx;
        position: relative;
        display: flex;
    }

    .home-1v {
        width: 172.5upx;
        position: relative;
    }

    .home-1vimg1 {
        width: 36upx;
        height: 36upx;
        margin: auto;
    }

    .home-1vimg2 {
        width: 44upx;
        height: 36upx;
        margin: auto;
    }

    .home-1vimg3 {
        width: 32upx;
        height: 36upx;
        margin: auto;
    }

    .home-1vimg4 {
        width: 36upx;
        height: 36upx;
        margin: auto;
    }

    .home-1vtext {
        text-align: center;
        width: 100%;
        font-size: 26upx;
        color: #090909;
        margin-top: 23.6upx;
    }

    .home-2 {
        width: 690upx;
        height: 360upx;
        background: gray;
        margin-left: 30upx;
        border-radius: 10upx;
    }

    .bannertext {
        width: 630upx;
        margin-left: 30upx;
        max-height: 80upx;
        font-size: 30upx;
        font-weight: bold;
        line-height: 40upx;
        color: #FFFFFF;
        opacity: 1;
        letter-spacing: 2upx;
        position: absolute;
        bottom: 45upx;
        text-align: left;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
		z-index: 99;
    }
	
	.bannertext2{
		width: 690upx;
		height: 100upx;
		background-image: linear-gradient(rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 1));
		color: #ffffff;
		position: absolute;
		bottom: 0;
	}
	
    .home-3 {
        width: 690upx;
        margin-top: 67upx;
        margin-left: 30upx;
    }

    .home-3list1 {
        border-bottom: 1upx solid #E4E4E4;
        opacity: 1;
        margin-bottom: 69upx;
    }

    .home-3title {
        width: 690upx;
        height: 35upx;
        position: relative;
    }

    .home-3titleimg1 {
        width: 6upx;
        height: 31upx;
        position: relative;
        top: 2upx;
        float: left;
    }

    .home-3titlename1 {
        height: 35upx;
        font-size: 34upx;
        font-weight: bold;
        line-height: 35upx;
        color: #5E068C;
        opacity: 1;
        margin-left: 9upx;
    }

    .home-3titlename2 {
        margin-left: 28upx;
        margin-top: 10upx;
        height: 25upx;
        font-size: 25upx;
        font-weight: bold;
        line-height: 25upx;
        color: #999999;
        opacity: 1;
    }

    .home-3titledd {
		width: 80upx;
		z-index: 99;
        height: 35upx;
        opacity: 1;
        position: absolute;
        right: 0;
        top: 0upx;
        display: flex;
    }

    .home-3titleddview1 {
        width: 8upx;
        height: 8upx;
        background: #B9B9B9;
        margin-left: 38upx;
		margin-top: 14upx;
        border-radius: 50%;
    }

    .home-3titleddview2 {
        width: 8upx;
        height: 8upx;
        background: #B9B9B9;
        margin-left: 6.5upx;
		margin-top: 14upx;
        border-radius: 50%;
    }

    .home-3titleddview3 {
        width: 8upx;
        height: 8upx;
		margin-left: 6.5upx;
		margin-top: 14upx;
        background: #B9B9B9;
        border-radius: 50%;
    }

    .home-3list2 {
        margin-top: 56upx;
    }

    .home-3name {
        font-size: 32upx;
        font-weight: bold;
        color: #121212;
        opacity: 1;
        position: relative;
        line-height: 47upx;
		max-height: 94upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
    }

    .home-3nameicon {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #5E068C;
        opacity: 1;
        border: 1upx solid #5E068C;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3nameicon2 {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3list2item {
        margin-bottom: 83upx;
    }

    .home-3dizhi {
        width: 690upx;
        height: 30upx;
        position: relative;
        margin-top: 38upx;
    }

    .home-3dizhit1 {
        width: 530upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }

    .home-3dizhiimg {
        width: 19upx;
        height: 19upx;
        float: right;
        position: relative;
        top: 4.5upx;
        margin-right: 8upx;
    }

    .home-3dizhit2 {
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: right;
    }

    .home-3dizhit3 {
        width: 340upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        margin-right: 10upx;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }

    .home-3dizhit4 {
        width: 340upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #9E9E9E;
        opacity: 1;
        float: right;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
    }

    .home-3tubiao {
        margin-top: 38upx;
        width: 690upx;
        position: relative;
        height: 40upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
    }

    .home-3tubiaoicon {
        font-size: 20upx;
        font-weight: 400;
        line-height: 40upx;
        position: relative;
        color: #990263;
        opacity: 1;
        border: 1upx solid #990263;
        border-radius: 1upx;
        /* padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }

    .home-3tubiaoicon2 {
        font-size: 20upx;
        line-height: 40upx;
        font-weight: 400;
        position: relative;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
       /* padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }
</style>
