<template name="home">
    <view>
        <cu-custom  bgColor="bg-white" @itemclick="cpnclick" :names="titles" :isinput2="true">
        </cu-custom>
        <scroll-view class="sdlist-list" :scroll-with-animation="true" @scrolltolower="scroll" :style="[Style]" scroll-y="true">
            <view style="height: 10upx;"></view>
            <view class="sdlist-list-item" @click="goto3(item.id)" v-for="(item,index) in bannerlist">
                <view class="sdlist-list-itemle">
                    <view class="sli-title">{{item.post_title}}</view>
                    <view class="sli-cons">{{item.post_excerpt}}</view>
                </view>
                <view class="sdlist-list-itemri">
                    <image mode="aspectFill" class="sli-image" :src="img(item.thumbnail)"></image>
                </view>
                <view class="sdlist-3dizhi">
                    <image class="sdlist-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                    <text class="sdlist-3dizhit2">{{time(item.published_time)}}</text>
                    <text class="sdlist-3dizhit3">{{item.post_hits}}</text>
                    <image class="sdlist-3dizhiimg2" src="https://keyanpro.com/kyrh/imageuni/yan.png"></image>
                </view>
                <view style="height: 39upx;width: 690upx; float: left;"></view>
            </view>
        </scroll-view>
		<view v-if="page>1" class="backTop mescroll-fade-in" @click="toTopClick">
			<image src="../../static/back-top/top.png" mode="widthFix" />
		</view>
    </view>
</template>

<script>
   
    export default {
        name: "home",
        data() {
            return {
                titles: '深度文章',
                title: '',
                bannerlist: [],
                page: 1,
				scrollTop: 0
            };
        },
        onLoad() {
            console.log("success");
            var that = this;
            that.listp();
        },
        methods: {
            goto3(e) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
                // uni.navigateTo({
                //     url: '/pages/home/details3?itemContent=' + encodeURIComponent(JSON.stringify(e).replace(/%/g, '%25'))
                // })
                uni.navigateTo({
                    url: '/pages/home/details3?id='+e
                })
            },
            scroll() {
                var that = this;
                that.page++;
                that.listp();
            },
            cpnclick(item) {
                var that = this;
                that.title = uni.getStorageSync('titipt');
                that.bannerlist = [];
                that.page = 1;
                that.listp();
            },
            listp() {
                var that = this;
                this.$api.bannerlist({
                    limit: 5,
                    page: that.page,
                    title: that.title
            
                }).then((res) => {
                    for (var i = 0; i < res.data.data.data.length; i++) {
                        that.bannerlist.push(res.data.data.data[i])
                    }
                });
            },
            time(t) {
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var time = timestamp - t;
                var days = time / 86400;
                var hours = days / 3600;
                var mins = hours / 60;
                if (mins * 311040000 < 60 && mins * 311040000 > 0) {
                    return Math.floor(mins * 311040000) + '分钟前';
                }
                if (hours * 86400 < 24 && hours * 86400 > 0) {
                    return Math.floor(hours * 86400) + '小时前';
                }
                if (days < 30 && days > 0) {
                    return Math.floor(days) + '天前';
                }
                if (days < 365 && days > 0) {
                    return Math.floor(days / 30) + '月前';
                }
                if (days > 365 && days > 0) {
                    return Math.floor(days / 365) + '年前';
                }
            },
            time2(t) {
                var that = this;
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var times = t - timestamp;
                return times
            },
            keyword2(a) {
                if (a != null) {
                    var arr = a.split(';');
                    if (arr != undefined) {
                        return arr;
                    } else {
                        return a;
                    }
                } else {
                    return '';
                }
            },
            img(a) {
                if(a != ''){
                	var url = 'https://keyanpro.com/upload/' + a;
                	return url;
                }
            },
			toTopClick() {
				this.bannerlist = [];
				this.page = 1;
				this.listp();
			}
        },
        computed: {
            Style() {
                let obj = {
                    "height": `calc(100vh - ${this.CustomBar}px)`,
                }
                return obj
            }
        },

    }
</script>

<style>
   .sdlist-list{
       width: 750upx;
       height: 100vh;
   }
   
   .sdlist-list-item{
       margin: 30upx;
       width: 690upx;
       position: relative;
       overflow: hidden;
   }
   
   .sdlist-list-itemle{
       width: 483upx;
       float: left;
   }
   
   .sdlist-list-itemri{
       width: 174upx;
       float: right;
   }
   
   .sli-title{
       font-size: 32upx;
       font-weight: bold;
       line-height: 47upx;
       color: #121212;
       opacity: 1;
   }
   
   .sli-cons{
       margin-top: 18upx;
       font-size: 25upx;
       line-height: 42upx;
       color: #666666;
       opacity: 1;
       display: -webkit-box;
       -webkit-box-orient: vertical;
       -webkit-line-clamp: 2;
       overflow: hidden;
   }
   
   .sdlist-3dizhi {
       width: 690upx;
       height: 30upx;
       position: relative;
       margin-top: 35upx;
       float: left;
   }

   .sdlist-3dizhiimg {
       width: 19upx;
       height: 19upx;
       float: left;
       position: relative;
       top: 4.5upx;
       margin-right: 8upx;
   }
   
   .sdlist-3dizhit2 {
       height: 30upx;
       line-height: 30upx;
       font-size: 25upx;
       font-weight: 400;
       color: #9E9E9E;
       opacity: 1;
       float: left;
   }
   
   .sdlist-3dizhit3 {
       height: 30upx;
       line-height: 30upx;
       font-size: 25upx;
       font-weight: 400;
       color: #9E9E9E;
       opacity: 1;
       float: right;
   }
   
   .sdlist-3dizhiimg2 {
       width: 18upx;
       height: 15upx;
       float: right;
       position: relative;
       top: 6.5upx;
       margin-right: 8upx;
   }
   
   .sli-image{
       width: 174upx;
       height: 174upx;
       border-radius: 20upx;
   }
</style>
