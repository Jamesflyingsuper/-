<template name="home">
    <view>
        <cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
            <block slot="content"><text style="font-weight: bold; color: #000000;">机构相关课题</text></block>
        </cu-custom>
        <view style="height: 28upx;"></view>
        <view class="details2-banner">
            <image class="details2-bannerimg" src="https://keyanpro.com/kyrh/imageuni/d2banner.png"></image>
            <view style="height: 83upx;"></view>
            <view class="details2-bannerv1">{{names}}</view>
            <view style="height: 53upx;"></view>
            <view @click="dingyue(id)" v-if="tfdy==0" class="details2-bannerv2">+ 订阅</view>
            <view class="details2-bannerv3" v-if="tfdy==1">已订阅</view>
            <view style="height: 62upx;"></view>
            <view class="details2-bannerv4">指南 {{projecct_gov_count}} 条 政采信息 {{tender_count}}条 科研项目{{projecct_count}}条</view>
        </view>
        <view style="height: 51upx;"></view>
        <view class="details2-nav">
            <view class="" @click="demos" v-for="(item,index) in titles"
            :data-cur="index" :class="PageCur1==index?'details2-navv':'details2-navi'">{{item}}</view>
        </view>
        <scroll-view scroll-y class="home-list" @scrolltolower="scroll" :style="[Style]">
            <view style="height: 56upx;"></view>
            <view class="home-3list1s">
                <view class="home-3list2item" @click="goto0(item.IN_PROJECT_GOV_ID)" v-for="(item,index) in sbznlist"
                    v-if="PageCur1 == 0">
                    <view class="home-3name">
                        <text v-if="time2(item.PROJECT_DATE_END) > 0 && item.HITS>=hots" class="home-3nameicon">热门</text>
                        <text v-if="time2(item.PROJECT_DATE_END) < 0" class="home-3nameicon2">已结束</text>
                        {{item.PROJECT_NAME}}
                    </view>
                    <view class="home-3dizhi">
                        <view class="home-3dizhit1">{{text(item.PROJECT_GOVERNMENT)}}</view>
                        <text class="home-3dizhit2">{{time(item.PROJECT_DATE)}}</text>
                        <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                    </view>
                    <view class="home-3tubiao">
                        <text v-if="item.PROJECT_FUNDS == ''|| item.PROJECT_FUNDS!=null" class="home-3tubiaoicon">{{item.PROJECT_FUNDS}}万</text>
                        <text class="home-3tubiaoicon2"
                            v-for="(item,index) in keyword2(item.PROJECT_CONTENT_KEYWORDS)">{{item}}</text>
                    </view>
                </view>
                <view class="home-3list2item" @click="goto1(item.TENDER_ID)" v-for="(item,index) in zczblist"
                    v-if="PageCur1 == 1">
                    <view class="home-3name">
                        <text v-if="time2(item.TENDER_END_TIME) > 0 && item.hits>=hots1" class="home-3nameicon">热门</text>
                        <text v-if="time2(item.TENDER_END_TIME) < 0 && (item.TENDER_END_TIME != null)  && (item.TENDER_END_TIME != false)" class="home-3nameicon2">已结束</text>
                        {{item.TENDER_NAME}}
                    </view>
                    <view class="home-3dizhi">
                        <view class="home-3dizhit1">{{text(item.TENDER_ORGANIZATION)}}</view>
                        <text class="home-3dizhit2">{{time(item.TENDER_RELEASE_TIME)}}</text>
                        <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                    </view>
                    <view class="home-3tubiao">
                        <text v-if="item.TENDER_MONEY == '' || item.TENDER_MONEY!=null" class="home-3tubiaoicon">{{item.TENDER_MONEY}}万</text>
                        <text class="home-3tubiaoicon2"
                            v-for="(item,index) in keyword2(item.TENDER_KEYWORDS)">{{item}}</text>
                        <!-- <text class="home-3tubiaoicon2">新农村</text> -->
                    </view>
                </view>
                <view class="home-3list2item" @click="goto2(item.PROJECT_ID)" v-for="(item,index) in kyxmlist"
                    v-if="PageCur1 == 2">
                    <view class="home-3name">
                        {{item.PROJECT_NAME}}
                    </view>
                    <view class="home-3dizhi">
                        <view class="home-3dizhit3">{{text(item.PROJECT_ORGANIZATION_FUND)}}</view>
                        <text class="home-3dizhit4">{{text(item.PROJECT_ORGANIZATION)}}</text>
                    </view>
                    <view class="home-3tubiao">
                        <text v-if="item.PROJECT_FUNDS == '' || item.PROJECT_FUNDS!=null" class="home-3tubiaoicon">{{item.PROJECT_FUNDS}}</text>
                        <text class="home-3tubiaoicon2"
                            v-for="(item,index) in keyword2(item.PROJECT_KEYWORDS)">{{item}}</text>
                    </view>
                </view>
            </view>
        </scroll-view>
    </view>
</template>

<script>
    import fjjCondition from '@/components/fjj-condition/fjj-condition.vue';
    export default {
        name: "home",
        data() {
            return {
                datas:'',
                type:1,
                user_id:uni.getStorageSync('user_id'),
                id:'',
                names:'',
                PageCur1:0,
                tfdy:0,
                titles:['项目指南','政采招标','科研项目'],
                sbznlist:[],
                zczblist:[],
                kyxmlist:[],
                projecct_gov_count:0,
                tender_count:0,
                projecct_count:0,
				hots:0,
				hots1:0,
				page:1
            };
        },
        onShow() {
            console.log("success")
        },
        onShareTimeline: function(e){
        	// 配置标题
        	return {
        		title: '科研人',
        		path: '/pages/home/details2',
        		query: {
        			type: 0,
        			contentid: ''
        		}
        	}
        },
        onShareAppMessage: function(res) {
        	var that = this;
        	return {
        		title: '科研人', // 分享名称
        		path: '/pages/home/details2?pid='+ that.user_id,
        		// imageUrl: '../../static/graylogo.png',
        		success: function(shareTickets) {
        			uni.showToast({
        				title: "成功",
        				icon: 'none',
        				duration: 1000
        			});
        		},
        		fail: function(res) {
        			console.log(res + '失败');
        		},
        		complete: function(res) {
        			console.log("发送的uidwei" + user_id)
        		}
        	}
        },
        onLoad(e) {
            var that = this;
            that.type = e.type;
            that.names = e.name;
            that.id = e.id;
            var that = this;
			this.$api.ProjectGovhot().then((res) => {
				that.hots = res.data.data;
			});
			this.$api.Tenderhot().then((res) => {
				that.hots1 = res.data.data;
			});
            this.$api.subzation({
                user_id:that.user_id,
                organization_id:that.id
            }).then((res) => {
                that.tfdy = res.data.code;
				that.projecct_gov_count = res.data.data.projecct_gov_count;
				that.tender_count = res.data.data.tender_count;
				that.projecct_count = res.data.data.projecct_count;
            });
            that.listp1();
        },
        components: {
            fjjCondition,
        },
        computed: {
            Style() {
                let obj = {
                    "height": `calc((100vh - 478rpx) - ${this.CustomBar}px)`,
                }
                return obj
            }
        },
        methods: {
            demos: function(e) {
                this.PageCur1 = e.currentTarget.dataset.cur;
				this.sbznlist = [];
				this.zczblist = [];
				this.kyxmlist = [];
				this.page = 1;
				switch (e.currentTarget.dataset.cur){
					case 0:
						this.listp1();
						break;
					case 1:
						this.listp2();
						break;
					case 2:
						this.listp3();
						break;
					default:
						break;
				}
            },
            resultConditon(obj) {
                this.ispop = 0;
                this.$refs.condition.visibleDrawer = false;
                this.hasChoose = obj.hasChoose;
                this.custom1s = obj.str_result.custom1;
                this.custom2s = obj.str_result.custom2;
                this.custom3s = obj.str_result.custom3;
            },
            orderbyChange(obj) {
                this.ispop = 1;
                this.$refs.condition.visibleDrawer = true;
            },
            goto() {
                uni.navigateTo({
                    url: '/pages/home/details'
                })
            },
            dingyue(a){
                var that = this;
				if(a == '' ||a == 'null'){
					uni.showToast({
					    title:'不可订阅',
					    icon:'none'
					})
					return;
				}
                this.$api.suborganadd({
                    user_id:that.user_id,
                    organization_id:a
                }).then((res) => {
                    uni.showToast({
                        title:res.data.msg,
                        icon:'none'
                    })
                    if(res.data.code == 1){
                        that.tfdy = 1;
                    }
                });
            },
            listp1() {
                var that = this;
                this.$api.GovkeywordOrorganization({
					keywords:'',
					type:1,
					limit: 5,
					page: that.page,
					organization_id:that.id
				}).then((res) => {
                    for (var i = 0; i < res.data.data.length; i++) {
                        that.sbznlist.push(res.data.data[i])
                    }
                });
            },
			listp2() {
			    var that = this;
			    this.$api.GovkeywordOrorganization({
			        keywords:'',
			        type:2,
					limit: 5,
					page: that.page,
			        organization_id:that.id
			    }).then((res) => {
			        for (var i = 0; i < res.data.data.length; i++) {
			            that.zczblist.push(res.data.data[i])
			        }
			    });
			},
			listp3() {
			    var that = this;
			    this.$api.GovkeywordOrorganization({
			        keywords:'',
			        type:3,
					limit: 5,
					page: that.page,
			        organization_id:that.id
			    }).then((res) => {
			        for (var i = 0; i < res.data.data.length; i++) {
			            that.kyxmlist.push(res.data.data[i])
			        }
			    });
			},
            time(t) {
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var time = timestamp - t;
                var days = time / 86400;
                var hours = days / 3600;
                var mins = hours / 60;
                if (mins * 311040000 < 60 && mins * 311040000 > 0) {
                    return Math.floor(mins * 311040000) + '分钟前';
                }
                if (hours * 86400 < 24 && hours * 86400 > 0) {
                    return Math.floor(hours * 86400) + '小时前';
                }
                if (days < 30 && days > 0) {
                    return Math.floor(days) + '天前';
                }
                if (days < 365 && days > 0) {
                    return Math.floor(days / 30) + '月前';
                }
                if (days > 365 && days > 0) {
                    return Math.floor(days / 365) + '年前';
                }
            },
            time2(t) {
                var that = this;
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var times = t - timestamp;
                return times
            },
            keyword2(a) {
                if (a != null) {
                    var arr = a.split(';');
                    if (arr != undefined) {
                        return arr;
                    } else {
                        return a;
                    }
                } else {
                    return '';
                }
            },
			text(a){
				if(a==false || a== null){
					return '—'
				}else{
					return a
				}
			},
			goto0(e) {
			    var uid = uni.getStorageSync('user_id');
			    if (uid == '') {
			        uni.showToast({
			            title:'请先登录',
			            icon:'none'
			        });
			        return;
			    }
			    this.$api.vipprojectGov({
			    	id: uid
			    }).then((res) => {
			    	if (res.data.data == 0) {
			    		uni.navigateTo({
			    			url: '/pages/my/myts'
			    		})
			    		return;
			    	} else {
			    		uni.navigateTo({
			    			url: '/pages/home/zndetails?id=' + e
			    		})
			    	}
			    });
			},
			goto1(e) {
			    var uid = uni.getStorageSync('user_id');
			    if (uid == '') {
			        uni.showToast({
			            title:'请先登录',
			            icon:'none'
			        });
			        return;
			    }
			    this.$api.viptender({
			    	id: uid
			    }).then((res) => {
			    	if (res.data.data == 0) {
			    		uni.navigateTo({
			    			url: '/pages/my/myts'
			    		})
			    		return;
			    	} else {
			    		uni.navigateTo({
			    			url: '/pages/home/zsdetails?id=' + e
			    		})
			    	}
			    });
			},
			goto2(e) {
			    var uid = uni.getStorageSync('user_id');
			    if (uid == '') {
			        uni.showToast({
			            title:'请先登录',
			            icon:'none'
			        });
			        return;
			    }
			    this.$api.vipproject({
			    	id: uid
			    }).then((res) => {
			    	if (res.data.data == 0) {
			    		uni.navigateTo({
			    			url: '/pages/my/myts'
			    		})
			    		return;
			    	} else {
			    		uni.navigateTo({
			    		    url: '/pages/home/kydetails?id='+e
			    		})
			    	}
			    });
			},
			scroll(){
				var that = this;
				that.page++;
				this.listp1();
				this.listp2();
				this.listp3();
			}
        }

    }
</script>

<style>
    .home-list {
        width: 690upx;
        margin-left: 30upx;
    }

    .home-3list1s {
        opacity: 1;
    }

    .home-3list2 {
        /* margin-top: 56upx; */
    }

    .home-3name {
        font-size: 32upx;
        font-weight: bold;
        color: #121212;
        opacity: 1;
        position: relative;
        line-height: 47upx;
    }

    .home-3nameicon {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #5E068C;
        opacity: 1;
        border: 1upx solid #5E068C;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3nameicon2 {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3list2item {
        margin-bottom: 83upx;
    }

    .home-3dizhi {
        width: 690upx;
        height: 30upx;
        position: relative;
        margin-top: 38upx;
    }

    .home-3dizhit1 {
        width: 530upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }

    .home-3dizhiimg {
        width: 19upx;
        height: 19upx;
        float: right;
        position: relative;
        top: 4.5upx;
        margin-right: 8upx;
    }

    .home-3dizhit2 {
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: right;
    }
    
    .home-3dizhit3 {
        width: 340upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        margin-right: 10upx;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }
    
    .home-3dizhit4 {
        width: 340upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #9E9E9E;
        opacity: 1;
        float: right;
    }
    
    .home-3tubiao {
        margin-top: 38upx;
        width: 690upx;
        position: relative;
        height: 40upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
    }

    .home-3tubiaoicon {
        font-size: 20upx;
        font-weight: 400;
        line-height: 40upx;
        position: relative;
        color: #990263;
        opacity: 1;
        border: 1upx solid #990263;
        border-radius: 1upx;
/*        padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }

    .home-3tubiaoicon2 {
        font-size: 20upx;
        line-height: 40upx;
        font-weight: 400;
        position: relative;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
/*        padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }

    .details2-banner {
        width: 690upx;
        margin-left: 30upx;
        height: 360upx;
        position: relative;
        text-align: center;
    }

    .details2-bannerimg {
        width: 690upx;
        height: 360upx;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 0;
    }

    .details2-bannerv1 {
        color: #FFFFFF;
        position: relative;
        z-index: 1;
        text-align: center;
        font-size: 42upx;
        font-weight: bold;
        color: #FFFFFF;
        opacity: 1;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
    }

    .details2-bannerv2 {
        display: inline-block;
        padding-top: 10upx;
        padding-bottom: 10upx;
        padding-left: 25upx;
        padding-right: 25upx;
        background: linear-gradient(90deg, #FFCE86 0%, #FFBC76 100%);
        box-shadow: 0upx 2upx 4upx rgba(0, 0, 0, 0.16);
        opacity: 1;
        font-weight: bold;
        border-radius: 50upx;
        position: relative;
        z-index: 1;
    }

    .details2-bannerv3 {
        display: inline-block;
        padding-top: 10upx;
        padding-bottom: 10upx;
        padding-left: 25upx;
        padding-right: 25upx;
        border: 1upx solid #FFFFFF;
        opacity: 1;
        font-weight: bold;
        border-radius: 50upx;
        position: relative;
        z-index: 1;
        color: #FFFFFF;
    }

    .details2-bannerv4 {
        font-size: 24upx;
        font-family: Source Han Sans CN;
        font-weight: 400;
        color: #FFFFFF;
        opacity: 1;
        position: relative;
        z-index: 1;
    }

    .details2-nav {
        height: 40upx;
        width: 690upx;
        margin-left: 30upx;
    }

    .details2-navv {
        width: 230upx;
        font-size: 24upx;
        float: left;
        text-align: center;
        font-weight: bold;
        color: #5E068C;
        opacity: 1;
        line-height: 40upx;
    }

    .details2-navi {
        float: left;
        width: 230upx;
        text-align: center;
        font-size: 24upx;
        font-weight: 400;
        color: #999999;
        opacity: 1;
        line-height: 40upx;
    }
</style>
