<template name="home">
	<view>
		<cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
			<block slot="backText">
				<view class="parktitle">项目详情</view>
			</block>
		</cu-custom>

		<view class="details-bg">
			<xzj-firsthint :isCustom="false" />
			<view class="details-jia" v-if="level == 1">
				<view class="details-close cuIcon-close"></view>
				<view class="details-jiaview">
					<image class="details-jiaimg" mode="aspectFit" src="https://keyanpro.com/kyrh/imageuni/logo2.png">
					</image>
					<text class="details-jiatext">加入科研人，发现更多科研机会</text>
				</view>
				<view style="height: 46upx;"></view>
				<view @click="govip()" class="details-btn">立即加入</view>
				<view style="height: 38upx;"></view>
			</view>

			<view class="details-title">
				{{datas.PROJECT_NAME}}
			</view>
			<view class="details-gove">
				<view class="details-govev1">
					<text style="margin-right: 20upx;" @click="dingyue(item,index)"
						v-for="(item,index) in keyword3(datas.PROJECT_ORGANIZATION_FUND)">{{item}}</text>
				</view>
				<!-- <view class="details-govev2">
                    <image src="https://keyanpro.com/kyrh/imageuni/lingdang.png" class="details-goveimg"></image>
                    <text class="details-govetext">订阅</text>
                </view> -->
				<view class="details-govev2" @click="gody()" v-if="isdy == 0">
					<image src="https://keyanpro.com/kyrh/imageuni/lingdang.png" class="details-goveimg"></image>
					<text class="details-govetext">订阅</text>
				</view>
				<view class="details-govev3" v-if="isdy == 1">
					<image src="https://keyanpro.com/kyrh/imageuni/lingdang.png" class="details-goveimg"></image>
					<text class="details-govetext">已订阅</text>
				</view>
			</view>
			<view class="details-doc">
				<image src="https://keyanpro.com/kyrh/imageuni/time.png" class="details-docimg"></image>
				<view class="details-docview1">{{time(datas.GENERATE_TIME)}}</view>
				<!-- <view class="details-docview2">文号：——</view> -->
			</view>
			<view class="details-tb">
				<view class="details-tubiao" :class="more==1?'details-tubiaom':''">
					<view class="details-tubiao1" @click="dingyue2(item)"
						v-for="(item,index) in keyword2(datas.PROJECT_KEYWORDS)">{{item}}</view>
				</view>
				<button v-if="more == 1" @click="gengduo()" class="details-more cu-btn bg-mauve round">更多</button>
				<button v-if="more == 2" @click="shouhui()" class="details-more cu-btn bg-mauve round">收回</button>
			</view>
			<view class="details-type">
				<view style="height: 20upx;"></view>
				<view class="details-typev">
					<text class="details-typet">项目编号：</text>{{text(datas.PROJECT_NUMBER)}}
				</view>
				<view class="details-typev">
					<text class="details-typet">项目金额：</text>
					<text
						v-if=" datas.PROJECT_FUNDS !=null">{{text(datas.PROJECT_FUNDS)}}{{text(datas.PROJECT_FUNDS_UNIT)}}</text>
					<text v-else>—</text>
				</view>
				<view class="details-typev">
					<text class="details-typet">承担机构：</text>{{text(datas.PROJECT_ORGANIZATION)}}
				</view>
				<view class="details-typev">
					<text class="details-typet">负 责 人 ：</text>{{text(datas.PROJECT_PRINCIPAL)}}
				</view>
				<view class="details-typev">
					<text class="details-typet">研究周期：</text>
					<text v-if="datas.PROJECT_START != false">{{times(datas.PROJECT_START)}}-</text>
					<text v-if="datas.PROJECT_START != false && datas.PROJECT_END != false">{{times(datas.PROJECT_END)}}</text>
					<text v-if="datas.PROJECT_START == false">暂无数据</text>
					<text style="margin-left: 15upx;" v-if="datas.residue > 0">剩余{{datas.residue}}天</text>
					<text style="margin-left: 15upx;" v-if="datas.residue <= 0 && datas.PROJECT_START != false">(已结束)</text>
					
				</view>
				<view class="details-typev">
					<text class="details-typet">所属学科：</text>{{text(datas.SCIENTIFIC_CLASSIFICATION_ONE)}}
				</view>
				<view style="height: 20upx;"></view>
			</view>
			<view class="details-h5">
				<image class="details-h5img" src="https://keyanpro.com/kyrh/imageuni/home/homelist1.png"></image>
				<text>项目摘要</text>
			</view>
			<view class="details-h5v" style="white-space:pre-wrap">
				<u-parse :content="datas.PROJECT_ABSTRACT"></u-parse>
			</view>
			<view class="details-h5">
				<image class="details-h5img" src="https://keyanpro.com/kyrh/imageuni/home/homelist1.png"></image>
				<text>更多项目</text>
				<text class="details-h5smtext">点击关键词显示更多相关课题信息↓↓↓</text>
			</view>
			<view class="details-tb">
				<view class="details-tubiao" style="width: 690upx;">
					<view class="details-tubiao1" @click="dingyue2(item)"
						v-for="(item,index) in keyword2(datas.PROJECT_KEYWORDS)">{{item}}</view>
				</view>
			</view>
			<view class="details-jia" v-if="level == 1">
				<view class="details-close cuIcon-close"></view>
				<view class="details-jiaview">
					<image class="details-jiaimg" mode="aspectFit" src="https://keyanpro.com/kyrh/imageuni/logo2.png">
					</image>
					<text class="details-jiatext">加入科研人，发现更多科研机会</text>
				</view>
				<view style="height: 46upx;"></view>
				<view @click="govip()" class="details-btn">立即加入</view>
				<view style="height: 38upx;"></view>
			</view>
			<view style="height: 70upx;"></view>
			<view class="details-dd">
				<view class="details-ddview"></view>
			</view>
			<view style="height:48upx;"></view>
			<view class="details-bvs">
				本信息由科研人整理，相关信息请以官方文件为准。
			</view>
			<view style="height:18upx;"></view>
			<view class="details-bvs">
				科研人PC版：www.keyanpro.com
			</view>
			<view style="height:38upx;"></view>
			<view class="details-ewm">
				<view class="details-ewmitem">
					<image class="details-ewmimg" src="https://keyanpro.com/kyrh/imageuni/gzh.png"></image>
					<view class="details-ewmview">微信公众号</view>
				</view>
				<view class="details-ewmitem">
					<image class="details-ewmimg" src="https://keyanpro.com/kyrh/imageuni/kf.png"></image>
					<view class="details-ewmview">微信客服</view>
				</view>
			</view>
			<view style="height:38upx;"></view>
			<view class="details-endlogo">
				<image src="https://keyanpro.com/kyrh/imageuni/endlogo.png" class="details-endlogoimg"></image>
			</view>
			<view style="height:28upx;"></view>
		</view>
		<view style="height: 100upx;"></view>
		<view class="details-bottom">
			<view @click="copy(datas.PROJECT_SOURCE_URL)" class="details-bottomview1">
				原文
			</view>
			<view class="details-bottomview1" @click="shoucang()">
				收藏
			</view>
			<button v-if="codeImg != ''" @tap="showModal" data-target="bottomModal" class="details-bottomview2">
				<image class="details-bottomviewimg" src="https://keyanpro.com/kyrh/imageuni/weixin.png"></image>
				<text>分享</text>
			</button>
			<button v-if="codeImg == ''" class="details-bottomview3">
				<image class="details-bottomviewimg" src="https://keyanpro.com/kyrh/imageuni/weixin.png"></image>
				<text>加载中...</text>
			</button>
		</view>
		<view class="cu-modal bottom-modal" :class="modalName=='bottomModal'?'show':''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white">
					<view class="action text-green"></view>
					<view class="action text-gray cuIcon-close" @tap="hideModal"></view>
				</view>
				<view v-if="backs == 1" class="bg-white">
					<image class="fenxianghaibao1" mode="aspectFit" :src="mhq(codeImg)"></image>
					<view class="fenxianghaibao12">保存图片后，可分享至朋友圈或好友</view>
					<button @click="save()" class="fenxianghaibao13"><text style="margin-right: 13rpx;"
							class="cuIcon-down"></text>保存</button>
					<view style="height: 50upx;"></view>
				</view>
				<view class="bg-white" v-if="backs == 2">
					<canvas class="fenxianghaibao1" canvas-id="qrcode"
						:style="{width: `${qrcodeSize}px`, height: `${qrcodeSize}px`}" />
					<view class="fenxianghaibao12">保存二维码后，可分享至朋友圈或好友</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import firsthint from "@/components/xzj-firsthint/xzj-firsthint.vue";
	import uParse from '@/components/u-parse/u-parse.vue';
	import uQRCode from '@/components/uni-qrcode/uqrcode.js'
	export default {
		name: "home",
		components: {
			firsthint,
			uParse
		},
		data() {
			return {
				datas: {},
				user_id: uni.getStorageSync('user_id'),
				type: 3,
				govtype: [],
				level: 1,
				isdy: -1,
				more: 1,
				modalName: null,
				nickName: uni.getStorageSync('nickName'),
				avatarUrl: 'https://keyanpro.com/kyrh/imageuni/my/h5logo.png',
				access_token: uni.getStorageSync('accesstoken'),
				codeImg: '',
				backs: 2,
				qrcodeText: '',
				qrcodeSize: uni.upx2px(400),
				qrcodeSrc: '',
				wid: ''
			};
		},
		onShow() {

		},
		onShareTimeline: function(e) {
			// 配置标题
			return {
				title: '科研人',
				path: '/pages/home/kydetails',
				query: {
					type: 0,
					contentid: ''
				}
			}
		},
		onShareAppMessage: function(res) {
			var that = this;
			return {
				title: '科研人', // 分享名称
				path: '/pages/home/kydetails',
				// imageUrl: '../../static/tabbar/home',
				success: function(shareTickets) {
					uni.showToast({
						title: "成功",
						icon: 'none',
						duration: 1000
					});
				},
				fail: function(res) {
					console.log(res + '失败');
				},
				complete: function(res) {
					console.log("发送的uidwei" + uid)
				}
			}
		},
		onLoad(e) {
			var that = this;
			var wid = '';
			if (e && 'q' in e) {
				const q = decodeURIComponent(e.q);
				const querys = q
					.split('?')[1]
					.split('&')
					.reduce((acc, it) => {
						let r = it.split(/=/)
						return Object.assign(acc, {
							[r[0]]: r[1]
						})
					}, {});
				if ('wid' in querys) {
					wid = querys.wid.trim();
					console.log('h5文章id=' + wid);
				}
				if ('scene' in querys) {
					uni.setStorageSync('pid', querys.scene.trim());
				}
			} else {
				if (e.id) {
					wid = e.id;
					console.log('h5无分享=' + wid);
				}
			}
			// #ifdef H5
			that.backs = 2;
			var qrcodeText = 'https://keyanpro.com/?id=4&scene=' + that.user_id + '&wid=' + wid;
			uQRCode.make({
				canvasId: 'qrcode',
				text: qrcodeText,
				size: this.qrcodeSize,
				margin: 10
			}).then(res => {
				that.codeImg = res
			}).finally(() => {})
			// #endif	
			// #ifdef MP-WEIXIN
			if (e.scene) {
				const scene = decodeURIComponent(e.scene);
				let arr = scene.split(",");
				uni.setStorageSync('pid', arr[0]);
				console.log('小程序用户id=' + arr[0]);
				wid = arr[1];
				console.log('小程序文章id=' + wid);
			} else {
				if (e.id) {
					wid = e.id;
					console.log('小程序无分享=' + wid);
				}
			}
			that.backs = 1;
			that.$api.subscribeshare({
				id: that.user_id,
				user_name: that.nickName,
				title_id: wid,
				type: 3
			}).then((res) => {
				that.codeImg = res.data.data;
			});
			// #endif	
			that.$api.userpay({
				user_id: that.user_id
			}).then((res) => {
				that.level = res.data.data.level;
			});
			this.$api.kyxmlist({
				limit: 1,
				page: 1,
				id: wid
			}).then((res) => {
				that.datas = res.data.data.data[0];
				var list = res.data.data.data[0].PROJECT_ORGANIZATION_FUND_ID;
				if (list != '' && list != null) {
					this.$api.subzation({
						user_id: that.user_id,
						organization_id: list
					}).then((res) => {
						that.isdy = res.data.code
					});
				}
			});

			this.$api.historyadd3({
				user_id: that.user_id,
				title_id: wid
			}).then((res) => {});

			this.$api.projecthits({
				id: wid
			}).then((res) => {});

			this.$api.govtype({}).then((res) => {
				that.govtype = res.data.data.data;
			});
		},
		created() {
			var that = this;
		},
		methods: {
			showModal(e) {
				if (this.codeImg != '') {
					this.modalName = e.currentTarget.dataset.target
				} else {
					uni.showToast({
						title: '加载中...',
						icon: 'none'
					})
				}
			},
			hideModal(e) {
				this.modalName = null
			},
			dingyue(a, b) {
				var that = this;
				var list = that.datas.PROJECT_ORGANIZATION_FUND_ID;
				var id = '';
				if (list != null) {
					list = list + '';
					var arr = list.split(';');
					for (var i = 0; i < arr.length; i++) {
						id = arr[b];
					}
					uni.navigateTo({
						url: '/pages/home/details2?name=' + a + '&type=3' + '&id=' + id
					})
				} else {
					uni.showToast({
						title: '不可订阅',
						icon: 'none'
					})
					return;
				}
			},
			dingyue2(a) {
				uni.navigateTo({
					url: '/pages/home/details4?keyword=' + a + '&type=3'
				})
			},
			time(t) {
				if(t == false){
					return '—'
				}
				var timestamp = Math.floor((new Date()).getTime() / 1000);
				var time = timestamp - t;
				var days = time / 86400;
				var hours = days / 3600;
				var mins = hours / 60;
				if (mins * 311040000 < 60 && mins * 311040000 > 0) {
					return Math.floor(mins * 311040000) + '分钟前';
				}
				if (hours * 86400 < 24 && hours * 86400 > 0) {
					return Math.floor(hours * 86400) + '小时前';
				}
				if (days < 30 && days > 0) {
					return Math.floor(days) + '天前';
				}
				if (days < 365 && days > 0) {
					return Math.floor(days / 30) + '月前';
				}
				if (days > 365 && days > 0) {
					return Math.floor(days / 365) + '年前';
				}
			},
			times(a) {
				if(a == false){
					return '—'
				}
				var b = a * 1000;
				switch (uni.getSystemInfoSync().platform) {
					case 'ios':
						// var date = new Date(b.split('.')[0].replace(/\-/g, '/'));
						var date = new Date(b);
						break;
					default:
						var date = new Date(b);
						break;
				}
				let y = date.getFullYear();
				let MM = date.getMonth() + 1;
				MM = MM < 10 ? ('0' + MM) : MM;
				let d = date.getDate();
				d = d < 10 ? ('0' + d) : d;
				let h = date.getHours();
				h = h < 10 ? ('0' + h) : h;
				let m = date.getMinutes();
				m = m < 10 ? ('0' + m) : m;
				let s = date.getSeconds();
				s = s < 10 ? ('0' + s) : s;
				return y + '/' + MM + '/' + d;
			},
			keyword1(a) {
				if (a != null) {
					if (arr != undefined) {
						return arr;
					} else {
						return a;
					}
				} else {
					return '';
				}
			},
			keyword2(a) {
				if (a != null) {
					var arr = a.split(';');
					if (arr != undefined) {
						return arr;
					} else {
						return a;
					}
				} else {
					return '';
				}
			},
			keyword3(a) {
				if (a != null) {
					var arr = a.split(' ');
					if (arr != undefined) {
						return arr;
					} else {
						return a;
					}
				} else {
					return '';
				}
			},
			text(a) {
				if (a == null || a == false) {
					return '—'
				} else {
					return a
				}
			},
			shoucang() {
				var that = this;
				this.$api.collectAdd({
					type: 3,
					user_id: that.user_id,
					title_id: that.datas.PROJECT_ID
				}).then((res) => {
					uni.showToast({
						title: res.data.data.test,
						icon: 'none'
					})
				});
			},
			govip() {
				uni.redirectTo({
					url: '/pages/index/index?PageCur=my'
				})
			},
			gody() {
				var that = this;
				var list = that.datas.PROJECT_ORGANIZATION_FUND_ID;
				var id = '';
				if (list != null && list != '') {
					list = list + ''
					var arr = list.split(';');
					if (arr.length <= 1) {
						id = list
					} else {
						for (var i = 0; i < arr.length; i++) {
							id = arr[0];
						}
						if (id == '') {
							uni.showToast({
								title: '不可订阅',
								icon: 'none'
							})
							return;
						}
					}
					this.$api.suborganadd({
						user_id: that.user_id,
						organization_id: id
					}).then((res) => {
						uni.showToast({
							title: res.data.msg,
							icon: 'none'
						})
						if (res.data.code == 1) {
							that.isdy = 1;
						}
					});
				} else {
					uni.showToast({
						title: '不可订阅',
						icon: 'none'
					})
				}

			},
			copy(a) {
				if (a == null) {
					uni.showToast({
						title: '暂无原文链接',
						icon: 'none'
					})
					return;
				}
				wx.showModal({
					title: '复制原文链接，请到浏览器中打开。',
					content: a,
					showCancel: true, //是否显示取消按钮
					cancelText: "否", //默认是“取消”
					cancelColor: 'violet', //取消文字的颜色
					confirmText: "复制", //默认是“确定”
					confirmColor: 'violet', //确定文字的颜色
					success: function(res) {
						if (res.cancel) {
							//点击取消,默认隐藏弹框
						} else {
							uni.setClipboardData({
								data: a,
								success: function(res) {
									uni.showToast({
										icon: 'none',
										title: "复制成功",
									});
								}
							})
						}
					},
					fail: function(res) {},
					complete: function(res) {}
				})
			},
			gengduo() {
				this.more = 2;
			},
			shouhui() {
				this.more = 1;
			},
			save() {
				var that = this;
				uni.downloadFile({
					url: that.mhq(that.codeImg),
					success: (res) => {
						if (res.statusCode === 200) {
							uni.saveImageToPhotosAlbum({
								filePath: res.tempFilePath,
								success: function() {
									that.modalName = null
									uni.showModal({
										title: '图片已保存到系统相册',
										content: "快去分享给小伙伴们吧",
										showCancel: false
									})
								},
								fail: function() {
									uni.showToast({
										title: "保存失败，请稍后重试",
										icon: "none"
									});
								}
							});
						}
					}
				})
			},
			mhq(a) {
				var url = 'https://keyanpro.com/' + a;
				console.log(url)
				return url;
			}
		}

	}
</script>

<style>
	@import url("@/components/u-parse/u-parse.css");

	.details-bg {
		width: 690upx;
		margin-left: 30upx;
	}

	.details-jia {
		width: 690upx;
		text-align: center;
		background: #FBFCFF;
		border: 1upx solid #E6E7E9;
		opacity: 1;
		border-radius: 7upx;
		margin-top: 56upx;
		position: relative;
	}

	.details-jiaview {
		height: 60upx;
		text-align: center;
		display: -webkit-flex;
		justify-content: center;
		align-items: center;
		position: relative;
		margin-top: 38upx;
	}

	.details-jiaimg {
		width: 52upx;
		height: 60upx;
		text-align: center;
		margin-right: 16upx;
	}

	.details-jiatext {
		font-size: 33upx;
		font-weight: 500;
		color: #282828;
		opacity: 1;
	}

	.details-btn {
		background: #9702A3;
		text-align: center;
		display: inline;
		padding-top: 16upx;
		padding-bottom: 16upx;
		padding-left: 31upx;
		padding-right: 31upx;
		border-radius: 6upx;
		color: #FFFFFF;
	}

	.details-close {
		width: 17upx;
		height: 17upx;
		position: absolute;
		right: 27upx;
		top: 24upx;
		opacity: 1;
	}

	.details-title {
		margin-top: 56upx;
		width: 690upx;
		font-size: 42upx;
		font-weight: bold;
		line-height: 56upx;
		color: #282828;
		opacity: 1;
	}

	.details-gove {
		width: 690upx;
		margin-top: 28upx;
		position: relative;
	}

	.details-govev1 {
		width: 560upx;
		font-size: 29upx;
		font-weight: 400;
		line-height: 42upx;
		color: #990263;
		opacity: 1;
	}

	.details-govev2 {
		width: 90upx;
		height: 35upx;
		background: linear-gradient(90deg, #FFBD5C 0%, #FF8E18 100%);
		opacity: 1;
		border-radius: 21upx;
		position: absolute;
		right: 0;
		text-align: center;
		top: 0;
		display: -webkit-flex;
		justify-content: center;
		align-items: center;
	}

	.details-govev3 {
		width: 120upx;
		height: 35upx;
		background: #cccccc;
		opacity: 1;
		border-radius: 21upx;
		position: absolute;
		right: 0;
		text-align: center;
		top: 0;
		display: -webkit-flex;
		justify-content: center;
		align-items: center;
	}

	.details-goveimg {
		width: 20upx;
		height: 21upx;
		margin-right: 7upx;
	}

	.details-govetext {
		font-size: 21upx;
		color: #FFFFFF;
	}

	.details-doc {
		width: 690upx;
		margin-top: 28upx;
		position: relative;
		display: -webkit-flex;
		align-items: center;
	}

	.details-docimg {
		width: 21upx;
		height: 21upx;
		margin-right: 12upx;
	}

	.details-docview1 {
		font-size: 21upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
	}

	.details-docview2 {
		font-size: 21upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
		margin-left: 28upx;
	}

	.details-tb {
		width: 690upx;
		overflow: hidden;
		margin-top: 42upx;
		position: relative;
	}

	.details-tubiao {
		width: 550upx;
		position: relative;
		overflow: hidden;
	}

	.details-tubiaom {
		max-height: 90upx;
	}

	.details-more {
		position: absolute;
		height: 35upx;
		font-size: 22upx;
		top: 0;
		right: 0;
	}

	.details-tubiao1 {
		text-align: center;
		float: left;
		font-size: 21upx;
		font-weight: 400;
		position: relative;
		height: 35upx;
		line-height: 35upx;
		color: #9E9E9E;
		opacity: 1;
		border: 1upx solid #9E9E9E;
		border-radius: 1upx;
		padding-left: 15upx;
		padding-right: 15upx;
		margin-right: 14upx;
		margin-bottom: 16upx;
	}

	.details-type {
		width: 690upx;
		background: #FAFAFA;
		opacity: 1;
		position: relative;
		margin-top: 51upx;
	}

	.details-typev {
		margin: 20upx;
		height: 45upx;
		line-height: 45upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
	}

	.details-typet {
		color: #9E9E9E;
	}

	.details-bottom {
		width: 750upx;
		height: 100upx;
		border-top: 1upx solid #F0F0F0;
		position: fixed;
		bottom: 0;
	}

	.details-bottomview1 {
		width: 250upx;
		float: left;
		height: 100upx;
		border-right: 1upx solid #F1F2F3;
		line-height: 100upx;
		text-align: center;
		background: #FFFFFF;
		opacity: 1;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
		color: #121212;
		opacity: 1;
	}

	.details-bottomview2 {
		width: 250upx;
		float: left;
		height: 100upx;
		border-radius: 0;
		/* border-right: 1upx solid #F1F2F3; */
		line-height: 100upx;
		text-align: center;
		background: #5E068C;
		opacity: 1;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
		color: #FFFFFF;
		opacity: 1;
		display: -webkit-flex;
		justify-content: center;
		align-items: center;
	}

	.details-bottomview3 {
		width: 250upx;
		float: left;
		height: 100upx;
		border-radius: 0;
		/* border-right: 1upx solid #F1F2F3; */
		line-height: 100upx;
		text-align: center;
		background: #9e9e9e;
		opacity: 1;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
		color: #FFFFFF;
		opacity: 1;
		display: -webkit-flex;
		justify-content: center;
		align-items: center;
	}

	.details-bottomviewimg {
		width: 46upx;
		height: 36upx;
		margin-right: 10upx;
	}

	.details-h5 {
		width: 690upx;
		margin-top: 70upx;
		display: -webkit-flex;
		align-items: center;
		font-size: 29upx;
		font-weight: bold;
		color: #5E068C;
		opacity: 1;
	}

	.details-h5img {
		width: 6upx;
		height: 31upx;
		position: relative;
		margin-right: 7upx;
	}

	.details-h5v {
		width: 690upx;
		margin-top: 42upx;
		background: #FAFAFA;
		min-height: 30upx;
		padding: 30upx;
	}

	.details-h5smtext {
		font-size: 18upx;
		color: #9E9E9E;
		opacity: 1;
		margin-left: 20upx;
	}

	.details-dd {
		width: 690upx;
		height: 1upx;
	}

	.details-ddview {
		width: 345upx;
		border-bottom: 1upx dotted #000000;
	}

	.details-bvs {
		width: 690upx;
		font-size: 24upx;
		font-weight: 400;
		color: #B9B9B9;
		opacity: 1;
	}

	.details-ewm {
		width: 690upx;
		display: flex;
	}

	.details-ewmitem {
		overflow: hidden;
		text-align: center;
		margin-right: 40upx;
	}

	.details-ewmimg {
		width: 92upx;
		height: 92upx;
	}

	.details-ewmview {
		color: #B9B9B9;
		font-size: 21upx;
		margin-top: 7upx;
	}

	.details-endlogo {
		width: 690upx;
		height: 63upx;
	}

	.details-endlogoimg {
		width: 208upx;
		height: 63upx;
	}
</style>
