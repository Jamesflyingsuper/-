<template>
	<view class="content">
		<cu-custom bgColor="bg-white" :isBack="true">
		    <block slot="content"><text style="font-weight: bold; color: #000000;">合作伙伴</text></block>
		</cu-custom>
		<!-- 引流&收益统计 -->
		<view class="modul-comin">
			<view class="m-title">
				<view class="m-title-text">引流&收益统计</view>
				<view class="m-title-download" @click="downImg('https://keyanpro.com/img/4partner.png')">下载宣传单</view>
			</view>
			<view class="m-count">
				<view class="m-count-item">
					<view class="count-item-title">今日引流收益(元)</view>
					<text class="gold count-num">{{cData.today_money || 0}}</text>
				</view>
				<view class="m-count-item">
					<view class="count-item-title">累计引流收益(元)</view>
					<text class="gold count-num">{{cData.drainage_money || 0}}</text>
				</view>
				<view class="m-count-item">
					<view class="count-item-title">累计收益(元)</view>
					<text class="gold count-num">{{cData.all_money || 0}}</text>
				</view>
			</view>
			<view class="m-count">
				<view class="m-count-item">
					<view class="count-item-title">今日引流(人)</view>
					<text class="count-num">{{cData.today_num || 0}}</text>
				</view>
				<view class="m-count-item">
					<view class="count-item-title">累计引流(人)</view>
					<text class="count-num">{{cData.all_num || 0}}</text>
				</view>
				<view class="m-count-item">
					<view class="count-item-title">累计支付(人)</view>
					<text class="count-num">{{cData.all_pay || 0}}</text>
				</view>
			</view>
		</view>
		<view class="split-block"></view>
		<!-- 折线统计图 -->
		<view class="modul-comin">
			<view class="m-title">
				<view class="m-title-text">引流&付费量走势</view>
			</view>
			<view class="charts" >
				<canvas v-show="modalName!='Modal'" class="qiun-charts" canvas-id="canvasLineA" id="canvasLineA"  @touchstart="touchLineA"></canvas>
			</view>
		</view>
		<view class="split-block"></view>
		<!-- 地步提现信息 -->
		<view class="modul-comin margin-btn">
			<view class="m-title">
				<view class="m-title-text">提现</view>
				<view class="m-title-download" @click="toRecord">提现记录</view>
			</view>
			
			<view class="m-count">
				<view class="m-count-item">
					<view class="count-item-title">剩余可提现额度(元)</view>
					<text class="gold bigger-font count-num">{{cData.now_money || 0}}</text>
				</view>
			</view>
		</view>
		<view class="cu-modal" :class="modalName=='Modal'?'show':''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">提现</view>
					<view class="action" @tap="hideModal">
						<text class="cuIcon-close text-gray"></text>
					</view>
				</view>
				<view class="cu-form-group">
					<view class="title">提现金额</view>
					<input style="text-align: left;" v-model="money" placeholder="请输入提现金额" name="input"></input>
					<view class="cu-capsule radius">
						<view class="cu-tag line-purple">
							最高800
						</view>
					</view>
				</view>
				
				<view style="height: 20upx;"></view>
				<view class="cu-bar bg-purple">
					<view class="action margin-0 flex-sub  solid-left" @click="bind()">提现</view>
				</view>
			</view>
		</view>
		<view class="split-block"></view>
		<!-- 提现按钮 -->
		<view class="btn-tixian" @click="reply">
			立即提现
		</view>
	</view>
</template>

<script>
	Date.prototype.format = function(fmt)
	{ 
	　　var o = {
	　　　　"M+" : this.getMonth()+1, //月份
	　　　　"d+" : this.getDate(), //日
	　　　　"h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时
	　　　　"H+" : this.getHours(), //小时
	　　　　"m+" : this.getMinutes(), //分
	　　　　"s+" : this.getSeconds(), //秒
	　　　　"q+" : Math.floor((this.getMonth()+3)/3), //季度
	　　　　"S" : this.getMilliseconds() //毫秒
	　　};
	　　if(/(y+)/.test(fmt))
	　　　　fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
	　　for(var k in o)
	　　　　if(new RegExp("("+ k +")").test(fmt))
	　　fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
	　　return fmt;
	} 
	import uCharts from '@/components/js_sdk/u-charts/u-charts.js'
	import { Cooperation,reply } from '@/api/index.js'
	var _self;
	var canvaLineA=null;
	export default {
		data() {
			return {
				modalName:'',
				money:0,
				cData: {},
				cWidth: '',
				cHeight: '',
				pixelRatio: 1,
				serverData: '',
				title: 'Hello'
			}
		},
		onLoad() {
			_self = this;
			// uni.upx2px(750) 这是uni-app自带的自适应，以750的尺寸为基准。动态变化
			this.cWidth=uni.upx2px(750);
			this.cHeight=uni.upx2px(500);
			this.getData()
		},
		methods: {
			downImg(url){
			   const that = this;
				console.log("url",url)
			    uni.downloadFile({
			        url:url,//url为图片地址
			        success: res => {
						console.log("下载结果res",res)
			            if (res.statusCode === 200) {
			                uni.saveImageToPhotosAlbum({
			                    filePath: res.tempFilePath,
			                    success: function() {
			                        uni.showToast({
			                       		title:'保存成功'
			                       	})
			                    },
			                    fail: function() {
									uni.showToast({
										title:'保存失败，请稍后重试'
									})
			                    }
			                });
			            } else {
							uni.showToast({
								title:'保存失败，请稍后重试'
							})
			            }
			        }
			    });
			},
			bind(){
				
				if (isNaN(this.money)){
					uni.showToast({
						title:'提现金额必须是数字',
						icon:'none'
					})
					return false;
				}
				if (this.money<=0){
					uni.showToast({
						title:'金额必须大于0元',
						icon:'none'
					})
					return false;
				}
				if (this.money>800){
					uni.showToast({
						title:'最高提现金额为800元',
						icon:'none'
					})
					return false;
				}
				var uid = uni.getStorageSync('user_id');
				let that = this
				reply({
					user_id:uid,
					money: this.money
				}).then(res=>{
					if(res.data.code == 1 && res.data.data.money == that.cData.now_money) {
						uni.showToast({
							title: '申请成功',
							icon:'none'
						})
						this.modalName = ''
					}
				})
			},
			hideModal(){
				this.modalName = ''
			},
			reply(){
				this.modalName = 'Modal'
				
				
			},
			toRecord(){
				uni.navigateTo({
					url: '../cashOut/cashOut'
				})
			},
			// 获取X轴
			getXData(){
				let current = new Date()
				let arr = []
				arr.push(this.getStrDate(current)) // 1
				current = new Date()
				current.setDate(current.getDate()-1)
				arr.push(this.getStrDate(current)) // 2
				current = new Date()
				current.setDate(current.getDate()-2)
				arr.push(this.getStrDate(current)) // 3
				current = new Date()
				current.setDate(current.getDate()-3)
				arr.push(this.getStrDate(current))
				current = new Date()
				current.setDate(current.getDate()-4)
				arr.push(this.getStrDate(current))
				current = new Date()
				current.setDate(current.getDate()-5)
				arr.push(this.getStrDate(current))
				current = new Date()
				current.setDate(current.getDate()-6)
				arr.push(this.getStrDate(current))
				current = new Date()
				current.setDate(current.getDate()-7)
				arr.push(this.getStrDate(current))
				current = new Date()
				current.setDate(current.getDate()-8)
				arr.push(this.getStrDate(current))
				current = new Date()
				current.setDate(current.getDate()-9)
				arr.push(this.getStrDate(current))
				console.log('nitamade',arr)
				arr = arr.reverse()
				return arr
			},
			getStrDate(date){
				return date.format('MM/dd')
			},
			getData(){
				var uid = uni.getStorageSync('user_id');
				Cooperation({user_id:uid}).then(res=>{
					console.log(res)
					if(res.data && res.data.code == 1 && res.data.data) {
						let result = res.data.data
						this.cData = result
						let LineA={categories:[],series:[]};
						let xArr = this.getXData()
 						let categories = xArr
						LineA.categories=categories;
						let yinliuData = []
						let fufeiData = []
						let sery1 = {name:'引流量',data:[]}
						let sery2 = {name:'付费量',data:[]}
						if(result.Discharge){
							let yinliuObj = result.Discharge
							yinliuData.push(yinliuObj.one.num || 0)
							yinliuData.push(yinliuObj.two.num || 0)
							yinliuData.push(yinliuObj.three.num || 0)
							yinliuData.push(yinliuObj.four.num || 0)
							yinliuData.push(yinliuObj.five.num || 0)
							yinliuData.push(yinliuObj.six.num || 0)
							yinliuData.push(yinliuObj.seven.num || 0)
							yinliuData.push(yinliuObj.eight.num || 0)
							yinliuData.push(yinliuObj.nine.num || 0)
							yinliuData.push(yinliuObj.ten.num || 0)
						}
						if(result.Payment){
							let fufeiObj = result.Payment
							fufeiData.push(fufeiObj.one.num || 0)
							fufeiData.push(fufeiObj.two.num || 0)
							fufeiData.push(fufeiObj.three.num || 0)
							fufeiData.push(fufeiObj.four.num || 0)
							fufeiData.push(fufeiObj.five.num || 0)
							fufeiData.push(fufeiObj.six.num || 0)
							fufeiData.push(fufeiObj.seven.num || 0)
							fufeiData.push(fufeiObj.eight.num || 0)
							fufeiData.push(fufeiObj.nine.num || 0)
							fufeiData.push(fufeiObj.ten.num || 0)
						}
						// 赋值 Y的数据
						sery1.data = yinliuData.reverse()
						sery2.data = fufeiData.reverse()
						LineA.series=[sery1,sery2];
						// 根据其中的最大值来判断坐标轴Y的分割范围
						let arrNums = [...yinliuData,...fufeiData]
						let max = Math.max(...arrNums)
						
						if(max > 10){
							max = 10
						} else if(max == 0) {
							max = 1
						}
						// 找到id为canvasLineA的块
						_self.showLineA("canvasLineA",LineA,max);
					}
					
				})
			},
			
			showLineA(canvasId,chartData,splitNum){
				canvaLineA=new uCharts({
					$this:_self,
					context:uni.createCanvasContext(canvasId, _self),
					// 图标类型
					type: 'line',
					fontSize:11,
					legend:{show:true},
					dataLabel:false,
					dataPointShape:true,
					background:'#FFFFFF',
					pixelRatio:_self.pixelRatio,
					categories: chartData.categories,
					series: chartData.series,
					animation: true,
					// x轴显示的内容
					xAxis: {
						type:'grid',
						gridColor:'#CCCCCC',
						gridType:'dash',
						dashLength:8
					},
					// y轴显示的内容
					yAxis: {
						gridType:'dash',
						gridColor:'#CCCCCC',
						dashLength:8,
						splitNumber:splitNum,
						format:(val)=>{return val.toFixed(0)+'元'}
					},
					width: _self.cWidth*_self.pixelRatio,
					height: _self.cHeight*_self.pixelRatio,
					extra: {
						line:{
							type: 'straight'
						}
					}
				});
				
			},
			// 点击图表显示的内容
			touchLineA(e) {
				// 使用声明的变量canvaLineA
				canvaLineA.showToolTip(e, {
					format: function (item, category) {
						return category + ' ' + item.name + ':' + item.data 
					}
				});
			}
		}
	}
</script>

<style>
	.modul-comin {
		width: 95%;
		margin: 10rpx 15rpx !important;
		
	}
	.m-title{
		height: 100rpx;
		line-height: 100rpx;
		display: flex;
	}
	.m-title-text{
		flex: 1;
	}
	.m-title-download{
		font-size: 20rpx;
		color: gray;
	}
	.m-count{
		width: 100%;
		display: flex;
	}
	.m-count-item{
		margin-top: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		flex:1;
	}
	.count-item-title{
		font-size: 20rpx;
	}
	.count-num{
		height: 80rpx;
		line-height: 80rpx;
		font-size: 2em;
	}
	.gold {
		color: #F0AD4E;
	}
	/*样式的width和height一定要与定义的cWidth和cHeight相对应*/
		.qiun-charts {
			width: 750upx;
			height: 500upx;
			background-color: #FFFFFF;
		}
		
		.charts {
			width: 750upx;
			height: 500upx;
			background-color: #FFFFFF;
		}
	.btn-tixian{
		position: fixed;
		bottom: 0;
		left: 0;
		background-color: #F0AD4E;
		text-align: center;
		width: 100vw;
		height: 80rpx;
		line-height: 80rpx;
	}
	.split-block {
		width: 100vw;
		height: 10rpx;
		background-color: rgb(248, 248, 248);
	}
	.margin-btn{
		padding-bottom: 85rpx !important;
	}
	.bigger-font{
		font-size: 3em;
		font-weight: 600;
	}
</style>
