<template name="home">
    <view>
        <cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
            <block slot="content"><text style="font-weight: bold; color: #000000;">近期浏览</text></block>
        </cu-custom>
        <view style="height: 21upx;"></view>
        <!-- <view class="nvascr">
            <scroll-view class="nvascrview" scroll-x="true">
                <view v-for="(item,index) in titlenav" @click="NavChange1" class="nvascrtext" :data-cur="index"
                    :class="PageCur1==index?'curtext':''">
                    {{item}}
                </view>
            </scroll-view>
        </view> -->
        <scroll-view scroll-y class="home-list" :style="[Style]" @scrolltolower="scroll" scroll-y="true">
            <!-- <view style="height: 56upx;"></view> -->
            <view class="home-3list1s">
                <view v-if="item.type ==1 && item.title != null" class="home-3list2itemss" @click="goto1(item.title_id)" v-for="(item,index) in list">
                    <view class="home-3name">
                        {{item.title}}
                    </view>
                    <view class="home-3dizhi">
                        <view class="home-3dizhit1" style="color: #5E068C; font-weight: bold;">申报指南</view>
                       
                        <text class="home-3dizhit2">{{time(item.read_time)}}</text>
                        <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                    </view>
                    <view style="height: 10upx;"></view>
                </view>
                <view  v-if="item.type ==2 && item.title != null" class="home-3list2itemss" @click="goto2(item.title_id)" v-for="(item,index) in list">
                    <view class="home-3name">
                        {{item.title}}
                    </view>
                    <view class="home-3dizhi">
                        <view class="home-3dizhit1" style="color: #5E068C; font-weight: bold;">政采招标</view>
                        <text class="home-3dizhit2">{{time(item.read_time)}}</text>
                        <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                    </view>
                    <view style="height: 10upx;"></view>
                </view>
                <view  v-if="item.type ==3 && item.title != null" class="home-3list2itemss" @click="goto3(item.title_id)" v-for="(item,index) in list">
                    <view class="home-3name">
                        {{item.title}}
                    </view>
                    <view class="home-3dizhi">
                        <view class="home-3dizhit1" style="color: #5E068C; font-weight: bold;">科研项目</view>
                        <text class="home-3dizhit2">{{time(item.read_time)}}</text>
                        <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                    </view>
                    <view style="height: 10upx;"></view>
                </view>
                <view  v-if="item.type ==4 && item.title != null" class="home-3list2itemss" @click="goto4(item.title_id)" v-for="(item,index) in list">
                    <view class="home-3name">
                        {{item.title}}
                    </view>
                    <view class="home-3dizhi">
                        <view class="home-3dizhit1" style="color: #5E068C; font-weight: bold;">深度文章</view>
                        <text class="home-3dizhit2">{{time(item.read_time)}}</text>
                        <image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png"></image>
                    </view>
                    <view style="height: 10upx;"></view>
                </view>
            </view>
            <!-- <view class="listend">— 内容太多，试试搜索功能吧 —</view> -->
        </scroll-view>
    </view>
</template>

<script>
    export default {
        name: "home",
        data() {
            return {
                CustomBar: this.CustomBar,
                ispop: 0,
                titlenav: ['项目指南', '政采招标', '科研项目', '深度文章'],
                titles: '搜索结果',
                PageCur1: 0,
                picker: ['相关度', '相关技术'],
                index: 0,
                list: [],
                page: 1,
                user_id: uni.getStorageSync('user_id'),
                title: ''
            };
        },
        onLoad() {
            var that = this;
            that.listp();
        },
        computed: {
            Style() {
                let obj = {
                    "height": `calc((100vh - 21rpx) - ${this.CustomBar}px)`,
                }
                return obj
            }
        },
        methods: {
            scroll() {
                var that = this;
                // that.page++;
                // that.listp();
            },
            cpnclick(item) {
                var that = this;
                that.title = uni.getStorageSync('titipt');
                that.list = [];
                that.listp();
            },
            listp() {
                var that = this;
                this.$api.organlist({
                    user_id: that.user_id
                }).then((res) => {
                    for (var i = 0; i < res.data.data.length; i++) {
                        that.list.push(res.data.data[i])
                    }
                });
            },
            NavChange1: function(e) {
                var that = this;
                that.PageCur1 = e.currentTarget.dataset.cur;
                that.list = [];
                that.page = 1;
                that.listp();
            },
            resultConditon(obj) {
                this.ispop = 0;
                this.$refs.condition.visibleDrawer = false;
                this.hasChoose = obj.hasChoose;
                this.custom1s = obj.str_result.custom1;
                this.custom2s = obj.str_result.custom2;
                this.custom3s = obj.str_result.custom3;
            },
            orderbyChange(obj) {
                this.ispop = 1;
                this.$refs.condition.visibleDrawer = true;
            },
            goto1(e) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                	uni.showToast({
                		title: '请先登录',
                		icon: 'none'
                	});
                	return;
                }
                this.$api.vipprojectGov({
                	id: uid
                }).then((res) => {
                	if (res.data.data == 0) {
                		uni.navigateTo({
                			url: '/pages/my/myts'
                		})
                		return;
                	} else {
                		uni.navigateTo({
                			url: '/pages/home/zndetails?id=' + e
                		})
                	}
                });
            },
            goto2(e) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                	uni.showToast({
                		title: '请先登录',
                		icon: 'none'
                	});
                	return;
                }
                this.$api.viptender({
                	id: uid
                }).then((res) => {
                	if (res.data.data == 0) {
                		uni.navigateTo({
                			url: '/pages/my/myts'
                		})
                		return;
                	} else {
                		uni.navigateTo({
                			url: '/pages/home/zsdetails?id=' + e
                		})
                	}
                });
            },
            goto3(e) {
                var uid = uni.getStorageSync('user_id');
                if (uid == '') {
                    uni.showToast({
                        title:'请先登录',
                        icon:'none'
                    });
                    return;
                }
                this.$api.vipproject({
                	id: uid
                }).then((res) => {
                	if (res.data.data == 0) {
                		uni.navigateTo({
                			url: '/pages/my/myts'
                		})
                		return;
                	} else {
                		uni.navigateTo({
                		    url: '/pages/home/kydetails?id='+e
                		})
                	}
                });
            },
            goto4(e) {
                uni.navigateTo({
                    url: '/pages/home/details3?id='+e
                })
            },
            PickerChange(e) {
                this.index = e.detail.value
            },
            time(t) {
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var time = timestamp - t;
                var days = time / 86400;
                var hours = days / 3600;
                var mins = hours / 60;
                if (mins * 311040000 < 60 && mins * 311040000 > 0) {
                    return Math.floor(mins * 311040000) + '分钟前';
                }
                if (hours * 86400 < 24 && hours * 86400 > 0) {
                    return Math.floor(hours * 86400) + '小时前';
                }
                if (days < 30 && days > 0) {
                    return Math.floor(days) + '天前';
                }
                if (days < 365 && days > 0) {
                    return Math.floor(days / 30) + '月前';
                }
                if (days > 365 && days > 0) {
                    return Math.floor(days / 365) + '年前';
                }
            },
            time2(t) {
                var that = this;
                var timestamp = Math.floor((new Date()).getTime() / 1000);
                var times = t - timestamp;
                return times
            },
            keyword2(a) {
                if (a != null) {
                    var arr = a.split(';');
                    if (arr != undefined) {
                        return arr;
                    } else {
                        return a;
                    }
                } else {
                    return '';
                }
            },
            img(a) {
                var url = 'https://keyanpro.com/' + a;
                return url;
            }
        }

    }
</script>

<style>
    .home-list {
        width: 690upx;
        margin-left: 30upx;
    }

    .home-3list1s {
        opacity: 1;
    }

    .home-3list2 {
        /* margin-top: 56upx; */
    }

    .home-3name {
        font-size: 32upx;
        font-weight: bold;
        color: #121212;
        opacity: 1;
        position: relative;
        line-height: 47upx;
		max-height: 94upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
    }

    .home-3nameicon {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #5E068C;
        opacity: 1;
        border: 1upx solid #5E068C;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3nameicon2 {
        font-size: 21upx;
        font-weight: 400;
        position: relative;
        top: -5upx;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
        padding-top: 3upx;
        padding-bottom: 3upx;
        padding-left: 8upx;
        padding-right: 8upx;
        margin-right: 10upx;
    }

    .home-3list2itemss {
        margin-bottom: 33upx;
    }

    .home-3dizhi {
        width: 690upx;
        height: 30upx;
        position: relative;
        margin-top: 38upx;
    }

    .home-3dizhit1 {
        width: 530upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }

    .home-3dizhiimg {
        width: 19upx;
        height: 19upx;
        float: right;
        position: relative;
        top: 4.5upx;
        margin-right: 8upx;
    }

    .home-3dizhit2 {
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        opacity: 1;
        float: right;
    }

    .home-3tubiao {
        margin-top: 38upx;
        width: 690upx;
        position: relative;
        height: 40upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
    }

    .home-3tubiaoicon {
        font-size: 20upx;
        font-weight: 400;
        line-height: 40upx;
        position: relative;
        color: #990263;
        opacity: 1;
        border: 1upx solid #990263;
        border-radius: 1upx;
/*        padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }

    .home-3tubiaoicon2 {
        font-size: 20upx;
        line-height: 40upx;
        font-weight: 400;
        position: relative;
        color: #9E9E9E;
        opacity: 1;
        border: 1upx solid #9E9E9E;
        border-radius: 1upx;
/*        padding-top: 7upx;
        padding-bottom: 7upx; */
        padding-left: 15upx;
        padding-right: 15upx;
        margin-right: 14upx;
    }

    .nvascr {
        width: 750upx;
        height: 56upx;
        position: relative;
        display: flex;
    }

    .nvascrview {
        width: 690upx;
        height: 56upx;
        margin-left: 30upx;
        position: relative;
        white-space: nowrap;
    }

    .nvascrview2 {
        width: 650upx;
        height: 56upx;
        margin-left: 30upx;
        position: relative;
        /* display: flex; */
    }

    .nvascrviewbtn {
        margin-top: 13upx;
        height: 30upx;
        margin-right: 15upx;
        color: #5E068C;
        opacity: 1;
        float: left;
    }

    .nvascrtext {
        padding: 0;
        text-align: center;
        width: 25%;
        display: inline-block;
        font-size: 24upx;
        font-weight: 400;
        line-height: 58upx;
        color: #999999;
        opacity: 1;
    }

    .nvascricon {
        width: 70upx;
        height: 56upx;
    }

    .nvascriconimg {
        width: 28upx;
        height: 28upx;
        position: relative;
        left: 21upx;
        top: 14upx;
    }

    .nvascrviewimg {
        width: 24upx;
        height: 24upx;
        margin-right: 13upx;
    }

    .nvascrviewtext {
        font-weight: bold;
        font-size: 24upx;
        line-height: 24upx;
        position: relative;
        top: -4upx;
    }

    .nvascrviewtext2 {
        font-size: 24upx;
        line-height: 24upx;
        position: relative;
        top: -4upx;
    }

    .nvascrviewtz {
        float: right;
        margin-top: 13upx;
        height: 30upx;
        margin-right: 15upx;
        color: #999999;
        opacity: 1;
    }

    .curtext {
        font-weight: bold;
        color: #5E068C;
        text-align: center;
    }

    .nvascrxl {
        float: right;
        position: absolute;
        height: 56upx;
        line-height: 56upx;
        display: flex;
        text-align: right;
        right: 25upx;
    }

    .nvascrtextss {
        font-size: 24upx;
        font-weight: 500;
        color: #666666;
        opacity: 1;
    }

    .home-3dizhit3 {
        width: 340upx;
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #666666;
        margin-right: 10upx;
        opacity: 1;
        float: left;
        margin: 0;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
    }

    .home-3dizhit4 {
        width: 340upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #9E9E9E;
        opacity: 1;
        float: right;
    }
    
    .sdlist-list-item{
        width: 690upx;
        position: relative;
        overflow: hidden;
    }
    
    .sdlist-list-itemle{
        width: 483upx;
        float: left;
    }
    
    .sdlist-list-itemri{
        width: 174upx;
        float: right;
    }
    
    .sli-title{
        font-size: 32upx;
        font-weight: bold;
        line-height: 47upx;
        color: #121212;
        opacity: 1;
    }
    
    .sli-cons{
        margin-top: 18upx;
        font-size: 25upx;
        line-height: 42upx;
        color: #666666;
        opacity: 1;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
    }
    
    .sdlist-3dizhi {
        width: 690upx;
        height: 30upx;
        position: relative;
        margin-top: 35upx;
        float: left;
    }
    
    .sdlist-3dizhiimg {
        width: 19upx;
        height: 19upx;
        float: left;
        position: relative;
        top: 4.5upx;
        margin-right: 8upx;
    }
    
    .sdlist-3dizhit2 {
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #9E9E9E;
        opacity: 1;
        float: left;
    }
    
    .sdlist-3dizhit3 {
        height: 30upx;
        line-height: 30upx;
        font-size: 25upx;
        font-weight: 400;
        color: #9E9E9E;
        opacity: 1;
        float: right;
    }
    
    .sdlist-3dizhiimg2 {
        width: 18upx;
        height: 15upx;
        float: right;
        position: relative;
        top: 6.5upx;
        margin-right: 8upx;
    }
    
    .sli-image{
        width: 174upx;
        height: 174upx;
        border-radius: 20upx;
    }
</style>
