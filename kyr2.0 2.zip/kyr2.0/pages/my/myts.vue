<template>
    <view>
        <cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
            <block slot="content"><text style="font-weight: bold; color: #000000;">{{titles}}</text></block>
        </cu-custom>
        <view style="height: 194upx;"></view>
        <view style="text-align: center;">
            <image class="myte-img" src="https://keyanpro.com/kyrh/imageuni/my/tishinull.png"></image>
        </view>
        <view style="height: 100upx;"></view>
        <view class="myte-view">{{con}}</view>
        <view style="height: 120upx;"></view>
        <view class="subsrc-bottom" v-if="audit == 1">
            <view class="sb-view1" @click="buy()">付费升级</view>
            <view class="sb-view22" @click="fenxi()">
                <image class="sb-viewimg" src="https://keyanpro.com/kyrh/imageuni/weixin.png"></image>
                免费升级</view>
        </view>
    </view>
</template>

<script>
    export default {
        data() {
            return {
                titles:'友情提醒',
                con:'你的阅读量已超过限制，请升级您的权限',
				audit:0
            };
        },
        onShow() {
            var that = this;
            that.$api.audit({}).then((res) => {
            	that.audit = res.data.code
            });
        },
        methods: {
           buy(){
			   uni.navigateTo({
			       url: '/pages/my/myupvip'
			   })
		   },
		   fenxi(){
			   uni.navigateTo({
			       url: '/pages/my/myfx'
			   })
		   }
        }

    }
</script>

<style>
    .subsrc-bottom {
		border-top: 1upx solid rgba(0, 0, 0, 0.16);
        width: 750upx;
        height: 97upx;
        position: fixed;
        bottom: 0;
        left: 0;
        overflow: hidden;
    }
    
    .sb-view1 {
        width: 50%;
        height: 97upx;
        float: left;
        background: #FFFFFF;
        text-align: center;
        font-size: 36upx;
        font-weight: 500;
        line-height: 97upx;
        color: #121212;
        opacity: 1;
    }
    
    .sb-view22 {
        width: 50%;
        height: 97upx;
        float: right;
        background: #5E068C;
        text-align: center;
        font-size: 36upx;
        font-weight: 500;
        line-height: 97upx;
        color: #FFFFFF;
        opacity: 1;
        display:-webkit-flex;
        justify-content: center;
        align-items: center;
    }
    
    .sb-viewimg{
        width: 46upx;
        height: 36upx;
        margin-right: 16upx;
    }
    
    .myte-img{
        width: 445upx;
        height: 288upx;
    }
    
    .myte-view{
        width: 460upx;
        font-size: 32upx;
        font-weight: 400;
        line-height: 47upx;
        color: #990263;
        opacity: 1;
        margin: auto;
        text-align: center;
    }
</style>
