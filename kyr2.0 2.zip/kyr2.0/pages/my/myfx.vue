<template>
	<view>
		<cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
			<block slot="content"><text style="font-weight: bold; color: #000000;">{{titles}}</text></block>
		</cu-custom>
		<view style="height: 26upx;"></view>
		<view class="myfx-title">
			PRO会员权益
		</view>
		<view class="myfx-view1">
			<view style="height: 20upx;"></view>
			<view class="myfx-item">
				<image class="myfx-itemimg" src="https://keyanpro.com/kyrh/imageuni/my/myvip1.png"></image>
				<view class="myfx-itemview1">申报指南</view>
				<view class="myfx-itemview2">每日查看50条</view>
			</view>
			<view class="myfx-item">
				<image class="myfx-itemimg" src="https://keyanpro.com/kyrh/imageuni/my/myvip2.png"></image>
				<view class="myfx-itemview1">政采招标</view>
				<view class="myfx-itemview2">每日查看100条</view>
			</view>
			<view class="myfx-item">
				<image class="myfx-itemimg" src="https://keyanpro.com/kyrh/imageuni/my/myvip3.png"></image>
				<view class="myfx-itemview1">科研项目</view>
				<view class="myfx-itemview2">每日查看100条</view>
			</view>
			<view class="myfx-item">
				<image class="myfx-itemimg" src="https://keyanpro.com/kyrh/imageuni/my/myvip4.png"></image>
				<view class="myfx-itemview1">关键词订阅</view>
				<view class="myfx-itemview2">可订阅多达100组关键词</view>
			</view>
			<view class="myfx-item">
				<image class="myfx-itemimg" src="https://keyanpro.com/kyrh/imageuni/my/myvip5.png"></image>
				<view class="myfx-itemview1">机构订阅</view>
				<view class="myfx-itemview2">可订阅多达100家机构</view>
			</view>
		</view>
		<view style="height: 20upx;"></view>
		<view class="myfx-view2">
			<view class="myfx-view2title">
				<image class="myfx-view2img" src="https://keyanpro.com/kyrh/imageuni/my/myviplw.png"></image>
				<view class="myfx-view2t2">限时免费升级计划</view>
			</view>
			<view class="myfx-view2titlet">即日起，凡通过分享邀请新用户注册科研人小程序者，双方均可免费获取7天PRO会员资格，人数无限制，赠送天数可累加。</view>
			<button v-if="backs == 1 && codeImg != ''" @tap="showModal" data-target="bottomModal" class="myfx-view2btn cu-btn">发送邀请海报</button>
			<button v-if="backs == 1 && codeImg == ''" @tap="showModal" data-target="bottomModal" class="myfx-view3btn cu-btn">发送邀请海报</button>
			<button v-if="backs == 2 && codeImg != ''" @tap="showModal" data-target="bottomModal" class="myfx-view2btn cu-btn">发送邀请码</button>
			<button v-if="backs == 2 && codeImg == ''" @tap="showModal" data-target="bottomModal" class="myfx-view2btn cu-btn">发送邀请码</button>
		</view>
		<view style="height: 27upx;"></view>
		<view class="myfx-view3">
			TIPS：分享到朋友圈或科研群/论坛能获得更多机会哦，分享课题信息享受同等待遇~<view></view>
			*本活动限时有效，科研人保留最终解释权
		</view>
		<view class="myfx-view4">
			<view class="myfx-view41">机构会员</view>
			<view class="myfx-view42"><text style="font-size: 20upx; margin-right: 14upx;"
					class="cuIcon-playfill"></text>更低的人均价格，完整的PRO会员权限</view>
			<view class="myfx-view42"><text style="font-size: 20upx; margin-right: 14upx;"
					class="cuIcon-playfill"></text>单位IP地址识别，零限制使用</view>
			<view class="myfx-view42"><text style="font-size: 20upx; margin-right: 14upx;"
					class="cuIcon-playfill"></text>支持个性化定制开发，解锁更多分析功能</view>
			<view class="myfx-view43">添加客服了解详情，客服微信号keyanpro</view>
		</view>
		<view style="height: 120upx;"></view>
		<view v-if="audit == 1" class="subsrc-bottom" style="background: #FFFFFF;">
			<view class="sb-view1" @click="buy()">付费升级</view>
			<button v-if="codeImg != ''" @tap="showModal" data-target="bottomModal" class="sb-view22">
				<image class="sb-viewimg" src="https://keyanpro.com/kyrh/imageuni/weixin.png"></image>
				免费升级
			</button>
			<button v-if="codeImg == ''" class="sb-view23">
				<image class="sb-viewimg" src="https://keyanpro.com/kyrh/imageuni/weixin.png"></image>
				<text>加载中...</text>
			</button>
		</view>
		<view class="cu-modal bottom-modal" :class="modalName=='bottomModal'?'show':''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white">
					<view class="action text-green"></view>
					<view class="action text-gray cuIcon-close" @tap="hideModal"></view>
				</view>
				<view v-if="backs == 1" class="bg-white">
					<image class="fenxianghaibao1s" mode="aspectFit" :src="mhq(codeImg)"></image>
					<view class="fenxianghaibao12">保存图片后，可分享至朋友圈或好友</view>
					<button  @click="save()" class="fenxianghaibao13"><text style="margin-right: 13rpx;"
							class="cuIcon-down"></text>保存</button>
					<view style="height: 50upx;"></view>
				</view>
				<view class="bg-white" v-if="backs == 2">
					<canvas class="fenxianghaibao1" canvas-id="qrcode" :style="{width: `${qrcodeSize}px`, height: `${qrcodeSize}px`}" />
					<view class="fenxianghaibao12">保存二维码后，可分享至朋友圈或好友</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uQRCode from '@/components/uni-qrcode/uqrcode.js';
	export default {
		data() {
			return {
				titles: '分享得PRO会员',
				user_id: uni.getStorageSync('user_id'),
				modalName: null,
				nickName: uni.getStorageSync('nickName'),
				avatarUrl: 'https://keyanpro.com/kyrh/imageuni/my/h5logo.png',
				access_token: uni.getStorageSync('accesstoken'),
				codeImg:'',
				backs:2,
				qrcodeText: '',
				qrcodeSize: uni.upx2px(400),
				qrcodeSrc: '',
				wid:'',
				audit:0
			};
		},
		onShow() {
			console.log("success")
			var that = this;
			that.$api.audit({}).then((res) => {
				that.audit = res.data.code
			});
		},
		onLoad(e) {
			var that = this;
			// #ifdef H5
			that.backs = 2;
			var qrcodeText= 'https://keyanpro.com/?id=1&scene='+ that.user_id;
			uQRCode.make({
				canvasId: 'qrcode',
				text: qrcodeText,
				size: this.qrcodeSize,
				margin: 10
			}).then(res => {
				that.codeImg = res
			}).finally(() => {
			})
			// #endif	
			// #ifdef MP-WEIXIN
			that.backs = 1;
			that.$api.subscribeshareHai({
				id:that.user_id,
				user_name: that.nickName
			}).then((res) => {
				that.codeImg = res.data.data;
			});
			// #endif	
			
		},
		created() {
			var that = this;
		},
		onShareTimeline: function(e) {
			// 配置标题
			return {
				title: '科研人',
				path: '/pages/index/index',
				query: {
					type: 0,
					contentid: ''
				}
			}
		},
		onShareAppMessage: function(res) {
			var that = this;
			return {
				title: '科研人', // 分享名称
				path: '/pages/index/index',
				// imageUrl: '../../static/tabbar/home',
				success: function(shareTickets) {
					uni.showToast({
						title: "成功",
						icon: 'none',
						duration: 1000
					});
				},
				fail: function(res) {
					console.log(res + '失败');
				},
				complete: function(res) {
					console.log("发送的uidwei" + uid)
				}
			}
		},
		methods: {
			showModal(e) {
				if(this.codeImg != ''){
					this.modalName = e.currentTarget.dataset.target
				}else{
					uni.showToast({
						title: '加载中...',
						icon: 'none'
					})
				}
			},
			hideModal(e) {
				this.modalName = null
			},
			buy() {
				uni.navigateTo({
					url: '/pages/my/myupvip'
				})
			},
			fenxi() {
				uni.showToast({
					title: '请发送邀请海报',
					icon: 'none'
				})
			},
			save() {
				var that = this;
				uni.downloadFile({
						url: that.mhq(that.codeImg),
						success: (res) =>{
							if (res.statusCode === 200){
								uni.saveImageToPhotosAlbum({
									filePath: res.tempFilePath,
									success: function() {
										that.modalName = null
										uni.showModal({
											title:'图片已保存到系统相册',
											content:"快去分享给小伙伴们吧",
											showCancel:false
										})
									},
									fail: function() {
										uni.showToast({
											title: "保存失败，请稍后重试",
											icon: "none"
										});
									}
								});
							}
						}
					})
			},
			mhq(a){
				var url = 'https://keyanpro.com/' + a;
				console.log(url)
				return url;
			}
		}

	}
</script>

<style>
	.myfx-title {
		width: 690upx;
		margin: 30upx;
		font-size: 39upx;
		font-weight: bold;
		line-height: 39upx;
		color: #000000;
		opacity: 1;
	}

	.myfx-view1 {
		width: 690upx;
		margin: 0upx 30upx 0upx 30upx;
	}

	.myfx-item {
		width: 690upx;
		overflow: hidden;
		position: relative;
		margin-bottom: 42upx;
	}

	.myfx-itemimg {
		width: 56upx;
		height: 56upx;
		position: absolute;
		top: calc(50% - 28rpx);
	}

	.myfx-itemview1 {
		font-size: 26upx;
		font-weight: bold;
		position: relative;
		top: 2upx;
		line-height: 30upx;
		color: #090909;
		opacity: 1;
		margin-left: 85upx;
	}

	.myfx-itemview2 {
		font-size: 26upx;
		font-weight: 400;
		line-height: 30upx;
		color: #666666;
		opacity: 1;
		margin-top: 22upx;
		margin-left: 85upx;
	}

	.myfx-view2 {
		margin: auto;
		width: 690upx;
		background: #FFFAF2;
		border: 1upx solid #D6B470;
		opacity: 1;
		border-radius: 7upx;
		text-align: center;
	}

	.myfx-view2title {
		margin: 42upx 30upx 0 30upx;
		width: 630upx;
		display: flex;
		display: -webkit-flex;
		/* justify-content: center; */
		align-items: center;
	}

	.myfx-view2img {
		width: 29upx;
		height: 26upx;
		margin-right: 10upx;
	}

	.myfx-view2t2 {
		font-size: 28upx;
		font-weight: bold;
		line-height: 28upx;
		color: #C87F00;
		opacity: 1;
	}

	.myfx-view2titlet {
		width: 630upx;
		margin: 30upx 30upx 30upx 30upx;
		font-size: 26upx;
		font-weight: 400;
		line-height: 42upx;
		color: #CA963B;
		opacity: 1;
		text-align: left;
	}

	.myfx-view2btn {
		width: 388upx;
		height: 67upx;
		line-height: 67upx;
		text-align: center;
		background: linear-gradient(90deg, #FFCE86 0%, #FFBC76 100%);
		box-shadow: 0upx 2upx 4upx rgba(0, 0, 0, 0.16);
		opacity: 1;
		border-radius: 50upx;
		font-size: 31upx;
		font-weight: 400;
		color: #000000;
		opacity: 1;
		margin: auto;
		margin-bottom: 50upx;
	}

	.myfx-view3btn {
		width: 388upx;
		height: 67upx;
		line-height: 67upx;
		text-align: center;
		background: linear-gradient(90deg, #737373 0%, #797979 100%);
		box-shadow: 0upx 2upx 4upx rgba(0, 0, 0, 0.16);
		opacity: 1;
		border-radius: 50upx;
		font-size: 31upx;
		font-weight: 400;
		color: #ffffff;
		opacity: 1;
		margin: auto;
		margin-bottom: 50upx;
	}

	.myfx-view3 {
		width: 630upx;
		font-size: 22upx;
		font-family: Source Han Sans CN;
		font-weight: 400;
		line-height: 33upx;
		color: #666666;
		opacity: 1;
		margin: auto;
	}

	.subsrc-bottom {
		width: 750upx;
		border-top: 1upx solid rgba(0, 0, 0, 0.16);
		height: 97upx;
		position: fixed;
		bottom: 0;
		left: 0;
		overflow: hidden;
	}

	.sb-view1 {
		width: 50%;
		height: 97upx;
		float: left;
		background: #FFFFFF;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
		line-height: 97upx;
		color: #121212;
		opacity: 1;
	}

	.sb-view22 {
		width: 50%;
		height: 97upx;
		float: right;
		background: #5E068C;
		text-align: center;
		border-radius: 0;
		font-size: 36upx;
		font-weight: 500;
		line-height: 97upx;
		color: #FFFFFF;
		opacity: 1;
		display: -webkit-flex;
		justify-content: center;
		align-items: center;
	}

	.sb-view23 {
		width: 50%;
		height: 97upx;
		float: right;
		background: #9e9e9e;
		text-align: center;
		border-radius: 0;
		font-size: 36upx;
		font-weight: 500;
		line-height: 97upx;
		color: #FFFFFF;
		opacity: 1;
		display: -webkit-flex;
		justify-content: center;
		align-items: center;
	}
	.sb-viewimg {
		width: 46upx;
		height: 36upx;
		margin-right: 16upx;
	}

	.myfx-view4 {
		width: 690upx;
		margin: 30upx;
		background: #FAFAFA;
		overflow: hidden;
	}

	.myfx-view41 {
		font-size: 28upx;
		font-family: Source Han Sans CN;
		font-weight: bold;
		line-height: 28upx;
		color: #9702A3;
		opacity: 1;
		margin: 30upx;
	}

	.myfx-view42 {
		font-size: 26upx;
		font-family: Source Han Sans CN;
		font-weight: 400;
		line-height: 26upx;
		color: #666666;
		opacity: 1;
		margin: 30upx;
	}

	.myfx-view43 {
		font-size: 22upx;
		font-family: Source Han Sans CN;
		font-weight: 400;
		line-height: 22upx;
		color: #8D8D8D;
		opacity: 1;
		margin: 30upx;
	}
</style>
