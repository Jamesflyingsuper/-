<template name="my">
	<view>
		<view class="my-title">
			<cu-custom :isBack3="true">
			</cu-custom>
			<view style="height: 24upx;"></view>
			<view class="my-titles" v-if="uid!=''" :style="[{animation: 'show ' + (1*0.4) + 's 1'}]">
				<image :src="avatarUrl" class="my-titimg">
				</image>
				<view class="my-titview">{{nickName}}</view>
				<view class="my-tittext" v-if="level == 1">游客</view>
				<view class="my-tittext" v-if="level == 2">注册会员</view>
				<view class="my-tittext2" v-if="level == 3">
					<view class="my-tittext2-v1">PRO会员</view>
					<view class="my-tittext2-v2"><text style="color:#9E9E9E;">到期日：</text>{{formatDate(vip_time)}}</view>
					<!-- <view class="my-tittext2-v3">续费>></view> -->
				</view>
			</view>
			<view class="my-titles" v-if="uid==''" @click="login()">
				<image :src="avatarUrl" class="my-titimg">
				</image>
				<view class="my-titview">{{nickName}}</view>
			</view>
		</view>
		<view class="my-vip" v-if="audit == 1">
			<image class="my-vipimg" src="https://keyanpro.com/kyrh/imageuni/myvipbg.png"></image>
			<view class="my-vipview1">科研人会员</view>
			<view class="my-vipview2">加入会员发现更多科研机会</view>
			<button v-if="level != 3" class="cu-btn my-vipbtn" @click="govip()">立即开通</button>
			<button v-if="level == 3" class="cu-btn my-vipbtn" @click="govip()">续费</button>
		</view>
		<view style="height: 45upx;"></view>
		<view class="my-list">
			<view v-if="backs == 1 && boundPhone ==1" class="my-list-item" @tap="showModal" data-target="Modal">
				<button class="mltbtn"></button>
				<image class="my-list-img2s" src="../../static/tabbar/my_cur.png"></image>
				<view class="my-list-view">绑定手机号码</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
			<view class="my-list-item" @click="goto(1)">
				<image class="my-list-img1" src="https://keyanpro.com/kyrh/imageuni/my/myitem1.png"></image>
				<view class="my-list-view">分享得PRO会员</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
			<view v-if="backs == 1" class="my-list-item">
				<button class="mltbtn" open-type="contact"></button>
				<image class="my-list-img2" src="https://keyanpro.com/kyrh/imageuni/my/myitem2.png"></image>
				<view class="my-list-view">消息中心</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
			<view v-if="backs == 2" class="my-list-item" @click="goto(2)">
				<image class="my-list-img2" src="https://keyanpro.com/kyrh/imageuni/my/myitem2.png"></image>
				<view class="my-list-view">消息中心</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
			<view class="my-list-item" @click="goto(3)">
				<image class="my-list-img3" src="https://keyanpro.com/kyrh/imageuni/my/myitem3.png"></image>
				<view class="my-list-view">我的收藏</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
			<view class="my-list-item" @click="goto(4)">
				<image class="my-list-img4" src="https://keyanpro.com/kyrh/imageuni/my/myitem4.png"></image>
				<view class="my-list-view">近期浏览</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
			<view class="my-list-item" @click="goto(7)" v-if="distribution == 1">
				<image class="my-list-img4" src="../../static/img/my/partner.png"></image>
				<view class="my-list-view" style="color: #f19835;">合作伙伴</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
			<!-- <view v-if="backs == 1" class="my-list-item" @click="goto(6)">
				<image class="my-list-img5" src="https://keyanpro.com/kyrh/imageuni/my/myitem5.png"></image>
				<view class="my-list-view">退出小程序</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view> -->
			<view v-if="backs == 2" class="my-list-item" @click="goto(5)">
				<image class="my-list-img5" src="https://keyanpro.com/kyrh/imageuni/my/myitem5.png"></image>
				<view class="my-list-view">退出登录</view>
				<image class="my-list-back" src="https://keyanpro.com/kyrh/imageuni/my/myback.png"></image>
			</view>
		</view>
		<view style="text-align: center; margin-top: 70upx;">
			<image class="endlogo" src="https://keyanpro.com/kyrh/imageuni/my/kyrlogo.png"></image>
		</view>
		<view class="cu-modal" :class="modalName=='Modal'?'show':''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">绑定手机号码</view>
					<view class="action" @tap="hideModal">
						<text class="cuIcon-close text-gray"></text>
					</view>
				</view>
				<view class="cu-form-group">
					<view class="title">手机号码</view>
					<input style="text-align: left;" v-model="phone" placeholder="输入手机号码" name="input"></input>
					<view class="cu-capsule radius">
						<view class='cu-tag bg-purple '>
							+86
						</view>
						<view class="cu-tag line-purple">
							中国大陆
						</view>
					</view>
				</view>
				<view class="cu-form-group">
					<view class="title">验证码</view>
					<input style="text-align: left;" v-model="codes" placeholder="输入验证码" name="input"></input>
					<button v-show="show" class='cu-btn bg-purple shadow' @click="havedx()">验证码</button>
					<button v-show="!show" class='cu-btn bg-purple shadow' @click="havedx()">剩余{{count}}s</button>
				</view>
				<view class="cu-form-group" v-if="tfpwd == 1">
					<view class="title">密码设置</view>
					<input style="text-align: left;" v-model="user_pass" placeholder="请填写您的密码" type="password" name="input"></input>
				</view>
				<view style="height: 20upx;"></view>
				<view class="cu-bar bg-purple">
					<view class="action margin-0 flex-sub  solid-left" @click="bind()">绑定</view>
				</view>
			</view>
		</view>
		<view class="cu-tabbar-height"></view>
	</view>
</template>

<script>
	export default {
		name: "my",
		data() {
			return {
				nickName: '点击登录',
				avatarUrl: 'https://keyanpro.com/kyrh/imageuni/my/h5logo.png',
				code: '',
				uid: '',
				ulogin: '',
				level: 1,
				backs: 1,
				modalName: null,
				vip_time: '',
				phone: '',
				codes: '',
				count: '',
				user_pass:'',
				timer: null,
				show: true,
				boundPhone: 2,
				tfpwd:0,
				audit:0,
				distribution:0
			};
		},
		mounted() {
			var that = this;
			that.$api.audit({}).then((res) => {
				that.audit = res.data.code
			});
			var uid = uni.getStorageSync('user_id');
			if (uid != '') {
				that.uid = uid;
				that.$api.userpay({
					user_id: uid
				}).then((res) => {
					console.log('qingqiu ok')
					that.level = res.data.data.level;
					that.vip_time = res.data.data.vip_time;
					that.boundPhone = res.data.data.boundPhone;
					console.log('distribution',res.data.data.distribution)
					that.distribution = res.data.data.distribution
					// #ifdef MP-WEIXIN
					if (res.data.data.boundPhone == 1) {
						that.modalName = 'Modal'
					}
					// #endif	

				});
			}
			var level = uni.getStorageSync('level');
			if (level != '') {
				that.level = level;
			}
			// #ifdef H5
			that.backs = 2;
			var ulogin = uni.getStorageSync('user_login');
			if (ulogin != '') {
				that.nickName = ulogin;
			}
			// #endif	
			// #ifdef MP-WEIXIN
			that.backs = 1;
			var code = uni.getStorageSync('mycode');
			if (code != '') {
				that.code = code;
			}
			var nickName = uni.getStorageSync('nickName');
			if (nickName != '') {
				that.nickName = nickName;
			}
			var avatarUrl = uni.getStorageSync('avatarUrl');
			if (avatarUrl != '') {
				that.avatarUrl = avatarUrl;
			}
			// #endif	
		},
		methods: {
			isShow(){
				return new Date() > new Date('2022-01-18 15:08:00')
			},
			havedx() {
				var that = this;
				if (that.phone == '') {
					uni.showToast({
						title: '请输入手机号',
						icon: 'none'
					})
					return;
				}
				this.$api.passin({
					phone: that.phone
				}).then((res) => {
					that.tfpwd = res.data.data;
				});
				this.$api.aliyun({
					phone: that.phone
				}).then((res) => {
					console.log(res.data.msg)
				});
				const TIME_COUNT = 60;
				if (!this.timer) {
					this.count = TIME_COUNT;
					this.show = false;
					this.timer = setInterval(() => {
						if (this.count > 0 && this.count <= TIME_COUNT) {
							this.count--;
						} else {
							this.show = true;
							clearInterval(this.timer);
							this.timer = null;
						}
					}, 1000)
				}
			},
			showModal(e) {
				this.modalName = e.currentTarget.dataset.target
			},
			hideModal(e) {
				this.modalName = null
			},
			bind() {
				var that = this;
				if (that.phone.length < 10) {
					uni.showToast({
						title: '请输入手机号',
						icon: 'none'
					});
					return;
				}
				if (that.codes.length == '') {
					uni.showToast({
						title: '请输入验证码',
						icon: 'none'
					});
					return;
				}
				if (that.tfpwd == 1) {
					if (that.user_pass.length < 6) {
						uni.showToast({
							title: '请输入6位数密码',
							icon: 'none'
						});
						return;
					}
				}
				that.$api.boundPhone({
					id: uni.getStorageSync('user_id'),
					phone: that.phone,
					code: that.codes,
					user_pass:that.user_pass
				}).then((res) => {
					uni.showToast({
						title: res.data.msg,
						icon: 'none'
					});
					if(res.data.code == 1){
						uni.setStorageSync('user_id', res.data.data.id);
						uni.redirectTo({
							url: '/pages/index/index?&PageCur=my'
						});
					}
				});
			},
			goto(a) {
				var uid = uni.getStorageSync('user_id');
				if (uid == '') {
					uni.showToast({
						title: '请先登录',
						icon: 'none'
					});
					return;
				}
				switch (a) {
					case 1:
						uni.navigateTo({
							url: '/pages/my/myfx'
						})
						break;
					case 2:

						break;
					case 3:
						uni.navigateTo({
							url: '/pages/my/collectList'
						})
						break;
					case 4:
						uni.navigateTo({
							url: '/pages/my/history'
						})
						break;
					case 5:
						uni.setStorageSync('user_id', '');
						uni.setStorageSync('user_login', '');
						uni.redirectTo({
							url: '/pages/login/index'
						})
						break;
					case 6:
						uni.showToast({
							title: '轻轻期待',
							icon: 'none'
						})
						break;
					case 7:
						uni.navigateTo({
							url:'../friends/friends'
						})
						break;
					default:
						break;
				}
			},
			govip() {
				var uid = uni.getStorageSync('user_id');
				if (uid == '') {
					uni.showToast({
						title: '请先登录',
						icon: 'none'
					});
					return;
				}
				uni.navigateTo({
					url: '/pages/my/myupvip'
				})
			},
			login() {
				var that = this;
				// #ifdef MP-WEIXIN
				uni.redirectTo({
					url: '/pages/index/index?bag=' + 1 + '&PageCur=my'
				});
				// #endif	
				// #ifdef H5
				uni.redirectTo({
					url: '/pages/login/index'
				});
				// #endif	

			},
			formatDate(timestamp) {
				var date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				let y = date.getFullYear();
				let MM = date.getMonth() + 1;
				MM = MM < 10 ? ('0' + MM) : MM;
				let d = date.getDate();
				d = d < 10 ? ('0' + d) : d;
				let h = date.getHours();
				h = h < 10 ? ('0' + h) : h;
				let m = date.getMinutes();
				m = m < 10 ? ('0' + m) : m;
				let s = date.getSeconds();
				s = s < 10 ? ('0' + s) : s;
				return y + '-' + MM + '-' + d;
			}
		},
	}
</script>

<style>
	.my-title {
		width: 750upx;
		height: 444upx;
		background: linear-gradient(180deg, rgba(223, 223, 223, 1) 0%, rgba(248, 248, 248, 0) 100%);

		position: relative;
	}

	.my-titles {
		width: 690upx;
		margin-left: 30upx;
		position: relative;
		display: -webkit-flex;
		align-items: flex-end;
	}

	.my-titimg {
		width: 167upx;
		height: 167upx;
		border-radius: 50%;
	}

	.my-titview {
		width: 400upx;
		height: 40upx;
		font-size: 40upx;
		font-weight: 500;
		line-height: 40upx;
		color: #000000;
		opacity: 1;
		position: absolute;
		left: 198upx;
		top: 63upx;
	}

	.my-tittext {
		padding: 7upx 15upx 7upx 15upx;
		background: #999999;
		opacity: 1;
		border-radius: 21upx;
		color: #FFFFFF;
		font-size: 21upx;
		margin-left: 31upx;
	}

	.my-tittext2 {
		opacity: 1;
		margin-left: 31upx;
		display: -webkit-flex;
		align-items: center;
	}

	.my-tittext2-v1 {
		padding: 7upx 15upx 7upx 15upx;
		background: linear-gradient(90deg, #FFBD5C 0%, #FF8E18 100%);
		opacity: 1;
		border-radius: 21upx;
		color: #FFFFFF;
		font-size: 21upx;
	}

	.my-tittext2-v2 {
		font-size: 21upx;
		font-weight: 400;
		color: #990263;
		opacity: 1;
		margin-left: 20upx;
	}

	.my-tittext2-v3 {
		font-size: 21upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
		margin-left: 30upx;
	}

	.my-vip {
		width: 690upx;
		height: 115upx;
		margin-left: 30upx;
		position: relative;
	}

	.my-vipimg {
		width: 690upx;
		height: 115upx;
		position: absolute;
		left: 0;
		top: 0;
		z-index: 1;
	}

	.my-vipview1 {
		height: 31upx;
		font-size: 31upx;
		font-weight: 400;
		line-height: 40upx;
		color: #FFFFFF;
		opacity: 1;
		z-index: 2;
		position: absolute;
		left: 42upx;
		top: 24upx;
	}

	.my-vipview2 {
		height: 21upx;
		font-size: 21upx;
		font-weight: 400;
		line-height: 30upx;
		color: #ABABA9;
		opacity: 1;
		z-index: 2;
		position: absolute;
		left: 42upx;
		bottom: 24upx;
	}

	.my-vipbtn {
		width: 161upx;
		height: 67upx;
		background: linear-gradient(90deg, #FFCE86 0%, #FFBC76 100%);
		box-shadow: 0upx 2upx 4upx rgba(0, 0, 0, 0.16);
		opacity: 1;
		font-size: 31upx;
		border-radius: 42upx;
		color: #000000;
		position: absolute;
		right: 16upx;
		padding: 0;
		top: 24upx;
		z-index: 2;
	}

	.my-list {
		width: 690upx;
		margin: 30upx;
	}

	.my-list-item {
		width: 690upx;
		height: 60upx;
		margin-bottom: 30upx;
		position: relative;
	}

	.my-list-img1 {
		width: 31upx;
		height: 28upx;
		float: left;
		margin-top: 16upx;
	}

	.my-list-img2 {
		width: 31upx;
		height: 33upx;
		float: left;
		margin-top: 13.5upx;
	}

	.my-list-img2s {
		margin-right: 4upx;
		width: 28upx;
		height: 33upx;
		float: left;
		margin-top: 13.5upx;
	}

	.my-list-img3 {
		width: 31upx;
		height: 34upx;
		float: left;
		margin-top: 13upx;
	}

	.my-list-img4 {
		width: 31upx;
		height: 27upx;
		float: left;
		margin-top: 17.5upx;
	}

	.my-list-img5 {
		width: 31upx;
		height: 31upx;
		float: left;
		margin-top: 16upx;
	}

	.my-list-view {
		width: 300upx;
		height: 30upx;
		font-size: 30upx;
		font-weight: 400;
		line-height: 30upx;
		margin-top: 15upx;
		margin-left: 28upx;
		color: #000000;
		opacity: 1;
		float: left;
	}

	.my-list-back {
		width: 15upx;
		height: 28upx;
		float: right;
		margin-top: 16upx;
	}

	.endlogo {
		width: 216upx;
		height: 67upx;
	}

	.mltbtn {
		width: 100%;
		height: 100%;
		position: absolute;
		z-index: 1;
		background: none;
	}

	.mltbtn::after {
		border: none;
	}
	
	.cu-form-group .title {
		min-width: calc(4em + 15px);
	}
</style>
