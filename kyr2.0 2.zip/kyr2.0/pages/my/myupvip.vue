<template>
    <view>
        <cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
            <block slot="content"><text style="font-weight: bold; color: #000000;">{{titles}}</text></block>
        </cu-custom>
        <view style="height: 69upx;"></view>
        <view class="myvip-card">
            <view class="myvip-cardv1">全年订阅</view>
            <view class="myvip-cardv2">
                ￥ 598.00
            </view>
            <view class="myvip-cardv3">
                原价798，限时立减200元
            </view>
        </view>
        <view style="height: 69upx;"></view>
        <view class="myvip-card2"></view>
        <view class="myvip-card3">
            <view class="myvip-card3title">支付方式</view>
            <!-- <view class="myvip-card3item" @click="pays(1)">
                <image class="myvip-card3img1" src="https://keyanpro.com/kyrh/imageuni/my/zfb.png"></image>
                <view class="myvip-views">支付宝</view>
                <image v-if="pay==1" class="myvip-card3img2" src="https://keyanpro.com/kyrh/imageuni/my/yuanyuan1.png"></image>
                <image v-if="pay==2" class="myvip-card3img2" src="https://keyanpro.com/kyrh/imageuni/my/yuanyuan2.png"></image>
            </view> -->
            <view class="myvip-card3item" @click="pays()">
                <image class="myvip-card3img1" src="https://keyanpro.com/kyrh/imageuni/my/wx.png"></image>
                <view class="myvip-views">微信</view>
                <image class="myvip-card3img2" src="https://keyanpro.com/kyrh/imageuni/my/yuanyuan1.png"></image>
                <!-- <image v-if="pay==1" class="myvip-card3img2" src="https://keyanpro.com/kyrh/imageuni/my/yuanyuan2.png"></image> -->
            </view>
        </view>
        <view style="height: 39upx;"></view>
        <view class="myvip-card2"></view>
        <view class="myvip-card4">
            <view @click="tongyi(2)" v-if="ofcouse== 1" style="color: #B9B9B9;" class="cuIcon-roundcheckfill"></view>
            <view @click="tongyi(1)" v-if="ofcouse== 2" style="color: #02A9F1;" class="cuIcon-roundcheckfill"></view>
            <view class="myvip-card4t2">付款即同意<text @tap="showModal" data-target="Modal" style="color: #02A9F1;text-decoration: underline;">《科研人会员协议》</text>
            </view>
        </view>
        <view class="myvip-card5">
            如需发票，请添加客服索取，客服微信号keyanpro
        </view>
        <view class="cu-modal show" v-if="payh5== 2">
            <view style="width: 550upx;" class="cu-dialog">
                <view class="bg-img">
                    <view style="height: 20upx;"></view>
                    <tki-qrcode v-if="ifShow" cid="qrcode1" ref="qrcode" :val="val" :size="size" :unit="unit"
                        :background="background" :foreground="foreground" :pdground="pdground" :icon="icon"
                        :iconSize="iconsize" :lv="lv" :onval="onval" :loadMake="loadMake" :usingComponents="true" />
                    <view style="height: 20upx;"></view>
                </view>
                <view class="cu-bar bg-white">
                    <view class="action margin-0 flex-sub  solid-left" @tap="hideModal">关闭</view>
                </view>
            </view>
        </view>
        <view style="height: 100upx;"></view>
        <view class="myvip-bottom">
            <view class="myvip-bottomv1">订单金额：<text style="font-weight: bold;color:#990263;"> ￥ 598</text></view>
            <view class="myvip-bottomv2" @click="paymoney()">支付</view>
        </view>
		<view class="cu-modal" :class="modalName=='Modal'?'show':''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">科研人会员协议</view>
					<view class="action" @tap="hideModal1">
						<text class="cuIcon-close text-gray"></text>
					</view>
				</view>
				<view style="margin: 20upx; height: 70vh; overflow: auto; text-align: left;">
					<view class="mhqtst" style="color: #5d5d5d;">
						重要须知：科研人（www.keyanpro.com）在此特别提醒用户认真阅读本《科研人会员协议》。在接受本协议之前，请您仔细阅读本协议的全部内容。如果您不同意本协议的任意内容，或者无法准确理解本协议任何条款的含义，请不要进行确认及后续操作。如果您对本协议的条款有疑问的，请通过客服渠道进行询问，其将向您解释条款内容。除非您接受本《协议》条款，否则您无权使用本协议相关的支付服务。如您通过网络页面点击确认或以我们认可的其他方式选择接受本协议的，即表示您与科研人已达成本协议并接受本协议的全部约定内容。
						本《协议》是用户与北京思谋数字科技有限责任公司（下称"思谋数科"）之间关于用户使用思谋数科相关软件以及支付服务所订立的协议。本《协议》描述思谋数科与会员之间关于软件许可以及支付服务使用及相关方面的权利义务。"用户"或"您"是指通过思谋数科提供的会员支付服务的个人或单一实体。
					</view>
					<view class="mhqtst1">
						1. 支付服务条款的确认和接纳
					</view>
					<view class="mhqtst">
						1.1 思谋数科会员支付服务涉及到的思谋数科产品的所有权以及相关软件的知识产权归思谋数科所有。思谋数科所提供的支付服务将按照其支付服务条款和操作规则严格执行。
					</view>
					<view class="mhqtst">
						1.2 本服务的期限以您自行选择并支付相应服务费用的期限为准，您也可以在本服务的相应页面查询。
					</view>
					<view class="mhqtst1">
						2. 风险提示
					</view>
					<view class="mhqtst">
						2.1 在使用思谋数科提供的充值支付服务时，用户务必仔细确认自己的账号并仔细选择相关操作选项。若因为用户自身输入账号错误、操作不当或不了解充值计费方式等因素造成充错账号、错选支付种类等情形而损害自身权益的，思谋数科将不会作任何补偿或赔偿。
					</view>
					<view class="mhqtst">
						2.2 若用户以非法的方式，或未使用思谋数科所指定的支付方式进行支付，思谋数科不保证该充值顺利或者正确完成。若因此造成用户权益受损时，思谋数科不会作任何补偿或赔偿，思谋数科同时保留随时终止该用户账号资格及使用各项支付服务的权利。
					</view>
					<view class="mhqtst1">
						3. 会员支付服务的程序
					</view>
					<view class="mhqtst">
						3.1用户可通过各种已有和未来新增的渠道享受会员支付服务,具体包括但不限于：
					</view>
					<view class="mhqtst">
						3.1.1 用户通过付费形式开通一定计费周期的会员服务，计费周期包括但不限于月度、年度等，会员可在购买思谋数科提供的会员服务时，根据思谋数科平台上显示的计费周期自行选择所需服务期间，用户为开通会员服务而从其自有充值账户、与会员账号绑定的第三方支付账户、银行卡（以下统称“账户”）余额中扣除该计费周期所需费用；
					</view>
					<view class="mhqtst">
						3.1.2 其他思谋数科认可的支付方式等。
						思谋数科在此声明：思谋数科未授权任何第三方销售思谋数科会员或思谋数科增值服务，任何未经授权销售思谋数科会员或思谋数科增值服务的均属于非法销售，思谋数科有权追究其法律责任。
					</view>
					<view class="mhqtst">
						3.2 成为会员后，您的会员服务会实时到账，会员有权利不接受思谋数科的提供的会员服务，可申请取消会员支付服务，但不获得会员费用的退还。
					</view>
					<view class="mhqtst">
						3.3 思谋数科向会员提供的本服务均仅限于与会员在思谋数科平台（含www.keyanpro.com和微信i科研人小程序）使用，任何以恶意破解等非法手段将思谋数科提供的本服务于思谋数科平台分离的行为，均不属于本协议中约定的本服务，由此引起的一切法律后果均有行为人负责，思谋数科将依法追究行为人的法律责任。
					</view>
					<view class="mhqtst">
						3.4 思谋数科仅提供相关的网络支付服务，除此之外与相关网络支付服务有关的设备(如个人电脑、手机、及其他与接入互联网或移动网有关的装置)及所需的费用(如为接入互联网而支付的电话费及上网费、为使用移动网而支付的手机费)均应由用户自行负担。
					</view>
					<view class="mhqtst1">
						4. 服务变更、中断或终止
					</view>
					<view class="mhqtst">
						4.1 思谋数科可以随时变更服务或更新本协议的条款，但应在相关的页面上及时提示修改内容。修改后的服务协议一旦在页面上公布即代替原来的服务协议。用户可随时登录相关页面查阅最新支付服务协议。
					</view>
					<view class="mhqtst">
						4.2 如发生下列任何一种情形，思谋数科有权随时中断或终止向用户提供本协议项下的网络服务而无需通知用户：（1）用户提供的个人资料不真实；（2）用户违反本协议中规定的使用规则。
					</view>
					<view class="mhqtst">
						4.3 除前款所述情形外，思谋数科同时保留在不事先通知用户的情况下随时中断或终止部分或全部网络充值服务的权利，对于充值服务的中断或终止而造成的任何损失，思谋数科无需对用户或任何第三方承担任何责任。
					</view>
					<view class="mhqtst1">
						5. 会员支付服务的通知和公告办法
					</view>
					<view class="mhqtst">
						会员支付服务的通知和公告将通过以下形式之一或多种形式对会员发布：
					</view>
					<view class="mhqtst">
						5.1 思谋数科客户端软件；
					</view>
					<view class="mhqtst">
						5.2 EMAIL；
					</view>
					<view class="mhqtst">
						5.3 思谋数科主页的公告专栏；
					</view>
					<view class="mhqtst1">
						6、责任声明
					</view>
					<view class="mhqtst">
						6.1 如思谋数科的系统发生故障影响到会员支付服务的正常运行，思谋数科承诺在第一时间内与相关单位配合，及时处理进行修复。但用户因此而产生的经济损失，思谋数科和合作公司不承担责任。
					</view>
					<view class="mhqtst">
						6.2 使用会员功能涉及到互联网支付服务，可能会受到各个环节不稳定因素的影响，存在因不可抗力、计算机病毒、黑客攻击、系统不稳定、用户所在位置、用户关机以及其他任何网络、技术、通信线路等原因造成的支付服务中断或不能满足用户要求的风险，用户须明白并自行承担以上风险，思谋数科不承担任何责任，并不予以亦无法补偿。
					</view>
					<view class="mhqtst">
						6.3 用户明确同意使用思谋数科会员支付服务的风险由用户个人承担。思谋数科明确表示不提供任何类型的担保，不论是明确的或隐含的。思谋数科不担保支付服务一定能满足用户的要求，也不担保支付服务不会受中断，对支付服务的及时性、安全性、真实性、出错发生、无病毒、无疏忽或无技术瑕疵问题都不作担保。思谋数科拒绝提供任何担保，包括信息能否准确、及时、顺利地传送。用户理解并接受传输或通过思谋数科产品支付服务取得的任何信息资料取决于用户自己，并由其承担系统受损、资料丢失以及其它任何风险。
					</view>
					<view class="mhqtst">
						6.4 用户违反本《协议》或相关的支付服务条款的规定，导致或产生的任何第三方主张的任何索赔、要求或损失，包括合理的诉讼费用和律师费用，用户同意赔偿思谋数科与合作公司、关联公司，并使之免受损害。对此，思谋数科有权视用户的行为性质，采取包括但不限于中断使用许可、停止提供支付服务、限制使用、法律追究等措施。
					</view>
					<view class="mhqtst1">
						7、法律适用和管辖
					</view>
					<view class="mhqtst">
						7.1 本《协议》所定的任何条款的部分或全部无效者，不影响其它条款的效力。
					</view>
					<view class="mhqtst">
						7.2 本《协议》的解释、效力及纠纷的解决，适用于中华人民共和国法律。若用户和思谋数科之间发生任何纠纷或争议，首先应友好协商解决，协商不成的，用户在此完全同意将纠纷或争议提交思谋数科所在地法院管辖。
					</view>
				</view>
			</view>
		</view>
    </view>
</template>

<script>
    import tkiQrcode from '@/components/tki-qrcode/tki-qrcode.vue'
    export default {
        components: {
            tkiQrcode
        },
        data() {
            return {
                ifShow: true,
                val: '', // 要生成的二维码值
                size: 300, // 二维码大小
                unit: 'upx', // 单位
                background: '#ffffff', // 背景色
                foreground: '#000000', // 前景色
                pdground: '#000000', // 角标色
                icon: '', // 二维码图标
                iconsize: 40, // 二维码图标大小
                lv: 3, // 二维码容错级别 ， 一般不用设置，默认就行
                onval: true, // val值变化时自动重新生成二维码
                loadMake: true, // 组件加载完成后自动生成二维码
                titles: '升级PRO会员',
                modalName: null,
                pay: 1,
                ofcouse: 1,
                payh5: 1,
                user_id: uni.getStorageSync('user_id'),
            };
        },
        onShow() {
            console.log("success")
        },
        methods: {
            pays(a) {
                this.pay = a;
            },
            tongyi(a) {
                this.ofcouse = a;
            },
            showModal(e) {
                this.modalName = e.currentTarget.dataset.target
            },
            hideModal(e) {
                this.payh5 = 1
            },
			hideModal1(e) {
			    this.modalName = null
			},
            paymoney() {
                var that = this;
                if (that.ofcouse == 2) {
                    // #ifdef MP-WEIXIN
                    this.$api.smallpay({
                        user_id: that.user_id
                    }).then((res) => {
                        var timeStamp = res.data.data.timeStamp;
                        var nonceStr = res.data.data.nonceStr;
                        var package1 = res.data.data.package;
                        var signType = res.data.data.signType;
                        var paySign = res.data.data.paySign;
                        uni.requestPayment({
                            provider: 'wxpay',
                            timeStamp: timeStamp,
                            nonceStr: nonceStr,
                            package: package1,
                            signType: signType,
                            paySign: paySign,
                            success: function(res) {
                                uni.redirectTo({
                                    url: '/pages/index/index?PageCur=my'
                                })
                            },
                            fail: function(err) {

                            }
                        });
                    });
                    // #endif	

                    // #ifdef H5
                    this.$api.h5smallpay({
                        user_id: that.user_id
                    }).then((res) => {
                        if (res.data.code == 1) {
                            that.payh5 = 2;
                        }
                        var pays = res.data.data;
                        that.val = res.data.data;
                        console.log(pays)
                    });
                    // #endif	

                } else {
                    uni.showToast({
                        title: '请勾选科研人会员协议',
                        icon: 'none'
                    })
                }

            }
        }

    }
</script>

<style>
    .myvip-card {
        width: 690upx;
        margin: auto;
        background: #FFFAF2;
        border: 3upx solid #D6B470;
        box-shadow: 0upx 0upx 3upx #D5B370;
        opacity: 1;
        border-radius: 14upx;
        position: relative;
    }

    .myvip-cardv1 {
        position: absolute;
        font-size: 28upx;
        font-family: Source Han Sans CN;
        font-weight: bold;
        line-height: 28upx;
        color: #000000;
        opacity: 1;
        top: calc(50% - 14rpx);
        left: 42rpx;
    }

    .myvip-cardv2 {
        font-size: 47upx;
        font-weight: 400;
        line-height: 40upx;
        color: #CA963B;
        opacity: 1;
        padding-top: 30upx;
        text-align: right;
        margin-right: 42upx;
    }

    .myvip-cardv3 {
        font-size: 25upx;
        font-weight: 400;
        line-height: 40upx;
        color: #A3A09B;
        opacity: 1;
        text-align: right;
        margin-top: 14upx;
        padding-bottom: 20upx;
        margin-right: 42upx;
    }

    .myvip-card2 {
        width: 750upx;
        height: 14upx;
        background: #FAFAFA;
        opacity: 1;
    }

    .myvip-card3title {
        font-size: 28upx;
        font-weight: 500;
        line-height: 28upx;
        color: #000000;
        opacity: 1;
        margin: 42upx 30upx 68upx 30upx;
    }

    .myvip-card3item {
        width: 690upx;
        margin: 30upx;
        display: -webkit-flex;
        /* justify-content: center; */
        align-items: center;
    }

    .myvip-card3img1 {
        width: 72upx;
        height: 72upx;
    }

    .myvip-card3img2 {
        width: 39upx;
        height: 39upx;
    }

    .myvip-views {
        margin-left: 23upx;
        width: 556upx;
        color: #999999;
        font-size: 28upx;
    }

    .myvip-card4 {
        margin: 42upx 30upx 30upx 30upx;
        width: 690upx;
        display: -webkit-flex;
        align-items: center;
    }

    .myvip-card4t2 {
        font-size: 22upx;
        line-height: 22upx;
        color: #999999;
        opacity: 1;
        margin-left: 8upx;
    }

    .myvip-card5 {
        margin: 30upx 30upx 30upx 30upx;
        width: 690upx;
        font-size: 22upx;
        line-height: 22upx;
        font-family: Source Han Sans CN;
        font-weight: 400;
        color: #999999;
        opacity: 1;
    }

    .myvip-bottom {
		border-top: 1upx solid rgba(0, 0, 0, 0.16);
        width: 750upx;
        height: 100upx;
        position: fixed;
        bottom: 0;
        left: 0;
        display: flex;
    }

    .myvip-bottomv1 {
        width: 68%;
        background: #FFFFFF;
        line-height: 100upx;
        text-align: center;
        font-size: 36upx;
        color: #000000;
        opacity: 1;
    }

    .myvip-bottomv2 {
        width: 32%;
        background: #5E068C;
        line-height: 100upx;
        text-align: center;
        font-size: 36upx;
        font-weight: 500;
        color: #FFFFFF;
        opacity: 1;
    }
	
	.mhqtst{
		margin: 10upx;
		line-height: 50upx;
	}
	
	.mhqtst1{
		font-weight: bold;
		font-size: 30upx;
		margin-top: 30upx;
		margin-bottom: 30upx;
	}
</style>
