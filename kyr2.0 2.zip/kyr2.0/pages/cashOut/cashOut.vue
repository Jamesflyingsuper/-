<template>
	<view class="container">
		<cu-custom bgColor="bg-white" :isBack="true">
		    <block slot="content"><text style="font-weight: bold; color: #000000;">提现记录</text></block>
		</cu-custom>
		<view class="tui-wallet__box">
			<view class="tui-recharge__box" v-if="list.length > 0">
				
					<!-- <view v-for="(item,index) in list" :key="index"> -->
					<view :hover="false" v-for="(model,subIndex) in list" :key="subIndex">
						
						<view class="tui-records__item">
							<image v-if="model.pm==1" class="tui-icon" src="/static/img/my/tixian.png"></image>
							<image v-else class="tui-icon" src="/static/img/my/tixian.png"></image>
							<view>
								<view class="tui-title1">{{model.extractTypeName}}</view>
								<view class="tui-desc" v-if="model.statue==0">
									<view class="text-red">未提现</view>
								</view>
								<view class="tui-desc" v-if="model.statue==3">
									<view class="text-blue">已拒绝</view>
								</view>
								<view class="tui-desc" v-if="model.statue==1">
									<view class="text-green">提现成功</view>
								</view>
								<view class="tui-desc">{{new Date(model.time * 1000).format('yyyy-MM-dd HH:mm:ss')}}</view>
							</view>
							<view class="tui-right__box">
								<view class="tui-amount">
									-￥{{model.money}}
								</view>

								<view class="tui-desc">手续费: ￥{{0.00}}</view>
							</view>
						</view>
					</view>
					<!--加载loading-->
					<!-- <tui-loadmore v-if="loading" :index="3" type="red"></tui-loadmore>
					<tui-nomore v-if="!loadMore"></tui-nomore> -->
					<!--加载loading-->
					<!-- </view> -->
				</view>
				<view v-else class="no-data">
					暂无提现记录～
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	
	import { getRecord } from '@/api/index.js'
	Date.prototype.format = function(fmt)
	{ 
	　　var o = {
	　　　　"M+" : this.getMonth()+1, //月份
	　　　　"d+" : this.getDate(), //日
	　　　　"h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时
	　　　　"H+" : this.getHours(), //小时
	　　　　"m+" : this.getMinutes(), //分
	　　　　"s+" : this.getSeconds(), //秒
	　　　　"q+" : Math.floor((this.getMonth()+3)/3), //季度
	　　　　"S" : this.getMilliseconds() //毫秒
	　　};
	　　if(/(y+)/.test(fmt))
	　　　　fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
	　　for(var k in o)
	　　　　if(new RegExp("("+ k +")").test(fmt))
	　　fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
	　　return fmt;
	} 
	export default {
		data() {
			return {
				isShow: true,
				userInfo: {},
				tabs: ["全部", "收入", "支出", "提现记录"],
				currentTab: 0,
				loading: false,
				loadMore: true,
				list: [],
				// 提现
				shopId: null,
				withdrawal: 0.00,
				nowMoney: 0,
				current: 1,
				size: 10,
				type: 0,
				moneystat: {}
			}
		},
		onLoad() {
			let that = this
			that.getWalletList();
		},
		onShow() {
		},
		methods: {
			toggle() {
				this.isShow = !this.isShow
			},
			refresh() {
				this.loadMore = true;
				this.loadding = false
				this.list = [];
				this.current = 1;
			},
			change(e) {
				this.type = e.index
				this.refresh();
			},
			getUserInfo() {
				let that = this
				GetUserInfo().then(res => {
					that.isLogin = true;
					that.userInfo = res.data
				})
			},
			getMerchantUserBillMoneystat() {
				let that = this
				getMerchantUserBillMoneystat().then(res => {
					that.moneystat = res.data.data
				})
			},
			getWalletList() {
				var uid = uni.getStorageSync('user_id');
				getRecord({
					user_id:uid
				}).then(res=>{
					if(res.data && res.data.data) {
						this.list = res.data.data
					}
				})
			},
		},
		onPullDownRefresh() {
			let that = this;
			setTimeout(function() {
				uni.stopPullDownRefresh();
				that.refresh()
			}, 1000);
		},
		onReachBottom() {
			let that = this;
			if (that.loadMore) {
				that.current++;
				console.log(that.current)
				
			}
		},
		onNavigationBarButtonTap(e) {
			uni.navigateTo({
				url: './withdraw'
			})
		}
	}
</script>

<style>
	.no-data {
		color: gray;
		height: 200rpx;
		line-height: 200rpx;
		text-align: center;
		width: 100%;
	}
	.container {
		padding-bottom: 48rpx;
	}

	.tui-wallet__box {
		width: 100%;
		padding: 0 30rpx;
		box-sizing: border-box;
	}

	.tui-content__box {
		width: 100%;
		height: 360rpx;
		border-radius: 24rpx;
		padding: 0 30rpx;
		box-sizing: border-box;
		/* background: linear-gradient(90deg, rgb(255, 89, 38), rgb(229,77,66)); */
		background: #e54d42;
		position: relative;
		box-shadow: 0 3rpx 20rpx rgba(229, 77, 66, 0.2);
	}

	.tui-my__assets {
		width: 100%;
		color: #fff;
		font-size: 32rpx;
		font-weight: bold;
		padding: 30rpx 0;
		box-sizing: border-box;
		display: flex;
		align-items: center;

	}

	.tui-my__assets image {
		width: 36rpx;
		height: 28rpx;
		margin-left: 16rpx;
		display: block;
	}

	.tui-assets__center,
	.tui-assets__bottom {
		width: 100%;
		padding: 0 30rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		box-sizing: border-box;
	}

	.tui-item__box {
		width: 33.3333%;
		text-align: center;
		color: #fff;
		font-size: 26rpx;
		flex-shrink: 0;
	}

	.tui-text__large {
		font-size: 40rpx;
		font-weight: bold;
	}

	.tui-assets__bottom {
		position: absolute;
		left: 0;
		bottom: 0;
		padding-top: 16rpx;
		box-shadow: 0px -5px 10px -5px rgba(255, 255, 255, .3);
	}

	.tui-assets__bottom .tui-item__box {
		width: 25%;
		font-size: 24rpx;
		padding-bottom: 16rpx;
		opacity: 0.8;
	}

	.tui-assets__bottom .tui-text__large {
		font-size: 32rpx;
	}

	.tui-recharge__box {
		width: 100%;
		padding: 40rpx 30rpx;
		box-sizing: border-box;
		margin-top: 30rpx;
		border-radius: 24rpx;
		background-color: #fff;
	}

	.tui-title {
		font-size: 32rpx;
		font-weight: 600;
		color: #222222;
		padding-bottom: 20rpx;
	}

	.tui-list-cell {
		width: 100%;
		height: 160rpx;
		padding: 0 30rpx;
		box-sizing: border-box;
		background: #FFF0F1;
		border-radius: 10rpx;
		margin-top: 20rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		position: relative;
	}

	.tui-amount__title {
		font-size: 36rpx;
		font-weight: bold;
		color: #333333;
	}

	.tui-amount__desc {
		font-size: 24rpx;
		font-weight: 400;
		color: #333333;
	}

	.tui-amount__box {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.tui-amount {
		font-size: 26rpx;
		font-weight: 500;
		color: #333333;
		text-align: center;
		min-width: 142rpx;
		margin-left: auto;
	}

	.tui-badge {
		height: 32rpx;
		border-radius: 10rpx 0;
		font-size: 25rpx;
		font-weight: 400;
		color: #FFFFFF;
		position: absolute;
		left: 0;
		top: 0;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.tui-bg__new {
		background-color: #1BABA1;
	}

	.tui-bg__appoint {
		background: #F51414;
	}

	.tui-bg__old {
		background: #FA5A0A;
	}

	.tui-scale__text {
		width: 100%;
		text-align: center;
		transform: scale(0.8);
		transform-origin: center center;
	}

	/* #ifdef MP */
	.tui-tag__box {
		position: absolute;
		right: 0;
		top: 30rpx;
		border: 1rpx solid #fff;
		border-right: 0 !important;
		color: #fff;
		font-size: 24rpx;
		border-radius: 100rpx 0 0 100rpx;
		padding: 4rpx 16rpx;
		text-align: center;
	}

	/* #endif */


	.tui-records__list {
		margin-top: 20rpx;
	}

	.tui-records__item {
		width: 100%;
		display: flex;
		align-items: center;
	}

	.tui-icon {
		width: 72rpx;
		height: 72rpx;
		margin-right: 20rpx;
	}

	.tui-title1 {
		font-size: 30rpx;
		font-weight: 400;
		color: #333333;
	}

	.tui-desc {
		font-size: 24rpx;
		font-weight: 400;
		color: #888888;
		padding-top: 12rpx;
	}

	.tui-right__box {
		margin-left: auto;
		text-align: right;
	}

	.tui-amount {
		font-size: 30rpx;
		font-weight: 400;
		color: #EB0909;
	}

	.tui-expend {
		color: #19be6b !important;
	}
	.text-red {
		color: red;
	}
	.text-blue {
		color: blue;
	}
	.text-green {
		color: green;
	}
</style>
