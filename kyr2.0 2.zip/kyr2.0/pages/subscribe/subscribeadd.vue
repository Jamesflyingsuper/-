<template>
</template>
<script>
    export default {
        data() {
            return {
                
            };
        },
        onShow() {
            // #ifdef MP-WEIXIN
            uni.navigateTo({
                url: '/pages/index/index?PageCur=subscribe'
            })
            // #endif	
            // #ifdef H5
            uni.setStorageSync('PageCur', 'subscribe');
            uni.redirectTo({
                url: '/pages/index/index'
            })
            // #endif	
        },
    }
</script>

<style>
</style>
