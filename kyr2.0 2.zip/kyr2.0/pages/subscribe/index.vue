<template name="subscribe">
	<view>
		<cu-custom bgColor="bg-white" @itemclick="cpnclick" :isinput3="true"></cu-custom>
		<view v-if="page>2" class="backTop mescroll-fade-in" @click="toTopClick()">
			<image src="../../static/back-top/top.png" mode="widthFix" />
		</view>
		<view v-if="long1+long2+long3 <= 0 && ll1+ll2 <= 0">
			<view style="height: 122upx"></view>
			<view style="width: 750upx; text-align: center;">
				<image class="dy-nullimg" src="https://keyanpro.com/kyrh/imageuni/null.png"></image>
			</view>
			<view style="height: 85upx"></view>
			<view style="width: 750upx; text-align: center;">
				<text style="font-size: 21upx; color: #262626;">您还有没订阅任何内容</text>
			</view>
			<view style="height: 269upx"></view>
			<view style="width: 750upx; text-align: center; margin: auto;">
				<button @click="dingyue()" style="background: #5E068C;" class="cu-btn block dy-nullbtn lg">马上订阅</button>
			</view>
		</view>
		<view v-else>
			<view class="dynavs">
				<view @click="NavChange1" class="dynav" v-for="(item,index) in titlev" :data-cur="index">
					<text :class="PageCur1==index?'curtext2':''" class="dynavt1">{{item}}</text>
				</view>
				<view class="dynav2">
					<button @click="tuisong()" v-if="backs == 1 && status == 1" class="spebtn">
						<image class="dynav2img" src="https://keyanpro.com/kyrh/imageuni/lingdang2.png"></image>
						<text class="dynavt2">定时推送</text>
					</button>
					<button @click="qxtuisong()" v-if="backs == 1 && status == 2" class="spebtn">
						<image class="dynav2img" src="https://keyanpro.com/kyrh/imageuni/lingdang2.png"></image>
						<text class="dynavt2">取消推送</text>
					</button>
					<button @click="dingyue()" class="spebtn">
						<image class="dynav2img" src="https://keyanpro.com/kyrh/imageuni/shaixuan.png"></image>
						<text class="dynavt2">管理订阅</text>
					</button>
				</view>
			</view>
			<view style="height: 21upx;"></view>
			<view>
				<scroll-view :scroll-top="scrollTop" :scroll-with-animation="true" @scrolltolower="scroll"
					scroll-y="true" class="home-list" :style="[Style]">
					<view style="height: 56upx;"></view>
					<view class="home-3list1s">
						<view v-if="PageCur1 == 0" v-for="(item2,index) in list1">
							<view @click="goto1(item.IN_PROJECT_GOV_ID)" v-for="(item,index2) in item2"
								class="home-3list2item">
								<view class="home-3name">
									<text v-if="time2(item.PROJECT_DATE_END) > 0 && item.HITS>=hots"
										class="home-3nameicon">热门</text>
									<text v-if="time2(item.PROJECT_DATE_END) < 0" class="home-3nameicon2">已结束</text>
									{{item.PROJECT_NAME}}
								</view>
								<view class="home-3dizhi">
									<view class="home-3dizhit1">{{text(item.PROJECT_GOVERNMENT)}}</view>
									<text class="home-3dizhit2">{{time(item.PROJECT_DATE)}}</text>
									<image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png">
									</image>
								</view>
								<view class="home-3tubiao">
									<text v-if="item.PROJECT_FUNDS == '' || item.PROJECT_FUNDS !=null"
										class="home-3tubiaoicon">{{item.PROJECT_FUNDS}}万</text>
									<text class="home-3tubiaoicon2"
										v-for="(item3,index3) in keyword2(item.PROJECT_CONTENT_KEYWORDS)">{{item3}}</text>
								</view>
							</view>
						</view>
						<view v-if="PageCur1 == 1" v-for="(item2,index) in list2">
							<view @click="goto2s(item.TENDER_ID)" v-for="(item,index2) in item2"
								class="home-3list2item">
								<view class="home-3name">
									<text v-if="time2(item.TENDER_END_TIME) > 0 && item.HITS>=hots1"
										class="home-3nameicon">热门</text>
									<text v-if="time2(item.TENDER_END_TIME) < 0 && (item.TENDER_END_TIME != null)  && (item.TENDER_END_TIME != false)" class="home-3nameicon2">已结束</text>
									{{item.TENDER_NAME}}
								</view>
								<view class="home-3dizhi">
									<view class="home-3dizhit1">{{text(item.TENDER_ORGANIZATION)}}</view>
									<text class="home-3dizhit2">{{time(item.TENDER_RELEASE_TIME)}}</text>
									<image class="home-3dizhiimg" src="https://keyanpro.com/kyrh/imageuni/time.png">
									</image>
								</view>
								<view class="home-3tubiao">
									<text v-if="item.TENDER_MONEY == '' || item.TENDER_MONEY!=null"
										class="home-3tubiaoicon">{{item.TENDER_MONEY}}万</text>
									<text class="home-3tubiaoicon2"
										v-for="(item3,index3) in keyword2(item.TENDER_KEYWORDS)">{{item3}}</text>
								</view>
							</view>
						</view>
						<view v-if="PageCur1 == 2" v-for="(item2,index) in list3">
							<view @click="goto3(item.PROJECT_ID)" v-for="(item,index2) in item2"
								class="home-3list2item">
								<view class="home-3name">
									{{item.PROJECT_NAME}}
								</view>
								<view class="home-3dizhi">
									<view class="home-3dizhit3">{{text(item.PROJECT_ORGANIZATION_FUND)}}</view>
									<text class="home-3dizhit4">{{text(item.PROJECT_ORGANIZATION)}}</text>
								</view>
								<view class="home-3tubiao">
									<text v-if="item.PROJECT_FUNDS == '' || item.PROJECT_FUNDS!=null"
										class="home-3tubiaoicon">{{item.PROJECT_FUNDS}}{{item.PROJECT_FUNDS_UNIT}}</text>
									<text class="home-3tubiaoicon2"
										v-for="(item3,index3) in keyword2(item.PROJECT_KEYWORDS)">{{item3}}</text>
								</view>
							</view>
						</view>
					</view>
					<view class="listend">— 内容太多，试试搜索功能吧 —</view>
				</scroll-view>
			</view>
		</view>
		<!-- <view class="cu-tabbar-height"></view> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list1: [],
				list2: [],
				list3: [],
				backs: 2,
				long1: 0,
				long2: 0,
				long3: 0,
				loadings: 2,
				titlev: ['申报指南', '政采招标', '科研项目'],
				PageCur1: 0,
				user_id: uni.getStorageSync('user_id'),
				title: '',
				level: 0,
				scrollTop: 0,
				page: 1,
				hots: 0,
				hots1: 0,
				ll1: 0,
				ll2: 0,
				status: 2

			};
		},
		created() {
			var that = this;
			this.$api.ProjectGovhot().then((res) => {
				that.hots = res.data.data;
			});
			this.$api.Tenderhot().then((res) => {
				that.hots1 = res.data.data;
			});
			var uid = uni.getStorageSync('user_id');
			this.$api.status({
				id: uid
			}).then((res) => {
				that.status = res.data.data;
			});
			this.$api.userpay({
				user_id: uid
			}).then((res) => {
				that.level = res.data.data.level;
			});
			if (uid != '') {
				that.listp();
				this.$api.sublistSet({
					user_id: uid
				}).then((res) => {
					that.ll1 = res.data.data.data.length;
				});
				this.$api.suborglist({
					user_id: uid
				}).then((res) => {
					that.ll2 = res.data.data.length;
				});
			}
			// #ifdef H5
			that.backs = 2;
			// #endif	
			// #ifdef MP-WEIXIN
			that.backs = 1;
			// #endif	
		},
		methods: {
			NavChange1: function(e) {
				var that = this;
				that.PageCur1 = e.currentTarget.dataset.cur;
				that.list1 = [];
				that.list2 = [];
				that.list3 = [];
				that.page = 1;
				that.listp();
			},
			cpnclick(item) {
				var that = this;
				that.title = uni.getStorageSync('titipt');
				that.list1 = [];
				that.list2 = [];
				that.list3 = [];
				that.listp();
			},
			goto1(e) {
				var uid = uni.getStorageSync('user_id');
				if (uid == '') {
					uni.showToast({
						title: '请先登录',
						icon: 'none'
					});
					return;
				}
				this.$api.vipprojectGov({
					id: uid
				}).then((res) => {
					if (res.data.data == 0) {
						uni.navigateTo({
							url: '/pages/my/myts'
						})
						return;
					} else {
						uni.navigateTo({
							url: '/pages/home/zndetails?id=' + e
						})
					}
				});
			},
			goto2s(e) {
				var uid = uni.getStorageSync('user_id');
				if (uid == '') {
					uni.showToast({
						title: '请先登录',
						icon: 'none'
					});
					return;
				}
				this.$api.viptender({
					id: uid
				}).then((res) => {
					if (res.data.data == 0) {
						uni.navigateTo({
							url: '/pages/my/myts'
						})
						return;
					} else {
						uni.navigateTo({
							url: '/pages/home/zsdetails?id=' + e
						})
					}
				});
			},
			goto3(e) {
				var uid = uni.getStorageSync('user_id');
				if (uid == '') {
					uni.showToast({
						title: '请先登录',
						icon: 'none'
					});
					return;
				}
				this.$api.vipproject({
					id: uid
				}).then((res) => {
					if (res.data.data == 0) {
						uni.navigateTo({
							url: '/pages/my/myts'
						})
						return;
					} else {
						uni.navigateTo({
							url: '/pages/home/kydetails?id=' + e
						})
					}
				});
			},
			dingyue() {
				var that = this;
				var uid = uni.getStorageSync('user_id');
				if (uid == '') {
					uni.showToast({
						title: '请先登录',
						icon: 'none'
					});
					return;
				}
				if (that.level == 1) {
					uni.showToast({
						title: '请注册会员',
						icon: 'none'
					});
					return;
				}
				uni.navigateTo({
					url: '/pages/subscribe/subscribelist'
				})
			},
			listp() {
				var that = this;
				this.$api.sublist({
					id: that.user_id,
					type: 1,
					title: that.title,
					page: that.page
				}).then((res) => {
					for (var i = 0; i < res.data.data.data.length; i++) {
						if (res.data.data.data[i] != '') {
							that.list1.push(res.data.data.data[i]);
						}
					}
					this.long1 = that.list1.length;
				});
				this.$api.sublist({
					id: that.user_id,
					type: 2,
					title: that.title,
					page: that.page
				}).then((res) => {
					for (var i = 0; i < res.data.data.data.length; i++) {
						if (res.data.data.data[i] != '') {
							that.list2.push(res.data.data.data[i]);
						}
					}
					this.long2 = that.list2.length;
				});
				this.$api.sublist({
					id: that.user_id,
					type: 3,
					title: that.title,
					page: that.page
				}).then((res) => {
					var lslong3 = res.data.data.data.length;
					for (var i = 0; i < res.data.data.data.length; i++) {
						if (res.data.data.data[i] != '') {
							that.list3.push(res.data.data.data[i]);
						}
					}
					this.long3 = that.list3.length;
				});
			},
			time(t) {
				var timestamp = Math.floor((new Date()).getTime() / 1000);
				var time = timestamp - t;
				var days = time / 86400;
				var hours = days / 3600;
				var mins = hours / 60;
				if (mins * 311040000 < 60 && mins * 311040000 > 0) {
					return Math.floor(mins * 311040000) + '分钟前';
				}
				if (hours * 86400 < 24 && hours * 86400 > 0) {
					return Math.floor(hours * 86400) + '小时前';
				}
				if (days < 30 && days > 0) {
					return Math.floor(days) + '天前';
				}
				if (days < 365 && days > 0) {
					return Math.floor(days / 30) + '月前';
				}
				if (days > 365 && days > 0) {
					return Math.floor(days / 365) + '年前';
				}
			},
			time2(t) {
				var that = this;
				var timestamp = Math.floor((new Date()).getTime() / 1000);
				var times = t - timestamp;
				return times
			},
			text(a) {
				if (a == false || a == null || a == undefined) {
					return '—'
				} else {
					return a
				}
			},
			keyword2(a) {
				if (a != null) {
					var arr = a.split(';');
					if (arr != undefined) {
						return arr;
					} else {
						return a;
					}
				} else {
					return '';
				}
			},
			img(a) {
				var url = 'https://keyanpro.com/' + a;
				return url;
			},
			toTopClick: function(e) {
				var that = this;
				that.list1 = [];
				that.list2 = [];
				that.list3 = [];
				that.page = 1;
				that.listp();
			},
			scroll: function(e) {
				var that = this;
				that.page++;
				that.listp();
			},
			tuisong() {
				var that = this;
				wx.requestSubscribeMessage({
					tmplIds: ["_3pDCr28lAXAeDxPmjT4ymkn5mGKzt-RkpkMNIRN-8I"],
					success: function(res) {
						if (res[`_3pDCr28lAXAeDxPmjT4ymkn5mGKzt-RkpkMNIRN-8I`] === 'reject') {
							that.$api.subscribepush({
								id: that.user_id,
								type: 1
							}).then((ress) => {
								wx.showToast({
									title: '订阅失败！',
									icon: 'none'
								})
							});
						} else {
							that.$api.subscribepush({
								id: that.user_id,
								type: 2
							}).then((ress) => {
								that.status = 2
								wx.showToast({
									title: '订阅成功！',
								})
							});
						}
					},
					fail(err) {
						console.error(err);
					}
				})
			},
			qxtuisong() {
				var that = this;
				uni.showModal({
					title: '取消订阅',
					content: '是否要取消订阅',
					showCancel: true,
					success: function(res) {
						if (res.confirm) {
							that.$api.subscribepush({
								id: that.user_id,
								type: 1
							}).then((ress) => {
								that.status = 1
								wx.showToast({
									title: '取消成功！',
								})
							});
						} else if (res.cancel) {
							
						}
					},
				});
			}
		},

		computed: {
			Style() {
				let obj = {
					"height": `calc((100vh - 177rpx) - ${this.CustomBar}px)`,
				}
				return obj
			}
		},

	}
</script>

<style>
	.page {
		height: 100vh;
	}

	.dy-nullimg {
		width: 444upx;
		height: 347upx;
	}

	.dy-nullbtn {
		width: 375upx;
		height: 97upx;
		background: #5E068C;
		border: 1px solid #5E068C;
		opacity: 1;
		border-radius: 13upx;
		margin: auto;
		line-height: 97upx;
		color: #FFFFFF;
		font-size: 36upx;
	}

	.nvascr {
		width: 750upx;
		height: 56upx;
		position: relative;
		display: flex;
	}

	.dynavs {
		width: 690upx;
		height: 56upx;
		margin-left: 30upx;
		position: relative;
		white-space: nowrap
	}

	.dynav {
		margin-top: 28upx;
		height: 30upx;
		margin-right: 15upx;
		opacity: 1;
		float: left;
	}

	.nvascrtext {
		padding-right: 42upx;
		display: inline-block;
		font-size: 24upx;
		font-weight: 400;
		line-height: 58upx;
		color: #999999;
		opacity: 1;
	}

	.nvascricon {
		width: 70upx;
		height: 56upx;
	}

	.nvascriconimg {
		width: 28upx;
		height: 28upx;
		position: relative;
		left: 21upx;
		top: 14upx;
	}

	.nvascrviewimg {
		width: 24upx;
		height: 24upx;
		margin-right: 13upx;
	}

	.dynavt1 {
		font-size: 24upx;
		line-height: 24upx;
		position: relative;
		top: -4upx;
		color: #999999;
	}

	.dynavt2 {
		font-size: 24upx;
		line-height: 24upx;
		position: relative;
		top: -4upx;
	}

	.dynav2 {
		margin-top: 28upx;
		height: 30upx;
		color: #666666;
		opacity: 1;
		float: right;
		text-align: right;
	}

	.dynav2img {
		width: 22upx;
		height: 24upx;
		margin-right: 10upx;
	}

	.home-list {
		width: 690upx;
		margin-left: 30upx;
	}

	.home-3list1s {
		opacity: 1;
	}

	.home-3list2 {
		/* margin-top: 56upx; */
	}

	.home-3name {
		font-size: 32upx;
		font-weight: bold;
		color: #121212;
		opacity: 1;
		position: relative;
		line-height: 47upx;
		max-height: 94upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
	}

	.home-3nameicon {
		font-size: 21upx;
		font-weight: 400;
		position: relative;
		top: -5upx;
		color: #5E068C;
		opacity: 1;
		border: 1upx solid #5E068C;
		border-radius: 1upx;
		padding-top: 3upx;
		padding-bottom: 3upx;
		padding-left: 8upx;
		padding-right: 8upx;
		margin-right: 10upx;
	}

	.home-3nameicon2 {
		font-size: 21upx;
		font-weight: 400;
		position: relative;
		top: -5upx;
		color: #9E9E9E;
		opacity: 1;
		border: 1upx solid #9E9E9E;
		border-radius: 1upx;
		padding-top: 3upx;
		padding-bottom: 3upx;
		padding-left: 8upx;
		padding-right: 8upx;
		margin-right: 10upx;
	}

	.home-3dizhit3 {
		width: 340upx;
		height: 30upx;
		line-height: 30upx;
		font-size: 25upx;
		font-weight: 400;
		color: #666666;
		margin-right: 10upx;
		opacity: 1;
		float: left;
		margin: 0;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
	}

	.home-3dizhit4 {
		width: 340upx;
		line-height: 30upx;
		font-size: 25upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
		float: right;
	}

	.home-3list2item {
		margin-bottom: 83upx;
	}

	.home-3dizhi {
		width: 690upx;
		height: 30upx;
		position: relative;
		margin-top: 38upx;
	}

	.home-3dizhit1 {
		width: 530upx;
		height: 30upx;
		line-height: 30upx;
		font-size: 25upx;
		font-weight: 400;
		color: #666666;
		opacity: 1;
		float: left;
		margin: 0;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
	}

	.home-3dizhiimg {
		width: 19upx;
		height: 19upx;
		float: right;
		position: relative;
		top: 4.5upx;
		margin-right: 8upx;
	}

	.home-3dizhit2 {
		height: 30upx;
		line-height: 30upx;
		font-size: 25upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
		float: right;
	}

	.home-3tubiao {
		margin-top: 38upx;
		width: 690upx;
		position: relative;
		height: 40upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
	}

	.home-3tubiaoicon {
		font-size: 20upx;
		font-weight: 400;
		line-height: 40upx;
		position: relative;
		color: #990263;
		opacity: 1;
		border: 1upx solid #990263;
		border-radius: 1upx;
/* 		padding-top: 7upx;
		padding-bottom: 7upx; */
		padding-left: 15upx;
		padding-right: 15upx;
		margin-right: 14upx;
	}

	.home-3tubiaoicon2 {
		font-size: 20upx;
		line-height: 40upx;
		font-weight: 400;
		position: relative;
		color: #9E9E9E;
		opacity: 1;
		border: 1upx solid #9E9E9E;
		border-radius: 1upx;
/* 		padding-top: 7upx;
		padding-bottom: 7upx; */
		padding-left: 15upx;
		padding-right: 15upx;
		margin-right: 14upx;
	}

	.curtext2 {
		font-weight: bold;
		color: #121212;
	}

	.spebtn {
		float: left;
		height: 30upx;
		line-height: 30upx;
		padding: 0;
		margin: 0;
		background: none;
		border: none;
		box-shadow: none;
		overflow: hidden;
		margin-left: 20upx;
	}

	.spebtn::after {
		border: none;

	}
</style>
