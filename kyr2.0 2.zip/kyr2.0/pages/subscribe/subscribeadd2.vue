<template>
</template>
<script>
    export default {
        data() {
            return {
                
            };
        },
        onShow() {
            // #ifdef MP-WEIXIN
            uni.navigateTo({
                url: '/pages/index/index?PageCur=my'
            })
            // #endif	
        },
    }
</script>

<style>
</style>
