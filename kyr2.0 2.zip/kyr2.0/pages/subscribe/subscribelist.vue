<template name="home">
	<view>
		<cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
			<block slot="content">
				<text v-if="ispop == 0" style="font-weight: bold; color: #000000;">订阅列表</text>
				<text v-if="ispop == 1" style="font-weight: bold; color: #000000;">添加订阅</text>
				<text v-if="ispop == 2" style="font-weight: bold; color: #000000;">修改订阅</text>
			</block>
		</cu-custom>
		<fjj-condition ref='condition' @touchmove.stop :list="menuList" @result="resultConditon" />
		<fjj-condition ref='condition1' @touchmove.stop :list="menuList1" @result="resultConditon1" />
		<view class="subsrc-title">
			<view class="st-v1">您还可以订阅<text class="st-v1t">{{keywords_num}}</text>个关键词和<text
					class="st-v1t">{{organization_num}}</text>家机构</view>
			<view class="st-v2" @click="gotofriend()">邀请好友提升订阅量 >></view>
		</view>
		<view class="subsrc-list">
			<view class="sl-titlebg">
				<view class="sl-title">
					<view class="sl-titlev1">关键词</view>
					<view class="sl-titlev2" @click="showup()" v-if="listshow == 1">全部<text class="cuIcon-right"></text>
					</view>
					<view class="sl-titlev2" @click="showdown()" v-if="listshow == 2">收起<text
							class="cuIcon-fold"></text></view>
				</view>
				<view style="height: 30upx;"></view>
				<view class="sl-item2" v-for="(item,index) in lists">
					<image v-if="item.time_out == 1" class="sl-itemimg1" @click="del(item.id)"
						src="https://keyanpro.com/kyrh/imageuni/sub/rub.png"></image>
					<image v-if="item.time_out == 2" class="sl-itemimg1" @click="del(item.id)"
						src="https://keyanpro.com/kyrh/imageuni/sub/rub.png"></image>
					<image v-if="item.time_out == 1" class="sl-itemimg2"
						@click="orderbyChange1(item.id,item.keywords,item.type)"
						src="https://keyanpro.com/kyrh/imageuni/sub/pen.png"></image>
					<image v-if="item.time_out == 2" class="sl-itemimg2"
						src="https://keyanpro.com/kyrh/imageuni/sub/pen.png"></image>
					<view v-if="item.time_out == 1" class="sl-itemtitle">{{item.keywords}}</view>
					<view v-if="item.time_out == 2" class="sl-itemtitle2">{{item.keywords}}</view>
					<view v-if="listshow == 2">
						<view class="sl-itemview"><text class="sl-itemtext">内容类型：</text>{{kznull(item.type)}}</view>
						<view class="sl-itemview"><text class="sl-itemtext">地区范围：</text>{{kznull(item.loacal)}}</view>
						<view class="sl-itemview"><text class="sl-itemtext">研究领域：</text>{{kznull(item.research_field)}}
						</view>
						<view class="sl-itemview"><text class="sl-itemtext">课题类型：</text>{{kznull(item.project_type)}}
						</view>
						<view style="height: 14upx;"></view>
					</view>
				</view>
				<!-- <view class="sl-item2">
                    <image class="sl-itemimg1" src="https://keyanpro.com/kyrh/imageuni/sub/rub.png"></image>
                    <image class="sl-itemimg2" src="https://keyanpro.com/kyrh/imageuni/sub/pen.png"></image>
                    <view class="sl-itemtitle2">思想政治</view>
                    <view class="sl-itemview"><text class="sl-itemtext">内容类型：</text>申报指南</view>
                    <view class="sl-itemview"><text class="sl-itemtext">地区范围：</text>全国</view>
                    <view class="sl-itemview"><text class="sl-itemtext">研究领域：</text>信息技术、人文社科、医药卫生、农林渔牧</view>
                    <view class="sl-itemview"><text class="sl-itemtext">课题类型：</text>开放课题、社科基金、部委项目</view>
                    <view style="height: 14upx;"></view>
                </view> -->
			</view>
			<view class="sl-titlebg">
				<view class="sl-title">
					<view class="sl-titlev1">机构</view>
					<view class="sl-titlev2" @click="showup2()" v-if="listshow2 == 1">全部<text
							class="cuIcon-right"></text></view>
					<view class="sl-titlev2" @click="showdown2()" v-if="listshow2 == 2">收起<text
							class="cuIcon-fold"></text></view>
				</view>
				<view style="height: 30upx;"></view>
				<view class="sl-item2" v-for="(item,index) in sublist">
					<image v-if="item.time_out == 1" class="sl-itemimg3" @click="del2(item.id)"
						src="https://keyanpro.com/kyrh/imageuni/sub/rub.png"></image>
					<image v-if="item.time_out == 2" class="sl-itemimg3" @click="del2(item.id)"
						src="https://keyanpro.com/kyrh/imageuni/sub/rub.png"></image>
					<view v-if="item.time_out == 1" class="sl-itemtitle">{{item.organization}}</view>
					<view v-if="item.time_out == 2" class="sl-itemtitle2">{{item.organization}}</view>
					<!-- <view v-if="listshow == 2">
                        <view class="sl-itemview"><text class="sl-itemtext">内容类型：</text>{{kznull(item.type)}}</view>
                        <view class="sl-itemview"><text class="sl-itemtext">地区范围：</text>{{kznull(item.loacal)}}</view>
                        <view class="sl-itemview"><text class="sl-itemtext">研究领域：</text>{{kznull(item.research_field)}}</view>
                        <view class="sl-itemview"><text class="sl-itemtext">课题类型：</text>{{kznull(item.project_type)}}</view>
                        <view style="height: 14upx;"></view>
                    </view> -->
				</view>
			</view>
		</view>
		<view style="height: 100upx;"></view>
		<view class="subsrc-bottom">
			<view class="sb-view1" @click="back()">返回</view>
			<view class="sb-view2" @tap="orderbyChange">添加关键词</view>
		</view>
	</view>
</template>

<script>
	import fjjCondition from '@/components/fjj-condition/fjj-condition.vue';
	export default {
		name: "home",
		data() {
			return {
				CustomBar: this.CustomBar,
				ispop: 0,
				typexet: 1,
				PageCur1: 0,
				inputt: '',
				listshow: 2,
				listshow2: 2,
				lists: [],
				ll1: 0,
				ll2: 0,
				ll1s: 0,
				ll2s: 0,
				sublist: [],
				user_id: uni.getStorageSync('user_id'),
				menuList: [{
						'title': '',
						'type': 'singleinput',
						'key': 'input',
					}, {
						'title': '内容类型',
						'title2': '内容类型为单选，必填',
						'type': 'custom',
						'key': 'custom5',
						'isMutiple': false, //多选
						'detailList': [{
							CN_NAME: '申报指南',
							id: "1",
						}, {
							CN_NAME: '政采招标',
							id: "2",
						}],
					},
					{
						'title': '地区范围',
						'title2': '不选代表选择全部, 下同',
						'type': 'custom',
						'key': 'custom3',
						'isMutiple': true, //单选
						'detailList': [],
					},
					{
						'title': '研究领域',
						'type': 'custom',
						'key': 'custom2',
						'isMutiple': true, //单选
						'detailList': [],
					},
					{
						'title': '课题类型',
						'title2': '仅限申报指南',
						'type': 'custom',
						'key': 'custom1',
						'isMutiple': true, //单选
						'detailList': [],
					},
					// {
					// 	'title': '所属学科',
					// 	'title2': '仅限科研项目',
					// 	'type': 'custom',
					// 	'key': 'custom4',
					// 	'isMutiple': true, //单选
					// 	'detailList': [],
					// }
				],
				menuList1: [{
						'title': '',
						'type': 'singleinput2',
						'key': 'input',
					},
					{
						'title': '内容类型',
						'title2': '内容类型为单选，必填',
						'type': 'custom',
						'key': 'custom5',
						'isMutiple': false, //多选
						'detailList': [{
							CN_NAME: '申报指南',
							id: "1",
						}, {
							CN_NAME: '政采招标',
							id: "2",
						}],
					},
					{
						'title': '地区范围',
						'title2': '不选代表选择全部, 下同',
						'type': 'custom',
						'key': 'custom3',
						'isMutiple': true, //单选
						'detailList': [],
					},
					{
						'title': '研究领域',
						'type': 'custom',
						'key': 'custom2',
						'isMutiple': true, //单选
						'detailList': [],
					},
					{
						'title': '课题类型',
						'title2': '仅限申报指南',
						'type': 'custom',
						'key': 'custom1',
						'isMutiple': true, //单选
						'detailList': [],
					},
					// {
					// 	'title': '所属学科',
					// 	'title2': '仅限科研项目',
					// 	'type': 'custom',
					// 	'key': 'custom4',
					// 	'isMutiple': true, //单选
					// 	'detailList': [],
					// }
				],
				titid: '',
				keywords: '',
				keywords_num: 0,
				organization_num: 0
			};
		},
		onShow() {
			var that = this;
			that.seacrh();
			this.$api.sublistSet({
				user_id: that.user_id
			}).then((res) => {
				// if (res.data.data.data.length <= 0) {
				// 	that.ispop = 1;
				// 	that.$refs.condition.visibleDrawer = true;
				// }
				that.ll1s = 1;
				that.ll1 = res.data.data.data.length;
				that.lists = res.data.data.data;
				that.keywords_num = res.data.data.keywords_num;
				that.organization_num = res.data.data.organization_num;
				that.youop();
			});
			this.$api.suborglist({
				user_id: that.user_id
			}).then((res) => {
				that.ll2 = res.data.data.length;
				that.ll2s = 1;
				that.sublist = res.data.data;
				that.youop();
			});


		},
		components: {
			fjjCondition,
		},
		computed: {
			Style() {
				let obj = {
					"height": `calc((100vh - 468rpx) - ${this.CustomBar}px)`,
				}
				return obj
			}
		},
		methods: {
			youop() {
				var that = this;
				if (that.ll1s + that.ll2s == 2) {
					if (that.ll1 + that.ll2 <= 0) {
						that.ispop = 1;
						that.$refs.condition.visibleDrawer = true;
					}
				}
			},
			gotofriend() {
				uni.navigateTo({
					url: '../my/myfx'
				})
			},
			NavChange1: function(e) {
				this.PageCur1 = e.currentTarget.dataset.cur;
			},
			seacrh() {
				var that = this;
				that.menuList[0] = {
					'title': '',
					'type': 'singleinput',
					'key': 'input',
				}
				that.menuList[1] = {
					'title': '内容类型',
					'title2': '内容类型为单选，必填',
					'type': 'custom',
					'key': 'custom5',
					'isMutiple': false, //多选
					'detailList': [{
						CN_NAME: '申报指南',
						id: "1",
					}, {
						CN_NAME: '政采招标',
						id: "2",
					}],
				}

				this.$api.govpro({}).then((res) => {
					var mlist = [];
					var mlist1 = [];
					for (var i = 0; i < res.data.data.data.length; i++) {
						mlist.push(res.data.data.data[i]);
					}
					that.menuList[2].detailList = mlist.map(Iterator => {
						return {
							AREA_NAME: Iterator.AREA_NAME,
							id: Iterator.AREA_ID
						}
					})
				});
				this.$api.govindustry({}).then((res) => {
					var mlist = [];
					var mlist1 = [];
					for (var i = 0; i < res.data.data.data.length; i++) {
						mlist.push(res.data.data.data[i]);
					}
					that.menuList[3].detailList = mlist.map(Iterator => {
						return {
							INDUSTRY_NAME: Iterator.INDUSTRY_NAME,
							id: Iterator.INDUSTRY_ID
						}
					})
				});
				this.$api.govtype({}).then((res) => {
					for (var i = 0; i < res.data.data.data.length; i++) {
						that.menuList[4].detailList.push(res.data.data.data[i]);
					}
				});
				// this.$api.govsubject({}).then((res) => {
				// 	var mlist = [];
				// 	for (var i = 0; i < res.data.data.data.length; i++) {
				// 		if (res.data.data.data[i].SUBJECT_LEVEL == 1) {
				// 			mlist.push(res.data.data.data[i]);
				// 		}
				// 	}
				// 	that.menuList[5].detailList = mlist.map(Iterator => {
				// 		return {
				// 			SUBJECT_NAME: Iterator.SUBJECT_NAME,
				// 			id: Iterator.SUBJECT_NAME
				// 		}
				// 	})
				// });
			},
			seacrh2() {
				var that = this;
				that.menuList1[0] = {
					'title': '',
					'type': 'singleinput2',
					'key': 'input',
				}
				that.menuList1[1] = {
					'title': '内容类型',
					'title2': '内容类型为单选，必填',
					'type': 'custom',
					'key': 'custom5',
					'isMutiple': false, //多选
					'detailList': [],
				}

				this.$api.govpro({}).then((res) => {
					var mlist = [];
					var mlist1 = [];
					for (var i = 0; i < res.data.data.data.length; i++) {
						mlist.push(res.data.data.data[i]);
					}
					that.menuList1[2].detailList = mlist.map(Iterator => {
						return {
							AREA_NAME: Iterator.AREA_NAME,
							id: Iterator.AREA_ID
						}
					})

				});
				this.$api.govindustry({}).then((res) => {
					var mlist = [];
					var mlist1 = [];
					for (var i = 0; i < res.data.data.data.length; i++) {
						mlist.push(res.data.data.data[i]);
					}
					that.menuList1[3].detailList = mlist.map(Iterator => {
						return {
							INDUSTRY_NAME: Iterator.INDUSTRY_NAME,
							id: Iterator.INDUSTRY_ID
						}
					})
				});
				this.$api.govtype({}).then((res) => {
					for (var i = 0; i < res.data.data.data.length; i++) {
						that.menuList1[4].detailList.push(res.data.data.data[i])
					}
				});
				this.$api.govsubject({}).then((res) => {
					var mlist = [];
					for (var i = 0; i < res.data.data.data.length; i++) {
						if (res.data.data.data[i].SUBJECT_LEVEL == 1) {
							mlist.push(res.data.data.data[i]);
						}
					}
					that.menuList1[5].detailList = mlist.map(Iterator => {
						return {
							SUBJECT_NAME: Iterator.SUBJECT_NAME,
							id: Iterator.SUBJECT_NAME
						}
					})
				});
			},
			resultConditon(obj) {
				var that = this;
				console.log(obj)
				if (obj.str_result.input == '') {
					obj.str_result.input = '不限关键词'
				}
				if (obj.str_result.custom5 == '') {
					uni.showToast({
						title: '请选择内容类型',
						icon: 'none'
					});
					return;
				}
				this.$api.subadd({
					user_id: that.user_id,
					keywords: obj.str_result.input,
					type: obj.str_result.custom5,
					loacal: obj.str_result.custom3,
					research_field: obj.str_result.custom2,
					project_type: obj.str_result.custom1,
					// scientific: obj.str_result.custom4
				}).then((res) => {
					if (res.data.code == 1) {
						that.ispop = 0;
						that.lists = [];
						that.$api.sublistSet({
							user_id: that.user_id
						}).then((res) => {
							that.lists = res.data.data.data;
							that.keywords_num = res.data.data.keywords_num;
							that.organization_num = res.data.data.organization_num;
						});
						that.$refs.condition.resetClick();
						that.$refs.condition.visibleDrawer = false;
						that.menuList[0].detailList = [];
						that.menuList[1].detailList = [];
						that.menuList[2].detailList = [];
						that.menuList[3].detailList = [];
						that.menuList[4].detailList = [];
						uni.showToast({
							title: res.data.data.test,
							icon: 'none'
						})
					} else {
						uni.showToast({
							title: res.data.data.test,
							icon: 'none'
						})
					}
				});
			},
			resultConditon1(obj) {
				var that = this;
				this.$api.subupdate({
					id: that.titid,
					keywords: that.keywords,
					type: that.typexet,
					loacal: obj.str_result.custom3,
					research_field: obj.str_result.custom2,
					project_type: obj.str_result.custom1,
					// scientific: obj.str_result.custom4
				}).then((res) => {
					if (res.data.code == 1) {
						that.ispop = 0;
						that.lists = [];
						that.$api.sublistSet({
							user_id: that.user_id
						}).then((res) => {
							that.lists = res.data.data.data;
						});
						that.$refs.condition1.visibleDrawer = false;
						that.menuList1[0].detailList = [];
						that.menuList1[1].detailList = [];
						that.menuList1[2].detailList = [];
						that.menuList1[3].detailList = [];
						that.menuList1[4].detailList = [];
						uni.showToast({
							title: res.data.data.test,
							icon: 'none'
						})
					} else {
						uni.showToast({
							title: res.data.data.test,
							icon: 'none'
						})
					}
				});

			},
			orderbyChange(obj) {
				this.seacrh();
				this.ispop = 1;
				this.$refs.condition.visibleDrawer = true;
			},
			orderbyChange1(a, b, c) {
				this.seacrh2();
				this.ispop = 2;
				this.$refs.condition1.visibleDrawer = true;
				this.menuList1[0].title = b;
				this.titid = a;
				this.keywords = b;
				if (c == '申报指南') {
					this.typexet = 1;
				}
				if (c == '政采招标') {
					this.typexet = 2;
				}
				if (c == '科研项目') {
					this.typexet = 3;
				}

			},
			back() {
				uni.reLaunch({
					url: '/pages/subscribe/subscribeadd'
				})
				// uni.navigateBack({
				//     delta: 1
				// })
			},
			showup() {
				this.listshow = 2;
			},
			showdown() {
				this.listshow = 1;
			},
			showup2() {
				this.listshow2 = 2;
			},
			showdown2() {
				this.listshow2 = 1;
			},
			kznull(a) {
				if (a == false) {
					return '全部';
				} else {
					return a
				}
			},
			del(a) {
				var that = this;
				this.$api.subdelete({
					id: a
				}).then((res) => {
					uni.showToast({
						title: res.data.data.test,
						icon: 'none'
					})
					that.lists = [];
					this.$api.sublistSet({
						user_id: that.user_id
					}).then((res) => {
						that.lists = res.data.data.data;
						that.keywords_num = res.data.data.keywords_num;
						that.organization_num = res.data.data.organization_num;
					});
				});
			},
			del2(a) {
				var that = this;
				this.$api.suborgdelete({
					id: a,
					user_id: that.user_id
				}).then((res) => {
					uni.showToast({
						title: res.data.msg,
						icon: 'none'
					})
					that.sublist = [];
					this.$api.suborglist({
						user_id: that.user_id
					}).then((res) => {
						that.sublist = res.data.data;
					});
				});
			}
		}

	}
</script>

<style>
	.subsrc-title {
		width: 690upx;
		margin: 30upx;
		display: flex;
		overflow: hidden;
	}

	.st-v1 {
		font-size: 21upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
	}

	.st-v2 {
		font-size: 21upx;
		font-weight: 400;
		color: #9702A3;
		margin-left: 22upx;
	}

	.st-v1t {
		color: #990263;
	}

	.sl-titlebg {
		margin-bottom: 60upx;
	}

	.subsrc-list {
		width: 690upx;
		margin-left: 30upx;
	}

	.sl-title {
		width: 690upx;
		overflow: hidden;
	}

	.sl-titlev1 {
		float: left;
		font-size: 29upx;
		font-weight: 500;
		color: #121212;
		opacity: 1;
		line-height: 30upx;
	}

	.sl-titlev2 {
		float: right;
		font-size: 26upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
		line-height: 30upx;
	}

	.sl-item2 {
		width: 690upx;
		overflow: hidden;
		background: #FAFAFA;
		opacity: 1;
		position: relative;
		margin-bottom: 14upx;
	}

	.sl-itemimg1 {
		width: 24upx;
		height: 24upx;
		position: absolute;
		top: 35upx;
		right: 92upx;
	}

	.sl-itemimg2 {
		width: 21upx;
		height: 24upx;
		right: 28upx;
		top: 35upx;
		position: absolute;
	}

	.sl-itemimg3 {
		width: 24upx;
		height: 24upx;
		right: 28upx;
		top: 35upx;
		position: absolute;
	}

	.sl-itemtitle {
		margin: 30upx;
		width: 530upx;
		font-size: 28upx;
		font-weight: bold;
		color: #5E068C;
		opacity: 1;
	}

	.sl-itemtitle2 {
		margin: 30upx;
		width: 530upx;
		font-size: 28upx;
		font-weight: bold;
		color: #666666;
		opacity: 1;
	}

	.sl-itemview {
		margin: 0upx 30upx 21upx 30upx;
		font-size: 21upx;
		font-weight: 400;
		color: #262626;
		opacity: 1;
	}

	.sl-itemtext {
		color: #9E9E9E;
	}

	.subsrc-bottom {
		border-top: 1upx solid rgba(0, 0, 0, 0.16);
		width: 750upx;
		height: 97upx;
		position: fixed;
		bottom: 0;
		left: 0;
		overflow: hidden;
	}

	.sb-view1 {
		width: 50%;
		height: 97upx;
		float: left;
		background: #FFFFFF;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
		line-height: 97upx;
		color: #121212;
		opacity: 1;
	}

	.sb-view2 {
		width: 50%;
		height: 97upx;
		float: right;
		background: #5E068C;
		text-align: center;
		font-size: 36upx;
		font-weight: 500;
		line-height: 97upx;
		color: #FFFFFF;
		opacity: 1;
	}
</style>
