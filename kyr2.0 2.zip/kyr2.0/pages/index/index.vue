<template>
	<view>
		<home v-if="PageCur=='home'"></home>
		<subscribe v-if="PageCur=='subscribe'"></subscribe>
		<my v-if="PageCur=='my'"></my>
		<backTop :src="backTop.src" :scrollTop="backTop.scrollTop"></backTop>
		<view class="cu-bar tabbar bg-white shadow foot">
			<view class="action" @click="NavChange" data-cur="home">
				<view class='cuIcon-cu-image'>
					<image style="width: 42upx; height: 43upx;"
						:src="'/static/tabbar/home' + [PageCur=='home'?'_cur':''] + '.png'"></image>
				</view>
				<view :class="PageCur=='home'?'text-zi':'text-gray'">首页</view>
			</view>
			<view class="action" @click="NavChange" data-cur="subscribe">
				<view class='cuIcon-cu-image'>
					<image style="width: 38upx; height: 43upx;"
						:src="'/static/tabbar/subscribe' + [PageCur=='subscribe'?'_cur':''] + '.png'"></image>
				</view>
				<view :class="PageCur=='subscribe'?'text-zi':'text-gray'">订阅</view>
			</view>
			<view class="action" @click="NavChange" data-cur="my">
				<view class='cuIcon-cu-image'>
					<image style="width: 33upx; height: 43upx;"
						:src="'/static/tabbar/my' + [PageCur=='my'?'_cur':''] + '.png'"></image>
				</view>
				<view :class="PageCur=='my'?'text-zi':'text-gray'">我的</view>
			</view>
		</view>
		<view class="unpo_tan" v-if="bag == 1">
			<view class="unpo_tanbg" @click="hides()"></view>
			<view class="unpo_box">
				<text>因内容需要授权后才能填写相应信息，请您授权登录。</text>
				<view style="display: block; height: 30px;"></view>
				<button type='primary' open-type="getUserInfo" @click="wxGetUserInfo" class='bottom'
					style="background: #912775;">授权登录</button>
			</view>
		</view>
		<view class="unpo_tan" v-if="auth == 1">
			<view class="unpo_tanbg" @click="hides()"></view>
			<view class="unpo_box">
				<text>因内容需要授权后才能填写相应信息，请您授权登录。</text>
				<view style="display: block; height: 30px;"></view>
				<button type='primary' open-type="getUserInfo" @click="wxGetUserInfo1" class='bottom'
					style="background: #912775;">授权登录</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				backTop: {
					src: '../../static/back-top/top.png',
					scrollTop: 0
				},
				scrollTop: 0,
				PageCur: 'home',
				bag: 0,
				infoResList: '',
				pid: '',
				linkId:'',
				auth:0
			}
		},
		onPageScroll(e) {
			this.backTop.scrollTop = e.scrollTop;
		},
		onLoad(e) {
			var that = this;
			if(e.linkId && e.linkId.length > 0){
				this.PageCur = 'home'
				// todo： 调用接口记录linkId
				this.linkId = e.linkId
				this.auth = 1
				uni.setStorageSync('pid', this.linkId);
			}
			var pidget = uni.getStorageSync('pid');
			if (pidget != null && pidget != '') {
				uni.setStorageSync('pid', pidget);
				console.log('缓存pid=' + pidget)
			}
			if (e.scene) {
				//扫微信二维码进入小程序，并获取参数
				const scene = decodeURIComponent(e.scene);
				let arr = scene.split(",");
				uni.setStorageSync('pid', arr[0]);
				console.log('微信二维码pid' + arr[0]);
			}
			if (e && 'q' in e) {
				//扫描普二维码进入小程序，并获取参数
				const q = decodeURIComponent(e.q);
				const querys = q
					.split('?')[1]
					.split('&')
					.reduce((acc, it) => {
						let r = it.split(/=/);
						return Object.assign(acc, {
							[r[0]]: r[1]
						})
					}, {});
				if ('scene' in querys) {
					uni.setStorageSync('pid', querys.scene.trim());
					console.log('普通二维码pid' + querys.scene.trim());
				}
			}
			// #ifdef MP-WEIXIN
			if (e.bag != undefined) {
				that.bag = e.bag;
			}
			if (e.PageCur != undefined) {
				that.PageCur = e.PageCur;
			}
			// #endif	
		},
		onShow() {
			var that = this;
			// #ifdef H5
			var PageCurs = uni.getStorageSync('PageCur');
			if (PageCurs != '') {
				that.PageCur = PageCurs;
				uni.setStorageSync('PageCur', '');
			}
			// #endif	
		},
		onShareTimeline: function(e) {
			// 配置标题
			return {
				title: '科研人',
				// 这里面是配置你的url中？后面的数据
				query: {
					type: 0,
					contentid: ''
				}
			}
		},
		onShareAppMessage: function(res) {
			var that = this;
			return {
				title: '科研人', // 分享名称
				path: '/pages/index/index',
				// imageUrl: '../../static/graylogo.png',
				success: function(shareTickets) {
					uni.showToast({
						title: "成功",
						icon: 'none',
						duration: 1000
					});
				},
				fail: function(res) {
					console.log(res + '失败');
				},
				complete: function(res) {
					console.log("发送的uidwei" + uid)
				}
			}
		},
		methods: {
			NavChange: function(e) {
				this.PageCur = e.currentTarget.dataset.cur
			},
			wxGetUserInfo1() {
				var that = this;
				uni.getUserProfile({
					lang: "zh_CN",
					desc: '获取你的昵称、头像、地区及性别',
					success: function(infoRes) {
						that.infoResList = infoRes
						uni.setStorageSync('nickName', infoRes.userInfo.nickName);
						uni.setStorageSync('avatarUrl', infoRes.userInfo.avatarUrl);
						uni.login({
							provider: 'weixin',
							success: function(loginRes) {
								that.$api.wxlogin({
									'encryptedData': that.infoResList.encryptedData,
									'iv': that.infoResList.iv,
									'code': loginRes.code,
									'nickName': that.infoResList.userInfo.nickName,
									'avatarUrl': that.infoResList.userInfo.avatarUrl,
									'pid': that.linkId
								}).then((res) => {
									uni.setStorageSync('level', res.data[0].level);
									uni.setStorageSync('user_id', res.data[0].id);
									uni.reLaunch({
										url: '/pages/subscribe/subscribeadd2'
									})
								});
							},
							fail: (resError) => {
								
							}
						});
					},
					fail(res) {
						
					}
				});
			},
			wxGetUserInfo() {
				var that = this;
				uni.getUserProfile({
					lang: "zh_CN",
					desc: '获取你的昵称、头像、地区及性别',
					success: function(infoRes) {
						that.infoResList = infoRes
						uni.setStorageSync('nickName', infoRes.userInfo.nickName);
						uni.setStorageSync('avatarUrl', infoRes.userInfo.avatarUrl);
						uni.login({
							provider: 'weixin',
							success: function(loginRes) {
								that.$api.wxlogin({
									'encryptedData': that.infoResList.encryptedData,
									'iv': that.infoResList.iv,
									'code': loginRes.code,
									'nickName': that.infoResList.userInfo.nickName,
									'avatarUrl': that.infoResList.userInfo.avatarUrl,
									'pid': uni.getStorageSync('pid')
								}).then((res) => {
									uni.setStorageSync('level', res.data[0].level);
									uni.setStorageSync('user_id', res.data[0].id);
									uni.reLaunch({
										url: '/pages/subscribe/subscribeadd2'
									})
								});
							},
						});
					},
					fail(res) {}
				});
			},
			hides() {
				this.bag = 0;
			}
		}
	}
</script>

<style>
	.curimgs {
		width: 42upx;
		height: 43upx;
		background: #5E068C;
		opacity: 1;
	}

	.unpo_tan {
		display: block;
		position: fixed;
		z-index: 999999;
		width: 100%;
		height: 100vh;
		top: 0;
		z-index: 99;
	}

	.unpo_tanbg {
		width: 100%;
		height: 100%;
		background: rgba(0, 0, 0, 0.5);
	}

	.unpo_box {
		display: block;
		position: fixed;
		padding: 30upx;
		z-index: 100;
		left: 10%;
		top: 38%;
		width: 80%;
		color: #FFFFFF;
		border-radius: 10px;
		background: rgba(0, 0, 0, 0.7);
		line-height: 35px;
	}
</style>
