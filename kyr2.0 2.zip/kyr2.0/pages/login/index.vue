<template>
    <view>
        <cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
            <block slot="content"><text style="font-weight: bold; color: #000000;">登录</text></block>
        </cu-custom>
        <view style="height: 108upx;"></view>
        <view class="login-logo">
            <image class="login-logoimg" src="https://keyanpro.com/kyrh/imageuni/logo2.png"></image>
        </view>
        <view style="height: 50upx;"></view>
        <view class="login-logov1">发现更多科研机会</view>
        <view style="height: 71upx;"></view>
        <view class="login-logov2">
            <view class="login-input1">+86<text style="margin-left: 30upx;" class="cuIcon-unfold"></text></view>
            <input class="login-input2" v-model="user_login" placeholder="用户名" />
        </view>
        <view style="height: 30upx;"></view>
        <view class="login-logov3">
            <image class="login-logov3img1" src="https://keyanpro.com/kyrh/imageuni/login/suo.png"></image>
            <view v-if="ispwd == 1">
                <input class="login-logov3input" type="password" v-model="user_pass" placeholder="密码" />
                <image @click="yan1()" class="login-logov3img2" src="https://keyanpro.com/kyrh/imageuni/yan.png"></image>
            </view>
            <view v-if="ispwd == 2">
                <input class="login-logov3input" type="text" v-model="user_pass" placeholder="密码" />
                <image @click="yan2()" class="login-logov3img2" src="https://keyanpro.com/kyrh/imageuni/yan.png"></image>
            </view>
        </view>
        <view style="height: 53upx;"></view>
        <view class="login-logov4">
            <button @click="login()" style="background: #5E068C; color: #FFFFFF;" class="cu-btn block lg">登录</button>
        </view>
        <view style="height: 69upx;"></view>
        <view class="login-logov5">
            <view @click="goto1()" class="login-logov5v">找回密码</view>
            <view class="login-logov5v2"></view>
            <view @click="goto2()" class="login-logov5v">快速注册</view>
        </view>
    </view>
</template>

<script>
    export default {
        data() {
            return {
                user_login: '',
                user_pass: '',
                ispwd: 1
            };
        },
        onShow() {
            console.log("success")
        },
        methods: {
            goto1() {
                uni.navigateTo({
                    url: '/pages/login/setpwd'
                })
            },
			goto2() {
			    uni.navigateTo({
			        url: '/pages/login/register'
			    })
			},
            login() {
                var that = this;
                this.$api.login({
                    user_login: that.user_login,
                    user_pass: that.user_pass
                }).then((res) => {
                    if (res.data.code == 1) {
                        uni.setStorageSync('user_id',res.data.data.data.id);
                        uni.setStorageSync('level',res.data.data.data.level);
                        uni.setStorageSync('user_login',res.data.data.data.user_login);
                        uni.redirectTo({
                            url: '/pages/index/index'
                        })
                    } else {
                        uni.showToast({
                            title: res.data.msg,
                            icon: 'none'
                        })
                    }
                });
            },
            yan1() {
                this.ispwd = 2
            },
            yan2() {
                this.ispwd = 1
            }
        }

    }
</script>

<style>
    .login-logo {
        width: 750upx;
        height: 163upx;
        text-align: center;
    }

    .login-logoimg {
        width: 153upx;
        height: 163upx;
    }

    .login-logov1 {
        font-size: 36upx;
        font-weight: 400;
        color: #666666;
        letter-spacing: 14upx;
        opacity: 1;
        text-align: center;
    }

    .login-logov2 {
        width: 610upx;
        height: 97upx;
        background: #FFFFFF;
        border: 1upx solid #B9B9B9;
        opacity: 1;
        border-radius: 13upx;
        margin: auto;
        display: flex;
    }

    .login-input1 {
        width: 170upx;
        /* background: red; */
        height: 96upx;
        line-height: 97upx;
        text-align: center;
        border-right: 1upx solid #B9B9B9;
    }

    .login-input2 {
        width: 390upx;
        height: 96upx;
        line-height: 97upx;
        margin-left: 30upx;
    }

    .login-logov3 {
        width: 610upx;
        height: 97upx;
        background: #FFFFFF;
        border: 1upx solid #B9B9B9;
        opacity: 1;
        border-radius: 13upx;
        margin: auto;
        display: flex;
        position: relative;
    }

    .login-logov3input {
        width: 390upx;
        height: 97upx;
        line-height: 97upx;
        margin-left: 88upx;
    }

    .login-logov3img1 {
        width: 32upx;
        height: 32upx;
        position: absolute;
        top: 32.5upx;
        left: 35upx;
    }

    .login-logov3img2 {
        width: 38upx;
        height: 32upx;
        position: absolute;
        top: 32.5upx;
        right: 35upx;
    }

    .login-logov4 {
        width: 610upx;
        height: 97upx;
        margin: auto;
    }

    .login-logov5 {
        margin: auto;
        display: flex;
        text-align: center;
        display: -webkit-flex;
        justify-content: center;
        align-items: center;
    }

    .login-logov5v {
        font-size: 25upx;
        font-weight: 400;
        line-height: 25upx;
        color: #990263;
        letter-spacing: 1upx;
        opacity: 1;
    }

    .login-logov5v2 {
        width: 2upx;
        height: 22upx;
        background: #B9B9B9;
        margin-left: 24upx;
        margin-right: 24upx;
    }
</style>
