<template>
    <view>
        <cu-custom bgColor="bg-white" @itemclick="cpnclick" :isBack="true">
            <block slot="content"><text style="font-weight: bold; color: #000000;">注册</text></block>
        </cu-custom>
        <view style="height: 108upx;"></view>
        <view class="login-logo">
            <image class="login-logoimg" src="https://keyanpro.com/kyrh/imageuni/logo2.png"></image>
        </view>
        <view style="height: 50upx;"></view>
        <view class="login-logov1">发现更多科研机会</view>
        <view style="height: 71upx;"></view>
        <view class="login-logov2">
            <view class="login-input1">+86<text style="margin-left: 30upx;" class="cuIcon-unfold"></text></view>
            <input class="login-input2" placeholder="用户名" v-model="mobile" />
        </view>
        <view style="height: 30upx;"></view>
        <view class="login-logov3">
            <image class="login-logov3img1" src="https://keyanpro.com/kyrh/imageuni/login/suo.png"></image>
            <view>
                <input class="login-logov3input" type="password" v-model="user_pass" placeholder="密码" />
            </view>
        </view>
        <view style="height: 30upx;"></view>
        <view class="login-logov6">
            <input type="text" v-model="code" placeholder="6位短信验证码" class="login-logov7" />
            <view v-show="show" class="login-logov8" @click="havedx()">
                获取短信验证码
            </view>
            <view v-show="!show" class="login-logov8" @click="havedx()">
                剩余{{count}}s
            </view>
        </view>
        <view style="height: 53upx;"></view>
        <view class="login-logov4">
            <button @click="register()" style="background: #5E068C; color: #FFFFFF;"
                class="cu-btn block lg">快速注册</button>
        </view>
        <view style="height: 40upx;"></view>
        <view class="login-logov9">
            <view class="login-logov9l">注册即表明同意<text style="color: #990263;">《科研人服务协议》</text></view>
            <view @click="goto()" class="login-logov9r">直接登录</view>
        </view>
    </view>
</template>

<script>
    export default {
        data() {
            return {
                mobile: '',
                user_pass: '',
                code: '',
                count: '',
                timer: null,
                show: true
            };
        },
        onShow() {
            console.log("success")
        },
        methods: {
            goto() {
                uni.navigateTo({
                    url: '/pages/login/index'
                })
            },
            havedx() {
                var that = this;
                if (that.mobile == '') {
                    uni.showToast({
                        title: '请输入手机号',
                        icon: 'none'
                    })
                    return;
                }
                this.$api.aliyun({
                    phone: that.mobile
                }).then((res) => {
                    console.log(res.data.msg)
                });
                const TIME_COUNT = 60;
                if (!this.timer) {
                    this.count = TIME_COUNT;
                    this.show = false;
                    this.timer = setInterval(() => {
                        if (this.count > 0 && this.count <= TIME_COUNT) {
                            this.count--;
                        } else {
                            this.show = true;
                            clearInterval(this.timer);
                            this.timer = null;
                        }
                    }, 1000)
                }




            },
            register() {
                var that = this;
                if (that.mobile == '') {
                    uni.showToast({
                        title: '请输入手机号',
                        icon: 'none'
                    })
                    return;
                }
                if (that.user_pass == '') {
                    uni.showToast({
                        title: '请输入6位数密码',
                        icon: 'none'
                    })
                    return;
                }
                if (that.code == '') {
                    uni.showToast({
                        title: '请输入验证码',
                        icon: 'none'
                    })
                    return;
                }
                this.$api.register({
                    mobile: that.mobile,
                    user_pass: that.user_pass,
                    code: that.code
                }).then((res) => {
                    if (res.data.code == 1) {
                        uni.navigateTo({
                            url: '/pages/login/index'
                        })
                    } else {
                        uni.showToast({
                            title: res.data.data.data,
                            icon: 'none'
                        })
                    }
                });

            }
        }

    }
</script>

<style>
    .login-logo {
        width: 750upx;
        height: 163upx;
        text-align: center;
    }

    .login-logoimg {
        width: 153upx;
        height: 163upx;
    }

    .login-logov1 {
        font-size: 36upx;
        font-weight: 400;
        color: #666666;
        letter-spacing: 14upx;
        opacity: 1;
        text-align: center;
    }

    .login-logov2 {
        width: 610upx;
        height: 97upx;
        background: #FFFFFF;
        border: 1upx solid #B9B9B9;
        opacity: 1;
        border-radius: 13upx;
        margin: auto;
        display: flex;
    }

    .login-input1 {
        width: 170upx;
        /* background: red; */
        height: 96upx;
        line-height: 97upx;
        text-align: center;
        border-right: 1upx solid #B9B9B9;
    }

    .login-input2 {
        width: 390upx;
        height: 96upx;
        line-height: 97upx;
        margin-left: 30upx;
    }

    .login-logov3 {
        width: 610upx;
        height: 97upx;
        background: #FFFFFF;
        border: 1upx solid #B9B9B9;
        opacity: 1;
        border-radius: 13upx;
        margin: auto;
        display: flex;
        position: relative;
    }

    .login-logov6 {
        width: 610upx;
        height: 97upx;
        margin: auto;
        display: flex;
        position: relative;
    }

    .login-logov4 {
        width: 610upx;
        height: 97upx;
        margin: auto;
    }

    .login-logov5 {
        margin: auto;
        display: flex;
        text-align: center;
        display: -webkit-flex;
        justify-content: center;
        align-items: center;
    }

    .login-logov5v {
        font-size: 25upx;
        font-weight: 400;
        line-height: 25upx;
        color: #990263;
        letter-spacing: 1upx;
        opacity: 1;
    }

    .login-logov5v2 {
        width: 2upx;
        height: 22upx;
        background: #B9B9B9;
        margin-left: 24upx;
        margin-right: 24upx;
    }

    .login-logov7 {
        width: 320upx;
        height: 97upx;
        line-height: 97upx;
        padding-left: 38upx;
        padding-right: 38upx;
        background: #FFFFFF;
        border: 1upx solid #B9B9B9;
        opacity: 1;
        border-radius: 13upx;
    }

    .login-logov8 {
        width: 278upx;
        heigh: 97upx;
        line-height: 97upx;
        background: #FFFFFF;
        border: 1upx solid #B9B9B9;
        opacity: 1;
        border-radius: 13upx;
        margin-left: 14upx;
        text-align: center;
        color: #797979;
        font-size: 32upx;
    }

    .login-logov9 {
        width: 610upx;
        margin: auto;
        overflow: hidden;
    }

    .login-logov9l {
        float: left;
        font-size: 25upx;
        font-weight: 400;
        color: #B9B9B9;
        letter-spacing: 2upx;
        opacity: 1;
    }

    .login-logov9r {
        float: right;
        font-size: 25upx;
        font-weight: 400;
        color: #990263;
        letter-spacing: 2upx;
        opacity: 1;
    }

    .login-logov3input {
        width: 390upx;
        height: 97upx;
        line-height: 97upx;
        margin-left: 88upx;
    }

    .login-logov3img1 {
        width: 32upx;
        height: 32upx;
        position: absolute;
        top: 32.5upx;
        left: 35upx;
    }

    .login-logov3img2 {
        width: 38upx;
        height: 32upx;
        position: absolute;
        top: 32.5upx;
        right: 35upx;
    }
</style>
