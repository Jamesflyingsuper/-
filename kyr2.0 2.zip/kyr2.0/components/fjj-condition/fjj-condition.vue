<template>
	<view>
		<uni-drawer :visible="visibleDrawer" mode="right" @close="closeDrawer()">
			<scroll-view class="drawer-list" scroll-y :style="{'height': drawerHeight}">
				<view :style="[{height:CustomBar + 'px'}]"></view>
				<block v-for="(item, index) in menuList" :key="index">
					<!-- 单选、多选  isMutiple是否支持多选-->
					<view v-if="item.type === 'custom' && item.detailList.length">
						<view class="drawer-list-title flex justify-between">
							<view style="font-size: 29upx; font-weight: bold; color: #000000;">
								{{item.title}}<text class="mhqfjj">{{item.title2}}</text>
							</view>
							<text v-if="item.detailList.length>showLenght" @tap="showMore(index)"
								style="margin-right: 20upx;">

								<text v-if="item.showMoreList == true">收起<text class="cuIcon-fold"></text></text>
								<text v-else>全部<text class="cuIcon-right"></text></text>
							</text>
						</view>
						<view class="draer-list-con">
							<template v-if="!item.showMoreList">
								<view class="drawer-listview"
									:style="{color:textItem.isSelected ? '#5E068C' : '',background:textItem.isSelected ? '#ffffff' : ''}"
									v-if="idx<showLenght" v-for="(textItem, idx) in item.detailList" :key="idx"
									@tap="itemTap(idx,item.detailList,item.key, item.isMutiple)">
									<view class="itemfjj" v-if="textItem.isSelected"
										style="border: 1upx solid #5E068C;">
										<text v-if="item.key=='custom1'">{{textItem.type}}</text>
										<text v-if="item.key=='custom2'">{{textItem.INDUSTRY_NAME}}</text>
										<text v-if="item.key=='custom3'">{{textItem.AREA_NAME}}</text>
										<text v-if="item.key=='custom4'">{{textItem.SUBJECT_NAME}}</text>
										<text v-if="item.key=='custom5'">{{textItem.CN_NAME}}</text>
										<image class="xsj" src="https://keyanpro.com/kyrh/imageuni/xsj.png"></image>
									</view>
									<view class="itemfjj" v-else style="border: 1upx solid #F6F6F6;">
										<text v-if="item.key=='custom1'">{{textItem.type}}</text>
										<text v-if="item.key=='custom2'">{{textItem.INDUSTRY_NAME}}</text>
										<text v-if="item.key=='custom3'">{{textItem.AREA_NAME}}</text>
										<text v-if="item.key=='custom4'">{{textItem.SUBJECT_NAME}}</text>
										<text v-if="item.key=='custom5'">{{textItem.CN_NAME}}</text>
									</view>
								</view>
							</template>
							<template v-else>
								<view class="drawer-listview"
									:style="{color:  textItem.isSelected ? '#5E068C' : '',background:textItem.isSelected ? '#ffffff' : ''}"
									v-for="(textItem, idx) in item.detailList" :key="idx"
									@tap="itemTap(idx,item.detailList,item.key, item.isMutiple)">
									<view class="itemfjj" v-if="textItem.isSelected"
										style="border: 1upx solid #5E068C;">
										<text v-if="item.key=='custom1'">{{textItem.type}}</text>
										<text v-if="item.key=='custom2'">{{textItem.INDUSTRY_NAME}}</text>
										<text v-if="item.key=='custom3'">{{textItem.AREA_NAME}}</text>
										<text v-if="item.key=='custom4'">{{textItem.SUBJECT_NAME}}</text>
										<text v-if="item.key=='custom5'">{{textItem.CN_NAME}}</text>
										<image class="xsj" src="https://keyanpro.com/kyrh/imageuni/xsj.png"></image>
									</view>
									<view class="itemfjj" v-else style="border: 1upx solid #F6F6F6;">
										<text v-if="item.key=='custom1'">{{textItem.type}}</text>
										<text v-if="item.key=='custom2'">{{textItem.INDUSTRY_NAME}}</text>
										<text v-if="item.key=='custom3'">{{textItem.AREA_NAME}}</text>
										<text v-if="item.key=='custom4'">{{textItem.SUBJECT_NAME}}</text>
										<text v-if="item.key=='custom5'">{{textItem.CN_NAME}}</text>
									</view>
								</view>
							</template>
						</view>
					</view>
					<!-- 时间带时分秒范围选择 -->
					<view v-if="item.type === 'rangetime'">
						<view class="drawer-list-title flex justify-between">
							<view>
								{{item.title}}
							</view>
						</view>
						<view class="dateContent" @click="onShowDatePicker('rangetime', item.key, item)">
							<view>
								<template v-if="result[item.key] && result[item.key].length > 0">
									{{rangetime[0]}}
								</template>
							</view>
							<view>
								<template v-if="result[item.key] && result[item.key].length > 0">
									{{rangetime[1]}}
								</template>
							</view>
						</view>
					</view>
					<!-- 时间不带时分秒范围选择 -->
					<view v-if="item.type === 'range'">
						<view class="drawer-list-title flex justify-between">
							<view>
								{{item.title}}
							</view>
						</view>
						<view class="dateContent" @click="onShowDatePicker('range', item.key, item)">
							<view>
								<template v-if="result[item.key] && result[item.key].length > 0">
									{{range[0]}}-{{range[1]}}
								</template>
							</view>
						</view>
					</view>
					<!-- 时间选择 -->
					<view v-if="item.type === 'date'">
						<view class="drawer-list-title flex justify-between">
							<view>
								{{item.title}}
							</view>
						</view>
						<view class="dateContent" @click="onShowDatePicker('date', item.key, item)">
							<view>
								<template v-if="result[item.key]">
									{{result[item.key]}}
								</template>
							</view>
						</view>
					</view>
					<!-- 数值范围选择 -->
					<view v-if="item.type === 'rangenumber'">
						<view class="drawer-list-title flex justify-between">
							<view>
								{{item.title}}
							</view>
						</view>
						<view class="dateContent rangenumber-content flex">
							<view class="rangenumber-input">
								<input class="m-input" type="number" clearable
									v-model="result[item.minName || (item.key + 'Min')]"
									:placeholder="item.minPlaceholder || '最小值'" @blur="numberInputBlur(item)"></input>
							</view>
							<text>-</text>
							<view class="rangenumber-input">
								<input class="m-input" type="number" clearable
									v-model="result[item.maxName || (item.key + 'Max')]"
									:placeholder="item.maxPlaceholder || '最大值'" @blur="numberInputBlur(item)"></input>
							</view>
						</view>
					</view>
					<!-- 单输入框 -->
					<view v-if="item.type === 'singleinput'">
						<view class="drawer-list-title flex justify-between">
							<view>
								{{item.title}}
							</view>
						</view>
						<view class="dateContent">
							<view>
								<input class="m-input" clearable v-model="result[item.key]"
									:placeholder="item.placeholder || '请输入关键字'" />
							</view>
						</view>
					</view>
					<!-- 单输入框 -->
					<view v-if="item.type === 'singleinput2'">
						<view class="drawer-list-title flex justify-between">
							<view style="color: #5E068C;">
								请修改：{{item.title}}
							</view>
						</view>
					</view>
				</block>
			</scroll-view>
			<view class="bottombtns">
				<view class="filter-content-footer-item1" @tap="resetClick">
					<text>清空</text>
				</view>
				<view class="filter-content-footer-item2" @tap="sureClick">
					<text>确定</text>
				</view>
			</view>
		</uni-drawer>
		<mx-date-picker :show="showPicker" :color="color" :type="dateType" :value="dateValue" :show-tips="true"
			:show-seconds="true" @confirm="onSelected" @cancel="onSelected" />
	</view>
</template>

<script>
	/***
	 * 筛选组件，当前支持多选、单选
	 * item.type (custom 单选、多选、rangetime 时间范围带时分秒、range 时间范围不带时分秒、rangenumber 数字范围)
	 * item.isMutiple 是否支持多选
	 * 筛选后返回格式{"listName1":[value,value](多选),"listName2":"value"（单选）,...}
	 * rangenumber形式-可能为["",1]或[1,""]表示只有一个最大值或最小值
	 ***/
	import uniDrawer from '@/components/uni-drawer/uni-drawer.vue';
	import MxDatePicker from "@/components/mx-datepicker/mx-datepicker.vue";
	export default {
		props: {
			list: {
				required: true,
				type: Array,
				default () {
					return [];
				},
			},
			color: {
				type: String,
				default: '#4D7BFE',
			},
		},
		components: {
			uniDrawer,
			MxDatePicker
		},
		beforeCreate() {
			Date.prototype.Format = function(fmt) { //author: meizz
				var o = {
					"M+": this.getMonth() + 1, //月份 
					"d+": this.getDate(), //日 
					"h+": this.getHours(), //小时 
					"m+": this.getMinutes(), //分 
					"s+": this.getSeconds(), //秒 
					"q+": Math.floor((this.getMonth() + 3) / 3), //季度 
					"S": this.getMilliseconds() //毫秒 
				};
				if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1
					.length));
				for (var k in o)
					if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[
						k]) : (("00" + o[
						k]).substr(("" + o[k]).length)));
				return fmt;
			}
		},
		created() {
			this.resetResult();
			uni.getSystemInfo({
				success: (res) => {
					let windowHeight = res.windowHeight;
					// #ifdef H5
					windowHeight = window.innerHeight || document.documentElement.clientHeight || document.body
						.clientHeight || res.windowHeight;
					// #endif
					this.drawerHeight = (windowHeight - uni.upx2px(120)) + 'px';
				}
			});
		},
		computed: {
			defaultSelectedObj() { // 保存初始状态
				return this.getSelectedObj()
			},
			selectedObj: {
				get() {
					return this.getSelectedObj()
				},
				set(newObj) {
					return newObj;
				}
			},
			menuList() {
				return this.list;
			}
		},
		data() {
			return {
				CustomBar: this.CustomBar,
				visibleDrawer: false,
				menuKey: 1,
				showLenght: 12,
				drawerHeight: '500px',
				selectDetailList: [],
				result: {},
				showPicker: false,
				time: '',
				datetime: '',
				range: [new Date(new Date().getTime() - 24 * 60 * 60 * 1000).Format('yyyy/MM/dd'), new Date().Format(
					'yyyy/MM/dd')],
				rangetime: [new Date(new Date().getTime() - 24 * 60 * 60 * 1000).Format('yyyy/MM/dd hh:mm'), new Date()
					.Format(
						'yyyy/MM/dd hh:mm')
				],
				date: new Date().Format('yyyy/MM/dd'),
				dateType: 'rangetime',
				dateValue: '',
			};
		},

		methods: {
			getSelectedObj() {
				return this.commonResultObj();
			},
			resetResult() {
				this.result = this.commonResultObj();
			},
			commonResultObj() {
				let obj = {};
				this.menuList.map((item) => {
					switch (item.type) {
						case "custom":
							item.isMutiple ? obj[item.key] = [] : obj[item.key] = '';
							break;
						case 'range':
						case 'rangetime':
						case 'rangenumber':
							obj[item.key] = [];
							obj[item.minName || (item.key + 'Min')] = '';
							obj[item.maxName || (item.key + 'Max')] = '';
							break;
						default:
							obj[item.key] = '';
					}
				})
				return obj;
			},
			//筛选项选中或取消
			itemTap(index, list, key, isMutiple) {
				if (isMutiple == true) {
					list[index].isSelected = !list[index].isSelected;
					if (list[index].isSelected) {
						this.selectedObj[key].push(list[index].id);
					} else {
						list[index].isSelected = false;
						var idx = this.selectedObj[key].indexOf(list[index].id);
						this.selectedObj[key].splice(idx, 1);
					}
					this.result[key] = this.selectedObj[key];
				} else {
					this.result[key] = list[index].isSelected ? '' : list[index].id;
					for (let i = 0; i < list.length; i++) {
						if (index == i && !list[i].isSelected) {
							list[i].isSelected = true
						} else {
							list[i].isSelected = false
						}
					}
				}

				// #ifdef H5
				this.$forceUpdate();
				// #endif
			},

			sureClick() {
				let str_result = {};
				let hasChoose = false;
				for (let key in this.result) {
					if (typeof this.result[key] == 'object') {
						str_result[key] = this.result[key].join(';');
						if (!hasChoose) {
							hasChoose = this.result[key].join(';') !== '' ? true : false;
						}
					} else {
						str_result[key] = this.result[key];
						if (!hasChoose) {
							hasChoose = this.result[key] !== '' ? true : false;
						}
					}
				}

				this.$emit("result", {
					'str_result': str_result,
					'result': this.result,
					'hasChoose': hasChoose,
					'visibleDrawer': false
				});
			},
			resetClick() {
				this.minNumber = '';
				this.maxNumber = '';
				for (let key in this.result) {
					if (typeof this.result[key] === 'object') {
						this.selectedObj[key] = [];
						this.result[key] = [];
					} else {
						this.result[key] = '';
					}
				}
				for (let i = 0; i < this.menuList.length; i++) {
					if (this.menuList[i].type === 'custom') {
						for (let j = 0; j < this.menuList[i].detailList.length; j++) {
							this.menuList[i].detailList[j].isSelected = false;
						}
					}
				}
				// #ifdef H5
				this.$forceUpdate();
				// #endif
			},
			closeDrawer() {
				this.visibleDrawer = false;
			},

			showMore(index) {
				this.menuList[index].showMoreList = !this.menuList[index].showMoreList;
				++this.menuKey;
				// #ifdef H5
				this.$forceUpdate();
				// #endif
			},

			onShowDatePicker(type, key, item) { //显示
				this.dateType = type;
				this.dateValue = this[type];
				this.showPicker = true;
				this.tempKey = key;
				this.item = item;
			},

			onSelected(e, key) { //选择
				this.showPicker = false;
				if (e) {
					this[this.dateType] = e.value;
					this.result[this.tempKey] = e.value;
					if (e.value && e.value.length && this.item && this.item.type !== 'date') {
						let item = this.item;
						this.result[item.minName || (item.key + 'Min')] = e.value[0].replaceAll('/', '-');
						this.result[item.maxName || (item.key + 'Max')] = e.value[1].replaceAll('/', '-');
					}
					//选择的值
					console.log('value => ' + e.value);
					//原始的Date对象
					console.log('date => ' + e.date);
				}
			},
			numberInputBlur(item) {
				let minNumber = this.result[item.minName || (item.key + 'Min')];
				let maxNumber = this.result[item.maxName || (item.key + 'Max')];
				if (minNumber != '' && maxNumber != '' && parseFloat(minNumber) > parseFloat(maxNumber)) {
					let temp = minNumber;
					this.result[item.minName || (item.key + 'Min')] = maxNumber;
					this.result[item.maxName || (item.key + 'Max')] = temp;
				}
				this.result[item.key] = [];
				this.result[item.key].push(minNumber && parseFloat(minNumber));
				this.result[item.key].push(maxNumber && parseFloat(maxNumber));
			}
		}
	}
</script>

<style lang="scss" scoped>
	.flex {
		display: flex;
	}

	.justify-between {
		justify-content: space-between;
	}

	view,
	scroll-view,
	swiper,
	button,
	input,
	textarea,
	label,
	navigator,
	image {
		box-sizing: border-box;
	}

	/* 筛选样式 */
	.drawer-list {
		padding: 0 20rpx;
		font-size: 26rpx;
	}

	input {
		font-size: 26rpx;
	}

	.drawer-list .drawer-list-title {
		font-size: 34rpx;
		font-weight: 400;
		line-height: 48rpx;
		margin: 38rpx 0 18rpx;
		color: #9E9E9E;
	}

	.drawer-list .drawer-list-title>text {
		font-size: 26rpx;
		color: #9E9E9E;
	}

	.drawer-listview {
		background: #F6F6F6;
		color: #9E9E9E;
		font-size: 24rpx;
		width: 161rpx;
		margin-right: 17upx;
		margin-bottom: 17upx;
		text-align: center;
		display: inline-block;
	}

	.picker {
		z-index: 99999 !important;
	}

	.dateContent {
		&>view {
			background: rgba(244, 244, 244, 1);
			border-radius: 50rpx;
			width: 100%;
			height: 83rpx;
			line-height: 83rpx;
			margin-bottom: 12rpx;
			padding: 0 12rpx;
		}
	}

	.rangenumber-content {
		&>text {
			display: inline-block;
			width: 10%;
			text-align: center;
			height: 83rpx;
			line-height: 83rpx;
		}

		.rangenumber-input {
			width: 45%;
			display: inline-block;
			padding: 0 12rpx;
		}
	}

	.m-input {
		height: 83rpx;
		line-height: 83rpx;
		padding-left: 49upx;
		color: #5E068C;
		font-weight: bold;
	}

	.m-borders {
		border: 1upx soild #5E068C;
	}

	.xuanzhong {
		padding-top: 17upx;
		padding-bottom: 17upx;
	}

	.xsj {
		width: 15upx;
		height: 14upx;
		position: absolute;
		top: 0;
		right: 0;
	}

	::v-deep .picker {
		z-index: 999;
	}

	.bottombtns {
		border-top: 1upx solid rgba(0, 0, 0, 0.16);
		background: #FFFFFF;
		height: 97upx;
		width: 750upx;
		position: fixed;
		bottom: 0;
		display: flex;
	}


	.filter-content-footer-item1 {
		width: 50%;
		height: 97rpx;
		line-height: 97rpx;
		text-align: center;
		color: #121212;
		font-size: 36upx;
	}

	.filter-content-footer-item2 {
		width: 50%;
		height: 97rpx;
		line-height: 97rpx;
		text-align: center;
		color: #FFFFFF;
		background: #5E068C;
		font-size: 36upx;
	}

	.mhqfjj {
		font-size: 21upx;
		font-weight: 400;
		color: #9E9E9E;
		opacity: 1;
		margin-left: 17upx;
	}

	.itemfjj {
		height: 55upx;
		line-height: 55upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1;
		overflow: hidden;
		position: relative;
	}
</style>
