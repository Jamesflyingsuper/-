import http from './interface'
var baseUrl = 'https://keyanpro.com/api/';
export const tokenConfig = {
	token: uni.getStorageSync('token'),
	setToken(data) {
		this.token = data
	}
}
export const sbznt1 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/projectTtimeNum',
		dataType: 'json',
		data,
	})
}
export const sbznt2 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/projectWaitNum',
		dataType: 'json',
		data,
	})
}
export const sbznlist = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/list',
		dataType: 'json',
		data,
	})
}

export const sbznlist2 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/pgv',
		dataType: 'json',
		data,
	})
}
export const zczbt1 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Tender/tenderWaitNum',
		dataType: 'json',
		data,
	})
}
export const zczbt2 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Tender/tenderTtimeNum',
		dataType: 'json',
		data,
	})
}
export const zczblist = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Tender/list',
		dataType: 'json',
		data,
	})
}
export const zczblist2 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Tender/tender',
		dataType: 'json',
		data,
	})
}
export const kyxmt1 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Project/projectNum',
		dataType: 'json',
		data,
	})
}
export const kyxmlist = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Project/list',
		dataType: 'json',
		data,
	})
}
export const bannerlist = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Articles/list',
		dataType: 'json',
		data,
	})
}
// 课题类型
export const govtype = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/type',
		dataType: 'json',
		data,
	})
}
// 研究领域
export const govindustry = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/industry',
		dataType: 'json',
		data,
	})
}
// 学科分类
export const govsubject = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/subject',
		dataType: 'json',
		data,
	})
}
// 国家
export const govcountry = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/country',
		dataType: 'json',
		data,
	})
}
// 省
export const govpro = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/pro',
		dataType: 'json',
		data,
	})
}
// 微信登录
export const wxlogin = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/WxLogin/wxlogin',
		dataType: 'json',
		data,
	})
}
// h5登录
export const login = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Register/login',
		dataType: 'json',
		data,
	})
}
// h5注册
export const register = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Register/register',
		dataType: 'json',
		data,
	})
}
// h5修改
export const forgetPass = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Register/forgetPass',
		dataType: 'json',
		data,
	})
}
// h5短信
export const aliyun = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Register/aliyun',
		dataType: 'json',
		data,
	})
}
// 订阅列表
export const sublist = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/list',
		dataType: 'json',
		data,
	})
}
// 订阅机构列表
export const suborglist = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/organization_list',
		dataType: 'json',
		data,
	})
}
// 订阅设置列表
export const subadd = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/add',
		dataType: 'json',
		data,
	})
}
// 订阅订阅添加
export const sublistSet = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/listSet',
		dataType: 'json',
		data,
	})
}
// 订阅删除
export const subdelete = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/delete',
		dataType: 'json',
		data,
	})
}
// 文章订阅添加
export const subaddart = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/addArt',
		dataType: 'json',
		data,
	})
}
// 机构订阅添加
export const suborganadd = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/organization_add',
		dataType: 'json',
		data,
	})
}
// 关键词是否订阅
export const suborwords = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/keywordsJudge',
		dataType: 'json',
		data,
	})
}
// 机构是否订阅
export const subzation = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/organizationJudge',
		dataType: 'json',
		data,
	})
}
// 机构订阅删除
export const suborgdelete = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/organization_delete',
		dataType: 'json',
		data,
	})
}
// 收藏列表
export const collectList = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/collectList',
		dataType: 'json',
		data,
	})
}
// 收藏添加
export const collectAdd = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/collectAdd',
		dataType: 'json',
		data,
	})
}
// 申报指南添加历史记录
export const historyadd1 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/projectgov_history_add',
		dataType: 'json',
		data,
	})
}
// 政采招标添加历史记录
export const historyadd2 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Tender/tender_history_add',
		dataType: 'json',
		data,
	})
}
// 科研项目添加历史记录
export const historyadd3 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Project/project_history_add',
		dataType: 'json',
		data,
	})
}
// 深度文章添加历史记录
export const historyadd4 = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Articles/articles_history_add',
		dataType: 'json',
		data,
	})
}
// 历史记录列表
export const organlist = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/history',
		dataType: 'json',
		data,
	})
}
// 订阅修改
export const subupdate = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/update',
		dataType: 'json',
		data,
	})
}
// 收藏删除
export const collectDel = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/collectDel',
		dataType: 'json',
		data,
	})
}
// 收藏删除
export const ticleshits = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Articles/hits',
		dataType: 'json',
		data,
	})
}
// pay
export const smallpay = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/WxPay/small_pay',
		dataType: 'json',
		data,
	})
}
// h5pay
export const h5smallpay = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/WxPay/weChat_page_pay',
		dataType: 'json',
		data,
	})
}
// 支付回调
export const userpay = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/WxPay/user_pay',
		dataType: 'json',
		data,
	})
}

// 申报指南点击量
export const projectGovhits = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/hits',
		dataType: 'json',
		data,
	})
}
// 政采招标点击量
export const tenderhits = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Tender/hits',
		dataType: 'json',
		data,
	})
}
// 科研项目点击量
export const projecthits = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Project/hits',
		dataType: 'json',
		data,
	})
}
// 指南查询
export const searchpgv = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/search/pgv',
		dataType: 'json',
		data,
	})
}
// 政采查询
export const searchtender = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/search/tender',
		dataType: 'json',
		data,
	})
}
// 科研查询
export const searchproject = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/search/project',
		dataType: 'json',
		data,
	})
}
// 深度查询
export const searcharticle = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/search/article',
		dataType: 'json',
		data,
	})
}
// 手机号绑定
export const boundPhone = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/WxLogin/boundPhone',
		dataType: 'json',
		data,
	})
}
// 查看是否有密码
export const passin = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/WxLogin/passin',
		dataType: 'json',
		data,
	})
}

// 申报指南限制数量
export const vipprojectGov = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/VipRestrict/projectGov',
		dataType: 'json',
		data,
	})
}

// 政采招标限制阅读数量
export const viptender = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/VipRestrict/tender',
		dataType: 'json',
		data,
	})
}

// 科研项目限制阅读数量
export const vipproject = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/VipRestrict/project',
		dataType: 'json',
		data,
	})
}

// 根据机构或关键词搜索
export const GovkeywordOrorganization = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/GovkeywordOrorganization',
		dataType: 'json',
		data,
	})
}

// 政采招标热门评定数量
export const Tenderhot = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Tender/hot',
		dataType: 'json',
		data,
	})
}

// 申报指南热门评定数量
export const ProjectGovhot = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/ProjectGov/hot',
		dataType: 'json',
		data,
	})
}

// 分享海报
export const subscribeshare = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/share',
		dataType: 'json',
		data,
	})
}

// 推送
export const subscribepush = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/push',
		dataType: 'json',
		data,
	})
}

// 分享海报主页
export const subscribeshareHai = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/shareHai',
		dataType: 'json',
		data,
	})
}

// 审核
export const audit = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/audit',
		dataType: 'json',
		data,
	})
}

// 初始化订阅
export const status = (data) => {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/subscribe/status',
		dataType: 'json',
		data,
	})
}
// 合作伙伴页面数据提取
export const Cooperation  = (data)=>{
	
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Cooperation/index',
		dataType: 'json',
		data,
	})
}
// 提现记录
export const getRecord = (data)=> {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Cooperation/history',
		dataType: 'json',
		data,
	})
}
// 提现申请
export const reply = (data)=> {
	return http.request({
		baseUrl: baseUrl,
		url: 'demo/Cooperation/withdrawal',
		dataType: 'json',
		data,
	})
}
export default {
	sbznt1,
	sbznt2,
	sbznlist,
	zczbt1,
	zczbt2,
	zczblist,
	kyxmt1,
	kyxmlist,
	bannerlist,
	govtype,
	govindustry,
	govsubject,
	govcountry,
	govpro,
	wxlogin,
	login,
	register,
	forgetPass,
	aliyun,
	sublist,
	subadd,
	sublistSet,
	subdelete,
	subaddart,
	suborglist,
	suborganadd,
	suborwords,
	subzation,
	suborgdelete,
	collectList,
	collectAdd,
	historyadd1,
	historyadd2,
	historyadd3,
	historyadd4,
	organlist,
	subupdate,
	collectDel,
	ticleshits,
	smallpay,
	h5smallpay,
	userpay,
	projectGovhits,
	tenderhits,
	projecthits,
	searchpgv,
	searchtender,
	searchproject,
	searcharticle,
	boundPhone,
	passin,
	vipprojectGov,
	viptender,
	vipproject,
	GovkeywordOrorganization,
	Tenderhot,
	ProjectGovhot,
	sbznlist2,
	zczblist2,
	subscribeshare,
	subscribepush,
	subscribeshareHai,
	audit,
	status,
	Cooperation,
	getRecord,
	reply
}
